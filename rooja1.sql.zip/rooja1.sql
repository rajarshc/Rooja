-- phpMyAdmin SQL Dump
-- version 2.11.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 18, 2011 at 06:15 PM
-- Server version: 5.0.41
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rooja1`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminnotification_inbox`
--

CREATE TABLE `adminnotification_inbox` (
  `notification_id` int(10) unsigned NOT NULL auto_increment,
  `severity` tinyint(3) unsigned NOT NULL default '0',
  `date_added` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `url` varchar(255) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL default '0',
  `is_remove` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`notification_id`),
  KEY `IDX_SEVERITY` (`severity`),
  KEY `IDX_IS_READ` (`is_read`),
  KEY `IDX_IS_REMOVE` (`is_remove`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `adminnotification_inbox`
--

INSERT INTO `adminnotification_inbox` VALUES(1, 4, '2008-07-25 01:24:40', 'Magento 1.1 Production Version Now Available', 'We are thrilled to announce the availability of the production release of Magento 1.1. Read more about the release in the Magento Blog.', 'http://www.magentocommerce.com/blog/comments/magento-11-is-here-1/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(2, 4, '2008-08-02 01:30:16', 'Updated iPhone Theme is now available', 'Updated iPhone theme for Magento 1.1 is now available on Magento Connect and for upgrade through your Magento Connect Manager.', 'http://www.magentocommerce.com/blog/comments/updated-iphone-theme-for-magento-11-is-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(3, 3, '2008-08-02 01:40:27', 'Magento version 1.1.2 is now available', 'Magento version 1.1.2 is now available for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-version-112-is-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(4, 3, '2008-08-13 17:51:46', 'Magento version 1.1.3 is now available', 'Magento version 1.1.3 is now available', 'http://www.magentocommerce.com/blog/comments/magento-version-113-is-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(5, 1, '2008-09-02 21:10:31', 'Magento Version 1.1.4 Security Update Now Available', 'Magento 1.1.4 Security Update Now Available. If you are using Magento version 1.1.x, we highly recommend upgrading to this version as soon as possible.', 'http://www.magentocommerce.com/blog/comments/magento-version-114-security-update/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(6, 3, '2008-09-15 22:09:54', 'Magento version 1.1.5 Now Available', 'Magento version 1.1.5 Now Available.\n\nThis release includes many bug fixes, a new category manager and a new skin for the default Magento theme.', 'http://www.magentocommerce.com/blog/comments/magento-version-115-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(7, 3, '2008-09-17 20:18:35', 'Magento version 1.1.6 Now Available', 'Magento version 1.1.6 Now Available.\n\nThis version includes bug fixes for Magento 1.1.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-116-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(8, 4, '2008-11-07 23:46:42', 'Reminder: Change Magento`s default phone numbers and callouts before site launch', 'Before launching your Magento store, please remember to change Magento`s default phone numbers that appear in email templates, callouts, templates, etc.', '', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(9, 3, '2008-11-20 01:31:12', 'Magento version 1.1.7 Now Available', 'Magento version 1.1.7 Now Available.\n\nThis version includes over 350 issue resolutions for Magento 1.1.x that are listed in the release notes section, and new functionality that includes:\n\n-Google Website Optimizer integration\n-Google Base integration\n-Scheduled DB logs cleaning option', 'http://www.magentocommerce.com/blog/comments/magento-version-117-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(10, 3, '2008-11-26 21:24:50', 'Magento Version 1.1.8 Now Available', 'Magento version 1.1.8 now available.\n\nThis version includes some issue resolutions for Magento 1.1.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-118-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(11, 3, '2008-12-30 07:45:59', 'Magento version 1.2.0 is now available for download and upgrade', 'We are extremely happy to announce the availability of Magento version 1.2.0 for download and upgrade.\n\nThis version includes numerous issue resolutions for Magento version 1.1.x and some highly requested new features such as:\n\n    * Support for Downloadable/Digital Products. \n    * Added Layered Navigation to site search result page.\n    * Improved site search to utilize MySQL fulltext search\n    * Added support for fixed-taxes on product level.\n    * Upgraded Zend Framework to the latest stable version 1.7.2', 'http://www.magentocommerce.com/blog/comments/magento-version-120-is-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(12, 2, '2008-12-30 21:59:22', 'Magento version 1.2.0.1 now available', 'Magento version 1.2.0.1 now available.This version includes some issue resolutions for Magento 1.2.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-1201-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(13, 2, '2009-01-12 20:41:49', 'Magento version 1.2.0.2 now available', 'Magento version 1.2.0.2 is now available for download and upgrade. This version includes an issue resolutions for Magento version 1.2.0.x as listed in the release notes.', 'http://www.magentocommerce.com/blog/comments/magento-version-1202-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(14, 3, '2009-01-24 00:25:56', 'Magento version 1.2.0.3 now available', 'Magento version 1.2.0.3 is now available for download and upgrade. This version includes issue resolutions for Magento version 1.2.0.x as listed in the release notes.', 'http://www.magentocommerce.com/blog/comments/magento-version-1203-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(15, 3, '2009-02-02 21:57:00', 'Magento version 1.2.1 is now available for download and upgrade', 'We are happy to announce the availability of Magento version 1.2.1 for download and upgrade.\n\nThis version includes some issue resolutions for Magento version 1.2.x. A full list of items included in this release can be found on the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-121-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(16, 3, '2009-02-24 00:45:47', 'Magento version 1.2.1.1 now available', 'Magento version 1.2.1.1 now available.This version includes some issue resolutions for Magento 1.2.x that are listed in the release notes section.', 'http://www.magentocommerce.com/blog/comments/magento-version-1211-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(17, 3, '2009-02-27 01:39:24', 'CSRF Attack Prevention', 'We have just posted a blog entry about a hypothetical CSRF attack on a Magento admin panel. Please read the post to find out if your Magento installation is at risk at http://www.magentocommerce.com/blog/comments/csrf-vulnerabilities-in-web-application-and-how-to-avoid-them-in-magento/', 'http://www.magentocommerce.com/blog/comments/csrf-vulnerabilities-in-web-application-and-how-to-avoid-them-in-magento/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(18, 2, '2009-03-03 23:03:58', 'Magento version 1.2.1.2 now available', 'Magento version 1.2.1.2 is now available for download and upgrade.\nThis version includes some updates to improve admin security as described in the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-1212-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(19, 3, '2009-03-31 02:22:40', 'Magento version 1.3.0 now available', 'Magento version 1.3.0 is now available for download and upgrade. This version includes numerous issue resolutions for Magento version 1.2.x and new features as described on the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-130-is-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(20, 3, '2009-04-18 04:06:02', 'Magento version 1.3.1 now available', 'Magento version 1.3.1 is now available for download and upgrade. This version includes some issue resolutions for Magento version 1.3.x and new features such as Checkout By Amazon and Amazon Flexible Payment. To see a full list of updates please check the release notes page.', 'http://www.magentocommerce.com/blog/comments/magento-version-131-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(21, 3, '2009-05-19 22:31:21', 'Magento version 1.3.1.1 now available', 'Magento version 1.3.1.1 is now available for download and upgrade. This version includes some issue resolutions for Magento version 1.3.x and a security update for Magento installations that run on multiple domains or sub-domains. If you are running Magento with multiple domains or sub-domains we highly recommend upgrading to this version.', 'http://www.magentocommerce.com/blog/comments/magento-version-1311-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(22, 3, '2009-05-29 22:54:06', 'Magento version 1.3.2 now available', 'This version includes some improvements and issue resolutions for version 1.3.x that are listed on the release notes page. also included is a Beta version of the Compile module.', 'http://www.magentocommerce.com/blog/comments/magento-version-132-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(23, 3, '2009-06-01 19:32:52', 'Magento version 1.3.2.1 now available', 'Magento version 1.3.2.1 now available for download and upgrade.\n\nThis release solves an issue for users running Magento with PHP 5.2.0, and changes to index.php to support the new Compiler Module.', 'http://www.magentocommerce.com/blog/comments/magento-version-1321-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(24, 3, '2009-07-02 01:21:44', 'Magento version 1.3.2.2 now available', 'Magento version 1.3.2.2 is now available for download and upgrade.\n\nThis release includes issue resolution for Magento version 1.3.x. To see a full list of changes please visit the release notes page http://www.magentocommerce.com/download/release_notes.', 'http://www.magentocommerce.com/blog/comments/magento-version-1322-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(25, 3, '2009-07-23 06:48:54', 'Magento version 1.3.2.3 now available', 'Magento version 1.3.2.3 is now available for download and upgrade.\n\nThis release includes issue resolution for Magento version 1.3.x. We recommend to upgrade to this version if PayPal payment modules are in use. To see a full list of changes please visit the release notes page http://www.magentocommerce.com/download/release_notes.', 'http://www.magentocommerce.com/blog/comments/magento-version-1323-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(26, 4, '2009-08-28 18:26:28', 'PayPal is updating Payflow Pro and Website Payments Pro (Payflow Edition) UK.', 'If you are using Payflow Pro and/or Website Payments Pro (Payflow Edition) UK.  payment methods, you will need to update the URL‘s in your Magento Administrator Panel in order to process transactions after September 1, 2009. Full details are available here: http://www.magentocommerce.com/wiki/paypal_payflow_changes', 'http://www.magentocommerce.com/wiki/paypal_payflow_changes', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(27, 2, '2009-09-23 20:16:49', 'Magento Version 1.3.2.4 Security Update', 'Magento Version 1.3.2.4 is now available. This version includes a security updates for Magento 1.3.x that solves possible XSS vulnerability issue on customer registration page and is available through SVN, Download Page and through the Magento Connect Manager.', 'http://www.magentocommerce.com/blog/comments/magento-version-1324-security-update/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(28, 4, '2009-09-25 14:57:54', 'Magento Preview Version 1.4.0.0-alpha2 is now available', 'We are happy to announce the availability of Magento Preview Version 1.4.0.0-alpha2 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1400-alpha2-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(29, 4, '2009-10-07 00:55:40', 'Magento Preview Version 1.4.0.0-alpha3 is now available', 'We are happy to announce the availability of Magento Preview Version 1.4.0.0-alpha3 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1400-alpha3-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(30, 4, '2009-12-08 23:30:36', 'Magento Preview Version 1.4.0.0-beta1 is now available', 'We are happy to announce the availability of Magento Preview Version 1.4.0.0-beta1 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1400-beta1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(31, 4, '2009-12-31 09:22:12', 'Magento Preview Version 1.4.0.0-rc1 is now available', 'We are happy to announce the availability of Magento Preview Version 1.4.0.0-rc1 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1400-rc1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(32, 4, '2010-02-13 03:39:53', 'Magento CE Version 1.4.0.0 Stable is now available', 'We are excited to announce the availability of Magento CE Version 1.4.0.0 Stable for upgrade and download.', 'http://bit.ly/c53rpK', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(33, 3, '2010-02-20 02:39:36', 'Magento CE Version 1.4.0.1 Stable is now available', 'Magento CE 1.4.0.1 Stable is now available for upgrade and download.', 'http://www.magentocommerce.com/blog/comments/magento-ce-version-1401-stable-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(34, 4, '2010-04-23 20:09:03', 'Magento Version CE 1.3.3.0 Stable - Now Available With Support for 3-D Secure', 'Based on community requests, we are excited to announce the release of Magento CE 1.3.3.0-Stable with support for 3-D Secure. This release is intended for Magento merchants using version 1.3.x, who want to add support for 3-D Secure.', 'http://www.magentocommerce.com/blog/comments/magento-version-ce-1330-stable-now-available-with-support-for-3-d-secure/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(35, 4, '2010-05-31 17:20:21', 'Announcing the Launch of Magento Mobile', 'The Magento team is pleased to announce the launch of Magento mobile, a new product that will allow Magento merchants to easily create branded, native mobile storefront applications that are deeply integrated with Magento’s market-leading eCommerce platform. The product includes a new administrative manager, a native iPhone app that is fully customizable, and a service where Magento manages the submission and maintenance process for the iTunes App Store.\n\nLearn more by visiting the Magento mobile product page and sign-up to be the first to launch a native mobile commerce app, fully integrated with Magento.', 'http://www.magentocommerce.com/product/mobile', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(36, 4, '2010-06-10 20:08:08', 'Magento CE Version 1.4.1.0 Stable is now available', 'We are excited to announce the availability of Magento CE Version 1.4.1.0 Stable for upgrade and download. Some of the highlights of this release include: Enhanced PayPal integration (more info to follow), Change of Database structure of the Sales module to no longer use EAV, and much more.', 'http://www.magentocommerce.com/blog/comments/magento-ce-version-1410-stable-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(37, 4, '2010-07-26 21:37:34', 'Magento CE Version 1.4.1.1 Stable is now available', 'We are excited to announce the availability of Magento CE Version 1.4.1.1 Stable for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-ce-version-1411-stable-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(38, 4, '2010-07-28 05:12:12', 'Magento CE Version 1.4.2.0-beta1 Preview Release Now Available', 'This release gives a preview of the new Magento Connect Manager.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1420-beta1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(39, 4, '2010-07-28 20:15:01', 'Magento CE Version 1.4.1.1 Patch Available', 'As some users experienced issues with upgrading to CE 1.4.1.1 through PEAR channels we provided a patch for it that is available on our blog http://www.magentocommerce.com/blog/comments/magento-ce-version-1411-stable-patch/', 'http://www.magentocommerce.com/blog/comments/magento-ce-version-1411-stable-patch/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(40, 4, '2010-11-08 21:52:06', 'Magento CE Version 1.4.2.0-RC1 Preview Release Now Available', 'We are happy to announce the availability of Magento Preview Version 1.4.2.0-RC1 for download.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1420-rc1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(41, 4, '2010-12-02 20:33:00', 'Magento CE Version 1.4.2.0-RC2 Preview Release Now Available', 'We are happy to announce the availability of Magento Preview Version 1.4.2.0-RC2 for download.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-1420-rc2-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(42, 4, '2010-12-08 22:29:55', 'Magento CE Version 1.4.2.0 Stable is now available', 'We are excited to announce the availability of Magento CE Version 1.4.2.0 Stable for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-ce-version-1420-stable-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(43, 4, '2010-12-17 23:23:55', 'Magento Preview Version CE 1.5.0.0-alpha1 is now available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.0.0-alpha1 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1500-alpha1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(44, 4, '2010-12-29 23:51:08', 'Magento Preview Version CE 1.5.0.0-alpha2 is now available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.0.0-alpha2 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1500-alpha2-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(45, 4, '2011-01-14 00:35:36', 'Magento Preview Version CE 1.5.0.0-beta1 is now available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.0.0-beta1 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1500-beta1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(46, 4, '2011-01-21 21:19:09', 'Magento Preview Version CE 1.5.0.0-beta2 is now available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.0.0-beta2 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1500-beta2-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(47, 4, '2011-01-27 21:27:57', 'Magento Preview Version CE 1.5.0.0-rc1 is now available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.0.0-rc1 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1500-rc1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(48, 4, '2011-02-03 21:56:33', 'Magento Preview Version CE 1.5.0.0-rc2 is now available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.0.0-rc2 for download.\nAs this is a preview version it is NOT recommended in any way to be used in a production environment.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1500-rc2-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(49, 4, '2011-02-08 19:43:23', 'Magento CE Version 1.5.0.0 Stable is now available', 'We are excited to announce the availability of Magento CE Version 1.5.0.0 Stable for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-community-professional-and-enterprise-editions-releases-now-availab/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(50, 4, '2011-02-09 23:42:57', 'Magento CE 1.5.0.1 stable Now Available', 'We are excited to announce the availability of Magento CE Version 1.5.0.1 Stable for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-ce-1501-stable-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(51, 4, '2011-03-18 20:15:45', 'Magento CE 1.5.1.0-beta1 Now Available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.1.0-beta1 for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1510-beta1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(52, 4, '2011-03-31 18:43:02', 'Magento CE 1.5.1.0-rc1 Now Available', 'We are happy to announce the availability of Magento Preview Version CE 1.5.1.0-rc1 for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-preview-version-ce-1510-rc1-now-available/', 1, 0);
INSERT INTO `adminnotification_inbox` VALUES(53, 4, '2011-04-26 19:21:07', 'Magento CE 1.5.1.0-stable Now Available', 'We are excited to announce the availability of Magento CE Version 1.5.1.0 Stable for download and upgrade.', 'http://www.magentocommerce.com/blog/comments/magento-ce-version-1510-stable-now-available/', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_assert`
--

CREATE TABLE `admin_assert` (
  `assert_id` int(10) unsigned NOT NULL auto_increment,
  `assert_type` varchar(20) NOT NULL default '',
  `assert_data` text,
  PRIMARY KEY  (`assert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ACL Asserts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `admin_assert`
--


-- --------------------------------------------------------

--
-- Table structure for table `admin_role`
--

CREATE TABLE `admin_role` (
  `role_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL default '0',
  `tree_level` tinyint(3) unsigned NOT NULL default '0',
  `sort_order` tinyint(3) unsigned NOT NULL default '0',
  `role_type` char(1) NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `role_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`role_id`),
  KEY `parent_id` (`parent_id`,`sort_order`),
  KEY `tree_level` (`tree_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ACL Roles' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin_role`
--

INSERT INTO `admin_role` VALUES(1, 0, 1, 1, 'G', 0, 'Administrators');
INSERT INTO `admin_role` VALUES(3, 1, 2, 0, 'U', 1, 'Adam');

-- --------------------------------------------------------

--
-- Table structure for table `admin_rule`
--

CREATE TABLE `admin_rule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `role_id` int(10) unsigned NOT NULL default '0',
  `resource_id` varchar(255) NOT NULL default '',
  `privileges` varchar(20) NOT NULL default '',
  `assert_id` int(10) unsigned NOT NULL default '0',
  `role_type` char(1) default NULL,
  `permission` varchar(10) default NULL,
  PRIMARY KEY  (`rule_id`),
  KEY `resource` (`resource_id`,`role_id`),
  KEY `role_id` (`role_id`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ACL Rules' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_rule`
--

INSERT INTO `admin_rule` VALUES(1, 1, 'all', '', 0, 'G', 'allow');

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `user_id` mediumint(9) unsigned NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL default '',
  `lastname` varchar(32) NOT NULL default '',
  `email` varchar(128) NOT NULL default '',
  `username` varchar(40) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime default NULL,
  `logdate` datetime default NULL,
  `lognum` smallint(5) unsigned NOT NULL default '0',
  `reload_acl_flag` tinyint(1) NOT NULL default '0',
  `is_active` tinyint(1) NOT NULL default '1',
  `extra` text,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `UNQ_ADMIN_USER_USERNAME` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Users' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` VALUES(1, 'Adam', 'McCombs', 'adamjmccombs@gmail.com', 'admin', '3a7bb21552db48f61080a179022d2f92:Rg', '2011-04-27 19:40:07', '2011-04-27 19:40:07', '2011-05-18 20:38:40', 2, 0, 1, 'a:1:{s:11:"configState";a:7:{s:14:"design_package";s:1:"1";s:12:"design_theme";s:1:"1";s:11:"design_head";s:1:"0";s:13:"design_header";s:1:"0";s:13:"design_footer";s:1:"0";s:16:"design_watermark";s:1:"0";s:17:"design_pagination";s:1:"0";}}');

-- --------------------------------------------------------

--
-- Table structure for table `api_assert`
--

CREATE TABLE `api_assert` (
  `assert_id` int(10) unsigned NOT NULL auto_increment,
  `assert_type` varchar(20) NOT NULL default '',
  `assert_data` text,
  PRIMARY KEY  (`assert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Api ACL Asserts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `api_assert`
--


-- --------------------------------------------------------

--
-- Table structure for table `api_role`
--

CREATE TABLE `api_role` (
  `role_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL default '0',
  `tree_level` tinyint(3) unsigned NOT NULL default '0',
  `sort_order` tinyint(3) unsigned NOT NULL default '0',
  `role_type` char(1) NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `role_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`role_id`),
  KEY `parent_id` (`parent_id`,`sort_order`),
  KEY `tree_level` (`tree_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Api ACL Roles' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `api_role`
--


-- --------------------------------------------------------

--
-- Table structure for table `api_rule`
--

CREATE TABLE `api_rule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `role_id` int(10) unsigned NOT NULL default '0',
  `resource_id` varchar(255) NOT NULL default '',
  `privileges` varchar(20) NOT NULL default '',
  `assert_id` int(10) unsigned NOT NULL default '0',
  `role_type` char(1) default NULL,
  `permission` varchar(10) default NULL,
  PRIMARY KEY  (`rule_id`),
  KEY `resource` (`resource_id`,`role_id`),
  KEY `role_id` (`role_id`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Api ACL Rules' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `api_rule`
--


-- --------------------------------------------------------

--
-- Table structure for table `api_session`
--

CREATE TABLE `api_session` (
  `user_id` mediumint(9) unsigned NOT NULL,
  `logdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `sessid` varchar(40) NOT NULL default '',
  KEY `API_SESSION_USER` (`user_id`),
  KEY `API_SESSION_SESSID` (`sessid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Api Sessions';

--
-- Dumping data for table `api_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `api_user`
--

CREATE TABLE `api_user` (
  `user_id` mediumint(9) unsigned NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL default '',
  `lastname` varchar(32) NOT NULL default '',
  `email` varchar(128) NOT NULL default '',
  `username` varchar(40) NOT NULL default '',
  `api_key` varchar(40) NOT NULL default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime default NULL,
  `lognum` smallint(5) unsigned NOT NULL default '0',
  `reload_acl_flag` tinyint(1) NOT NULL default '0',
  `is_active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Api Users' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `api_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogindex_aggregation`
--

CREATE TABLE `catalogindex_aggregation` (
  `aggregation_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `key` varchar(255) default NULL,
  `data` mediumtext,
  PRIMARY KEY  (`aggregation_id`),
  UNIQUE KEY `IDX_STORE_KEY` (`store_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogindex_aggregation`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogindex_aggregation_tag`
--

CREATE TABLE `catalogindex_aggregation_tag` (
  `tag_id` int(10) unsigned NOT NULL auto_increment,
  `tag_code` varchar(255) NOT NULL,
  PRIMARY KEY  (`tag_id`),
  UNIQUE KEY `IDX_CODE` (`tag_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogindex_aggregation_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogindex_aggregation_to_tag`
--

CREATE TABLE `catalogindex_aggregation_to_tag` (
  `aggregation_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `IDX_AGGREGATION_TAG` (`aggregation_id`,`tag_id`),
  KEY `FK_CATALOGINDEX_AGGREGATION_TO_TAG_TAG` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalogindex_aggregation_to_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogindex_eav`
--

CREATE TABLE `catalogindex_eav` (
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`store_id`,`entity_id`,`attribute_id`,`value`),
  KEY `IDX_VALUE` (`value`),
  KEY `FK_CATALOGINDEX_EAV_ENTITY` (`entity_id`),
  KEY `FK_CATALOGINDEX_EAV_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOGINDEX_EAV_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalogindex_eav`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogindex_minimal_price`
--

CREATE TABLE `catalogindex_minimal_price` (
  `index_id` int(10) unsigned NOT NULL auto_increment,
  `entity_id` int(10) unsigned NOT NULL default '0',
  `customer_group_id` smallint(3) unsigned NOT NULL default '0',
  `qty` decimal(12,4) unsigned NOT NULL default '0.0000',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `tax_class_id` smallint(6) NOT NULL default '0',
  `website_id` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`index_id`),
  KEY `IDX_VALUE` (`value`),
  KEY `IDX_QTY` (`qty`),
  KEY `FK_CATALOGINDEX_MINIMAL_PRICE_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `FK_CI_MINIMAL_PRICE_WEBSITE_ID` (`website_id`),
  KEY `IDX_FULL` (`entity_id`,`qty`,`customer_group_id`,`value`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogindex_minimal_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogindex_price`
--

CREATE TABLE `catalogindex_price` (
  `entity_id` int(10) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `customer_group_id` smallint(3) unsigned NOT NULL default '0',
  `qty` decimal(12,4) unsigned NOT NULL default '0.0000',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `tax_class_id` smallint(6) NOT NULL default '0',
  `website_id` smallint(5) unsigned default NULL,
  KEY `IDX_VALUE` (`value`),
  KEY `IDX_QTY` (`qty`),
  KEY `FK_CATALOGINDEX_PRICE_ENTITY` (`entity_id`),
  KEY `FK_CATALOGINDEX_PRICE_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOGINDEX_PRICE_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `IDX_RANGE_VALUE` (`entity_id`,`attribute_id`,`customer_group_id`,`value`),
  KEY `FK_CI_PRICE_WEBSITE_ID` (`website_id`),
  KEY `IDX_FULL` (`entity_id`,`attribute_id`,`customer_group_id`,`value`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalogindex_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `cataloginventory_stock`
--

CREATE TABLE `cataloginventory_stock` (
  `stock_id` smallint(4) unsigned NOT NULL auto_increment,
  `stock_name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog inventory Stocks list' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cataloginventory_stock`
--

INSERT INTO `cataloginventory_stock` VALUES(1, 'Default');

-- --------------------------------------------------------

--
-- Table structure for table `cataloginventory_stock_item`
--

CREATE TABLE `cataloginventory_stock_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `stock_id` smallint(4) unsigned NOT NULL default '0',
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `min_qty` decimal(12,4) NOT NULL default '0.0000',
  `use_config_min_qty` tinyint(1) unsigned NOT NULL default '1',
  `is_qty_decimal` tinyint(1) unsigned NOT NULL default '0',
  `backorders` tinyint(3) unsigned NOT NULL default '0',
  `use_config_backorders` tinyint(1) unsigned NOT NULL default '1',
  `min_sale_qty` decimal(12,4) NOT NULL default '1.0000',
  `use_config_min_sale_qty` tinyint(1) unsigned NOT NULL default '1',
  `max_sale_qty` decimal(12,4) NOT NULL default '0.0000',
  `use_config_max_sale_qty` tinyint(1) unsigned NOT NULL default '1',
  `is_in_stock` tinyint(1) unsigned NOT NULL default '0',
  `low_stock_date` datetime default NULL,
  `notify_stock_qty` decimal(12,4) default NULL,
  `use_config_notify_stock_qty` tinyint(1) unsigned NOT NULL default '1',
  `manage_stock` tinyint(1) unsigned NOT NULL default '0',
  `use_config_manage_stock` tinyint(1) unsigned NOT NULL default '1',
  `stock_status_changed_automatically` tinyint(1) unsigned NOT NULL default '0',
  `use_config_qty_increments` tinyint(1) unsigned NOT NULL default '1',
  `qty_increments` decimal(12,4) NOT NULL default '0.0000',
  `use_config_enable_qty_increments` tinyint(1) unsigned NOT NULL default '1',
  `enable_qty_increments` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`item_id`),
  UNIQUE KEY `IDX_STOCK_PRODUCT` (`product_id`,`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_ITEM_PRODUCT` (`product_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_ITEM_STOCK` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Inventory Stock Item Data' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cataloginventory_stock_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `cataloginventory_stock_status`
--

CREATE TABLE `cataloginventory_stock_status` (
  `product_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `stock_id` smallint(4) unsigned NOT NULL,
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `stock_status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`,`website_id`,`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_STOCK` (`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cataloginventory_stock_status`
--


-- --------------------------------------------------------

--
-- Table structure for table `cataloginventory_stock_status_idx`
--

CREATE TABLE `cataloginventory_stock_status_idx` (
  `product_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `stock_id` smallint(4) unsigned NOT NULL,
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `stock_status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`,`website_id`,`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_STOCK` (`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cataloginventory_stock_status_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `cataloginventory_stock_status_tmp`
--

CREATE TABLE `cataloginventory_stock_status_tmp` (
  `product_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `stock_id` smallint(4) unsigned NOT NULL,
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `stock_status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`,`website_id`,`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_STOCK` (`stock_id`),
  KEY `FK_CATALOGINVENTORY_STOCK_STATUS_WEBSITE` (`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cataloginventory_stock_status_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogrule`
--

CREATE TABLE `catalogrule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `from_date` date default NULL,
  `to_date` date default NULL,
  `customer_group_ids` text,
  `is_active` tinyint(1) NOT NULL default '0',
  `conditions_serialized` mediumtext NOT NULL,
  `actions_serialized` mediumtext NOT NULL,
  `stop_rules_processing` tinyint(1) NOT NULL default '1',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `simple_action` varchar(32) NOT NULL,
  `discount_amount` decimal(12,4) NOT NULL,
  `website_ids` text,
  PRIMARY KEY  (`rule_id`),
  KEY `sort_order` (`is_active`,`sort_order`,`to_date`,`from_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogrule`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogrule_affected_product`
--

CREATE TABLE `catalogrule_affected_product` (
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalogrule_affected_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogrule_group_website`
--

CREATE TABLE `catalogrule_group_website` (
  `rule_id` int(10) unsigned NOT NULL default '0',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rule_id`,`customer_group_id`,`website_id`),
  KEY `rule_id` (`rule_id`),
  KEY `customer_group_id` (`customer_group_id`),
  KEY `website_id` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `catalogrule_group_website`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogrule_product`
--

CREATE TABLE `catalogrule_product` (
  `rule_product_id` int(10) unsigned NOT NULL auto_increment,
  `rule_id` int(10) unsigned NOT NULL default '0',
  `from_time` int(10) unsigned NOT NULL default '0',
  `to_time` int(10) unsigned NOT NULL default '0',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `action_operator` enum('to_fixed','to_percent','by_fixed','by_percent') NOT NULL default 'to_fixed',
  `action_amount` decimal(12,4) NOT NULL default '0.0000',
  `action_stop` tinyint(1) NOT NULL default '0',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`rule_product_id`),
  UNIQUE KEY `sort_order` (`rule_id`,`from_time`,`to_time`,`website_id`,`customer_group_id`,`product_id`,`sort_order`),
  KEY `FK_catalogrule_product_rule` (`rule_id`),
  KEY `FK_catalogrule_product_customergroup` (`customer_group_id`),
  KEY `FK_catalogrule_product_website` (`website_id`),
  KEY `IDX_FROM_TIME` (`from_time`),
  KEY `IDX_TO_TIME` (`to_time`),
  KEY `FK_CATALOGRULE_PRODUCT_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogrule_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogrule_product_price`
--

CREATE TABLE `catalogrule_product_price` (
  `rule_product_price_id` int(10) unsigned NOT NULL auto_increment,
  `rule_date` date NOT NULL default '0000-00-00',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `rule_price` decimal(12,4) NOT NULL default '0.0000',
  `website_id` smallint(5) unsigned NOT NULL,
  `latest_start_date` date default NULL,
  `earliest_end_date` date default NULL,
  PRIMARY KEY  (`rule_product_price_id`),
  UNIQUE KEY `rule_date` (`rule_date`,`website_id`,`customer_group_id`,`product_id`),
  KEY `FK_catalogrule_product_price_customergroup` (`customer_group_id`),
  KEY `FK_catalogrule_product_price_website` (`website_id`),
  KEY `FK_CATALOGRULE_PRODUCT_PRICE_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogrule_product_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogsearch_fulltext`
--

CREATE TABLE `catalogsearch_fulltext` (
  `product_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `data_index` longtext NOT NULL,
  PRIMARY KEY  (`product_id`,`store_id`),
  FULLTEXT KEY `data_index` (`data_index`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalogsearch_fulltext`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogsearch_query`
--

CREATE TABLE `catalogsearch_query` (
  `query_id` int(10) unsigned NOT NULL auto_increment,
  `query_text` varchar(255) NOT NULL default '',
  `num_results` int(10) unsigned NOT NULL default '0',
  `popularity` int(10) unsigned NOT NULL default '0',
  `redirect` varchar(255) NOT NULL default '',
  `synonym_for` varchar(255) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `display_in_terms` tinyint(1) NOT NULL default '1',
  `is_active` tinyint(1) default '1',
  `is_processed` tinyint(1) default '0',
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`query_id`),
  KEY `FK_CATALOGSEARCH_QUERY_STORE` (`store_id`),
  KEY `IDX_SEARCH_QUERY` (`query_text`,`store_id`,`popularity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalogsearch_query`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalogsearch_result`
--

CREATE TABLE `catalogsearch_result` (
  `query_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `relevance` decimal(6,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`query_id`,`product_id`),
  KEY `IDX_QUERY` (`query_id`),
  KEY `IDX_PRODUCT` (`product_id`),
  KEY `IDX_RELEVANCE` (`query_id`,`relevance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalogsearch_result`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_anc_categs_index_idx`
--

CREATE TABLE `catalog_category_anc_categs_index_idx` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `path` varchar(255) NOT NULL default '',
  KEY `IDX_CATEGORY` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_anc_categs_index_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_anc_categs_index_tmp`
--

CREATE TABLE `catalog_category_anc_categs_index_tmp` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `path` varchar(255) NOT NULL default '',
  KEY `IDX_CATEGORY` (`category_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_anc_categs_index_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_anc_products_index_idx`
--

CREATE TABLE `catalog_category_anc_products_index_idx` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_anc_products_index_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_anc_products_index_tmp`
--

CREATE TABLE `catalog_category_anc_products_index_tmp` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_anc_products_index_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity`
--

CREATE TABLE `catalog_category_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `path` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `children_count` int(11) NOT NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_LEVEL` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Category Entities' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `catalog_category_entity`
--

INSERT INTO `catalog_category_entity` VALUES(1, 3, 0, 0, '0000-00-00 00:00:00', '2011-04-27 19:39:12', '1', 0, 0, 1);
INSERT INTO `catalog_category_entity` VALUES(2, 3, 3, 1, '2011-04-27 19:39:12', '2011-04-27 19:39:12', '1/2', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_datetime`
--

CREATE TABLE `catalog_category_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime default NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DATETIME_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_category_entity_datetime`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_decimal`
--

CREATE TABLE `catalog_category_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) default NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_category_entity_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_int`
--

CREATE TABLE `catalog_category_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) default NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_INT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_EMTITY_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_EMTITY_INT_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `catalog_category_entity_int`
--

INSERT INTO `catalog_category_entity_int` VALUES(1, 3, 34, 1, 2, 1);
INSERT INTO `catalog_category_entity_int` VALUES(2, 3, 105, 0, 1, 1);
INSERT INTO `catalog_category_entity_int` VALUES(3, 3, 105, 0, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_text`
--

CREATE TABLE `catalog_category_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_TEXT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_TEXT_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `catalog_category_entity_text`
--

INSERT INTO `catalog_category_entity_text` VALUES(1, 3, 58, 1, 1, '');
INSERT INTO `catalog_category_entity_text` VALUES(2, 3, 58, 1, 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_varchar`
--

CREATE TABLE `catalog_category_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` USING BTREE (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `catalog_category_entity_varchar`
--

INSERT INTO `catalog_category_entity_varchar` VALUES(1, 3, 33, 1, 1, 'Root Catalog');
INSERT INTO `catalog_category_entity_varchar` VALUES(2, 3, 35, 0, 1, 'root-catalog');
INSERT INTO `catalog_category_entity_varchar` VALUES(3, 3, 33, 1, 2, 'Default Category');
INSERT INTO `catalog_category_entity_varchar` VALUES(4, 3, 41, 1, 2, 'PRODUCTS');
INSERT INTO `catalog_category_entity_varchar` VALUES(5, 3, 35, 0, 2, 'default-category');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_flat_store_1`
--

CREATE TABLE `catalog_category_flat_store_1` (
  `entity_id` int(11) unsigned NOT NULL,
  `parent_id` int(11) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `path` varchar(255) NOT NULL default '',
  `position` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `children_count` int(11) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `all_children` text,
  `available_sort_by` text,
  `children` text,
  `custom_apply_to_products` int(10) NOT NULL default '0',
  `custom_design` varchar(255) NOT NULL default '',
  `custom_design_from` datetime NOT NULL default '0000-00-00 00:00:00',
  `custom_design_to` datetime NOT NULL default '0000-00-00 00:00:00',
  `custom_layout_update` text,
  `custom_use_parent_settings` int(10) NOT NULL default '0',
  `default_sort_by` varchar(255) NOT NULL default '',
  `description` text,
  `display_mode` varchar(255) NOT NULL default '',
  `filter_price_range` int(10) NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `include_in_menu` int(10) NOT NULL default '0',
  `is_active` int(10) NOT NULL default '0',
  `is_anchor` int(10) NOT NULL default '0',
  `landing_page` int(10) NOT NULL default '0',
  `meta_description` text,
  `meta_keywords` text,
  `meta_title` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `page_layout` varchar(255) NOT NULL default '',
  `path_in_store` text,
  `thumbnail` varchar(255) NOT NULL default '',
  `url_key` varchar(255) NOT NULL default '',
  `url_path` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_PATH` (`path`),
  KEY `IDX_LEVEL` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_flat_store_1`
--

INSERT INTO `catalog_category_flat_store_1` VALUES(1, 0, '0000-00-00 00:00:00', '2011-04-27 19:39:12', '1', 0, 0, 1, 1, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '', '', '', 0, '', 1, 0, 0, 0, '', '', '', '', '', '', '', 'root-catalog', '');
INSERT INTO `catalog_category_flat_store_1` VALUES(2, 1, '2011-04-27 19:39:12', '2011-04-27 19:39:12', '1/2', 1, 1, 0, 1, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '', '', '', 0, '', 1, 0, 0, 0, '', '', '', '', '', '', '', 'default-category', '');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product`
--

CREATE TABLE `catalog_category_product` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) NOT NULL default '0',
  UNIQUE KEY `UNQ_CATEGORY_PRODUCT` (`category_id`,`product_id`),
  KEY `CATALOG_CATEGORY_PRODUCT_CATEGORY` (`category_id`),
  KEY `CATALOG_CATEGORY_PRODUCT_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product_index`
--

CREATE TABLE `catalog_category_product_index` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned default NULL,
  `is_parent` tinyint(1) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `visibility` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `UNQ_CATEGORY_PRODUCT` (`category_id`,`product_id`,`store_id`),
  KEY `FK_CATALOG_CATEGORY_PRODUCT_INDEX_CATEGORY_ENTITY` (`category_id`),
  KEY `IDX_JOIN` (`product_id`,`store_id`,`category_id`,`visibility`),
  KEY `IDX_BASE` (`store_id`,`category_id`,`visibility`,`is_parent`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_product_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product_index_enbl_idx`
--

CREATE TABLE `catalog_category_product_index_enbl_idx` (
  `product_id` int(10) unsigned NOT NULL default '0',
  `visibility` int(11) unsigned NOT NULL default '0',
  KEY `IDX_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_product_index_enbl_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product_index_enbl_tmp`
--

CREATE TABLE `catalog_category_product_index_enbl_tmp` (
  `product_id` int(10) unsigned NOT NULL default '0',
  `visibility` int(11) unsigned NOT NULL default '0',
  KEY `IDX_PRODUCT` (`product_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_product_index_enbl_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product_index_idx`
--

CREATE TABLE `catalog_category_product_index_idx` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) NOT NULL default '0',
  `is_parent` tinyint(1) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `visibility` tinyint(3) unsigned NOT NULL,
  KEY `IDX_PRODUCT_CATEGORY_STORE` (`product_id`,`category_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_product_index_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product_index_tmp`
--

CREATE TABLE `catalog_category_product_index_tmp` (
  `category_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `position` int(10) NOT NULL default '0',
  `is_parent` tinyint(1) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `visibility` tinyint(3) unsigned NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_category_product_index_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_compare_item`
--

CREATE TABLE `catalog_compare_item` (
  `catalog_compare_item_id` int(11) unsigned NOT NULL auto_increment,
  `visitor_id` int(11) unsigned NOT NULL default '0',
  `customer_id` int(11) unsigned default NULL,
  `product_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`catalog_compare_item_id`),
  KEY `FK_CATALOG_COMPARE_ITEM_CUSTOMER` (`customer_id`),
  KEY `FK_CATALOG_COMPARE_ITEM_PRODUCT` (`product_id`),
  KEY `IDX_VISITOR_PRODUCTS` (`visitor_id`,`product_id`),
  KEY `IDX_CUSTOMER_PRODUCTS` (`customer_id`,`product_id`),
  KEY `FK_CATALOG_COMPARE_ITEM_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_compare_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_eav_attribute`
--

CREATE TABLE `catalog_eav_attribute` (
  `attribute_id` smallint(5) unsigned NOT NULL auto_increment,
  `frontend_input_renderer` varchar(255) default NULL,
  `is_global` tinyint(1) unsigned NOT NULL default '1',
  `is_visible` tinyint(1) unsigned NOT NULL default '1',
  `is_searchable` tinyint(1) unsigned NOT NULL default '0',
  `is_filterable` tinyint(1) unsigned NOT NULL default '0',
  `is_comparable` tinyint(1) unsigned NOT NULL default '0',
  `is_visible_on_front` tinyint(1) unsigned NOT NULL default '0',
  `is_html_allowed_on_front` tinyint(1) unsigned NOT NULL default '0',
  `is_used_for_price_rules` tinyint(1) unsigned NOT NULL default '0' COMMENT 'deprecated after 1.4.0.1',
  `is_filterable_in_search` tinyint(1) unsigned NOT NULL default '0',
  `used_in_product_listing` tinyint(1) unsigned NOT NULL default '0',
  `used_for_sort_by` tinyint(1) unsigned NOT NULL default '0',
  `is_configurable` tinyint(1) unsigned NOT NULL default '1',
  `apply_to` varchar(255) NOT NULL,
  `is_visible_in_advanced_search` tinyint(1) unsigned NOT NULL default '0',
  `position` int(11) NOT NULL,
  `is_wysiwyg_enabled` tinyint(1) unsigned NOT NULL default '0',
  `is_used_for_promo_rules` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`attribute_id`),
  KEY `IDX_USED_FOR_SORT_BY` (`used_for_sort_by`),
  KEY `IDX_USED_IN_PRODUCT_LISTING` (`used_in_product_listing`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=122 ;

--
-- Dumping data for table `catalog_eav_attribute`
--

INSERT INTO `catalog_eav_attribute` VALUES(33, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(34, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(35, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(36, '', 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, '', 0, 0, 1, 0);
INSERT INTO `catalog_eav_attribute` VALUES(37, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(38, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(39, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(40, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(41, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(42, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(43, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(44, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(45, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(46, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(47, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(48, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(49, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(50, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(51, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(52, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(53, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(54, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(55, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(56, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(57, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(58, 'adminhtml/catalog_category_helper_sortby_available', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(59, 'adminhtml/catalog_category_helper_sortby_default', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(60, '', 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, '', 1, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(61, '', 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, '', 1, 0, 1, 0);
INSERT INTO `catalog_eav_attribute` VALUES(62, '', 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, '', 1, 0, 1, 0);
INSERT INTO `catalog_eav_attribute` VALUES(63, '', 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, '', 1, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(64, '', 2, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 'simple,configurable,virtual,bundle,downloadable', 1, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(65, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(66, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(67, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(68, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'simple,virtual,downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(69, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'simple,bundle', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(70, '', 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 'simple', 1, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(71, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(72, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(73, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(74, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(75, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(76, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(77, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(78, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(79, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(80, '', 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 'simple', 1, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(81, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(82, '', 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(83, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(84, '', 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(85, '', 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 1, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(86, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(87, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(88, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'simple,configurable,virtual,bundle,downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(89, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'simple,virtual', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(90, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'simple,virtual', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(91, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(92, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(93, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(94, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(95, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(96, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(97, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(98, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(99, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(100, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(101, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(102, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(103, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(104, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(105, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(106, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(107, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(108, 'adminhtml/catalog_category_helper_pricestep', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(109, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(110, 'giftmessage/adminhtml_product_helper_form_config', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(111, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'bundle', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(112, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'bundle', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(113, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'bundle', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(114, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'bundle', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(115, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'bundle', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(116, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(117, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(118, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(119, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'downloadable', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(120, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '', 0, 0, 0, 0);
INSERT INTO `catalog_eav_attribute` VALUES(121, '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_bundle_option`
--

CREATE TABLE `catalog_product_bundle_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `required` tinyint(1) unsigned NOT NULL default '0',
  `position` int(10) unsigned NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`option_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_OPTION_PARENT` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Bundle Options' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_bundle_option`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_bundle_option_value`
--

CREATE TABLE `catalog_product_bundle_option_value` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_OPTION_STORE` (`option_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Bundle Selections' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_bundle_option_value`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_bundle_price_index`
--

CREATE TABLE `catalog_product_bundle_price_index` (
  `entity_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `customer_group_id` smallint(3) unsigned NOT NULL,
  `min_price` decimal(12,4) NOT NULL,
  `max_price` decimal(12,4) NOT NULL,
  PRIMARY KEY  (`entity_id`,`website_id`,`customer_group_id`),
  KEY `IDX_WEBSITE` (`website_id`),
  KEY `IDX_CUSTOMER_GROUP` (`customer_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_bundle_price_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_bundle_selection`
--

CREATE TABLE `catalog_product_bundle_selection` (
  `selection_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL,
  `parent_product_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `position` int(10) unsigned NOT NULL default '0',
  `is_default` tinyint(1) unsigned NOT NULL default '0',
  `selection_price_type` tinyint(1) unsigned NOT NULL default '0',
  `selection_price_value` decimal(12,4) NOT NULL default '0.0000',
  `selection_qty` decimal(12,4) NOT NULL default '0.0000',
  `selection_can_change_qty` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`selection_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_OPTION` (`option_id`),
  KEY `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Bundle Selections' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_bundle_selection`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_bundle_selection_price`
--

CREATE TABLE `catalog_product_bundle_selection_price` (
  `selection_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `selection_price_type` tinyint(1) unsigned NOT NULL default '0',
  `selection_price_value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`selection_id`,`website_id`),
  KEY `FK_BUNDLE_PRICE_SELECTION_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_bundle_selection_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_bundle_stock_index`
--

CREATE TABLE `catalog_product_bundle_stock_index` (
  `entity_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `stock_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `stock_status` tinyint(1) default '0',
  PRIMARY KEY  (`entity_id`,`stock_id`,`website_id`,`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_bundle_stock_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_enabled_index`
--

CREATE TABLE `catalog_product_enabled_index` (
  `product_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `visibility` smallint(5) unsigned NOT NULL default '0',
  UNIQUE KEY `UNQ_PRODUCT_STORE` (`product_id`,`store_id`),
  KEY `IDX_PRODUCT_VISIBILITY_IN_STORE` (`product_id`,`store_id`,`visibility`),
  KEY `FK_CATALOG_PRODUCT_ENABLED_INDEX_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_enabled_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity`
--

CREATE TABLE `catalog_product_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `type_id` varchar(32) NOT NULL default 'simple',
  `sku` varchar(64) default NULL,
  `has_options` smallint(1) NOT NULL default '0',
  `required_options` tinyint(1) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_ATTRIBUTE_SET_ID` (`attribute_set_id`),
  KEY `sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Product Entities' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_datetime`
--

CREATE TABLE `catalog_product_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime default NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DATETIME_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DATETIME_PRODUCT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_datetime`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_decimal`
--

CREATE TABLE `catalog_product_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) default NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_ATTRIBUTE` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_gallery`
--

CREATE TABLE `catalog_product_entity_gallery` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `position` int(11) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_BASE` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_GALLERY_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_GALLERY_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_CATEGORY_ENTITY_GALLERY_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_gallery`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_int`
--

CREATE TABLE `catalog_product_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` mediumint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) default NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_INT_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_INT_PRODUCT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_media_gallery`
--

CREATE TABLE `catalog_product_entity_media_gallery` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`value_id`),
  KEY `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog product media gallery' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_media_gallery`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_media_gallery_value`
--

CREATE TABLE `catalog_product_entity_media_gallery_value` (
  `value_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `label` varchar(255) default NULL,
  `position` int(11) unsigned default NULL,
  `disabled` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`value_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_MEDIA_GALLERY_VALUE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog product media gallery values';

--
-- Dumping data for table `catalog_product_entity_media_gallery_value`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_text`
--

CREATE TABLE `catalog_product_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` mediumint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TEXT_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TEXT_PRODUCT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_text`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_tier_price`
--

CREATE TABLE `catalog_product_entity_tier_price` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_id` int(10) unsigned NOT NULL default '0',
  `all_groups` tinyint(1) unsigned NOT NULL default '1',
  `customer_group_id` smallint(5) unsigned NOT NULL default '0',
  `qty` decimal(12,4) NOT NULL default '1.0000',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `website_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_CATALOG_PRODUCT_TIER_PRICE` (`entity_id`,`all_groups`,`customer_group_id`,`qty`,`website_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_GROUP` (`customer_group_id`),
  KEY `FK_CATALOG_PRODUCT_TIER_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_tier_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_varchar`
--

CREATE TABLE `catalog_product_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` mediumint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_STORE` (`store_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_PRODUCT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_entity_varchar`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_flat_1`
--

CREATE TABLE `catalog_product_flat_1` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `type_id` varchar(32) NOT NULL default 'simple',
  `cost` decimal(12,4) default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `enable_googlecheckout` tinyint(1) default NULL,
  `gift_message_available` tinyint(1) default NULL,
  `has_options` smallint(6) NOT NULL default '0',
  `image_label` varchar(255) default NULL,
  `is_imported` tinyint(1) default NULL,
  `is_recurring` tinyint(1) default NULL,
  `links_exist` int(11) default NULL,
  `links_purchased_separately` int(11) default NULL,
  `links_title` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `news_from_date` datetime default NULL,
  `news_to_date` datetime default NULL,
  `price` decimal(12,4) default NULL,
  `price_type` int(11) default NULL,
  `price_view` int(11) default NULL,
  `recurring_profile` text,
  `required_options` tinyint(3) unsigned NOT NULL default '0',
  `shipment_type` int(11) default NULL,
  `short_description` text,
  `sku` varchar(64) default NULL,
  `sku_type` int(11) default NULL,
  `small_image` varchar(255) default NULL,
  `small_image_label` varchar(255) default NULL,
  `special_from_date` datetime default NULL,
  `special_price` decimal(12,4) default NULL,
  `special_to_date` datetime default NULL,
  `tax_class_id` int(11) default NULL,
  `thumbnail` varchar(255) default NULL,
  `thumbnail_label` varchar(255) default NULL,
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `url_key` varchar(255) default NULL,
  `url_path` varchar(255) default NULL,
  `visibility` tinyint(3) unsigned default NULL,
  `weight` decimal(12,4) default NULL,
  `weight_type` int(11) default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_TYPE_ID` (`type_id`),
  KEY `IDX_ATRRIBUTE_SET` (`attribute_set_id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_PRICE` (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_flat_1`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_eav`
--

CREATE TABLE `catalog_product_index_eav` (
  `entity_id` int(10) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`entity_id`,`attribute_id`,`store_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_VALUE` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_eav`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_eav_decimal`
--

CREATE TABLE `catalog_product_index_eav_decimal` (
  `entity_id` int(10) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` decimal(12,4) NOT NULL,
  PRIMARY KEY  (`entity_id`,`attribute_id`,`store_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_VALUE` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_eav_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_eav_decimal_idx`
--

CREATE TABLE `catalog_product_index_eav_decimal_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` decimal(12,4) NOT NULL,
  PRIMARY KEY  (`entity_id`,`attribute_id`,`store_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_VALUE` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_eav_decimal_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_eav_decimal_tmp`
--

CREATE TABLE `catalog_product_index_eav_decimal_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` decimal(12,4) NOT NULL,
  PRIMARY KEY  (`entity_id`,`attribute_id`,`store_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_VALUE` (`value`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_eav_decimal_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_eav_idx`
--

CREATE TABLE `catalog_product_index_eav_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`entity_id`,`attribute_id`,`store_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_VALUE` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_eav_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_eav_tmp`
--

CREATE TABLE `catalog_product_index_eav_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`entity_id`,`attribute_id`,`store_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_VALUE` (`value`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_eav_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price`
--

CREATE TABLE `catalog_product_index_price` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `price` decimal(12,4) default NULL,
  `final_price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`),
  KEY `IDX_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `IDX_WEBSITE` (`website_id`),
  KEY `IDX_MIN_PRICE` (`min_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_bundle_idx`
--

CREATE TABLE `catalog_product_index_price_bundle_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `price_type` tinyint(1) unsigned NOT NULL,
  `special_price` decimal(12,4) default NULL,
  `tier_percent` decimal(12,4) default NULL,
  `orig_price` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  `base_tier` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_bundle_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_bundle_opt_idx`
--

CREATE TABLE `catalog_product_index_price_bundle_opt_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `min_price` decimal(12,4) default NULL,
  `alt_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  `alt_tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`,`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_bundle_opt_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_bundle_opt_tmp`
--

CREATE TABLE `catalog_product_index_price_bundle_opt_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `min_price` decimal(12,4) default NULL,
  `alt_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  `alt_tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`,`option_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_bundle_opt_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_bundle_sel_idx`
--

CREATE TABLE `catalog_product_index_price_bundle_sel_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `selection_id` int(10) unsigned NOT NULL default '0',
  `group_type` tinyint(1) unsigned default '0',
  `is_required` tinyint(1) unsigned default '0',
  `price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`,`option_id`,`selection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_bundle_sel_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_bundle_sel_tmp`
--

CREATE TABLE `catalog_product_index_price_bundle_sel_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `selection_id` int(10) unsigned NOT NULL default '0',
  `group_type` tinyint(1) unsigned default '0',
  `is_required` tinyint(1) unsigned default '0',
  `price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`,`option_id`,`selection_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_bundle_sel_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_bundle_tmp`
--

CREATE TABLE `catalog_product_index_price_bundle_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `price_type` tinyint(1) unsigned NOT NULL,
  `special_price` decimal(12,4) default NULL,
  `tier_percent` decimal(12,4) default NULL,
  `orig_price` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  `base_tier` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_bundle_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_cfg_opt_agr_idx`
--

CREATE TABLE `catalog_product_index_price_cfg_opt_agr_idx` (
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`parent_id`,`child_id`,`customer_group_id`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_cfg_opt_agr_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_cfg_opt_agr_tmp`
--

CREATE TABLE `catalog_product_index_price_cfg_opt_agr_tmp` (
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`parent_id`,`child_id`,`customer_group_id`,`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_cfg_opt_agr_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_cfg_opt_idx`
--

CREATE TABLE `catalog_product_index_price_cfg_opt_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_cfg_opt_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_cfg_opt_tmp`
--

CREATE TABLE `catalog_product_index_price_cfg_opt_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_cfg_opt_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_downlod_idx`
--

CREATE TABLE `catalog_product_index_price_downlod_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_downlod_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_downlod_tmp`
--

CREATE TABLE `catalog_product_index_price_downlod_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_downlod_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_final_idx`
--

CREATE TABLE `catalog_product_index_price_final_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `orig_price` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  `base_tier` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_final_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_final_tmp`
--

CREATE TABLE `catalog_product_index_price_final_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `orig_price` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  `base_tier` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_final_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_idx`
--

CREATE TABLE `catalog_product_index_price_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `price` decimal(12,4) default NULL,
  `final_price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`),
  KEY `IDX_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `IDX_WEBSITE` (`website_id`),
  KEY `IDX_MIN_PRICE` (`min_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_opt_agr_idx`
--

CREATE TABLE `catalog_product_index_price_opt_agr_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`,`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_opt_agr_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_opt_agr_tmp`
--

CREATE TABLE `catalog_product_index_price_opt_agr_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL default '0',
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`,`option_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_opt_agr_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_opt_idx`
--

CREATE TABLE `catalog_product_index_price_opt_idx` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_opt_idx`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_opt_tmp`
--

CREATE TABLE `catalog_product_index_price_opt_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_opt_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price_tmp`
--

CREATE TABLE `catalog_product_index_price_tmp` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `tax_class_id` smallint(5) unsigned default '0',
  `price` decimal(12,4) default NULL,
  `final_price` decimal(12,4) default NULL,
  `min_price` decimal(12,4) default NULL,
  `max_price` decimal(12,4) default NULL,
  `tier_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`),
  KEY `IDX_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `IDX_WEBSITE` (`website_id`),
  KEY `IDX_MIN_PRICE` (`min_price`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_tier_price`
--

CREATE TABLE `catalog_product_index_tier_price` (
  `entity_id` int(10) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `min_price` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`,`customer_group_id`,`website_id`),
  KEY `FK_CATALOG_PRODUCT_INDEX_TIER_PRICE_CUSTOMER` (`customer_group_id`),
  KEY `FK_CATALOG_PRODUCT_INDEX_TIER_PRICE_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_tier_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_website`
--

CREATE TABLE `catalog_product_index_website` (
  `website_id` smallint(5) unsigned NOT NULL,
  `date` date default NULL,
  `rate` float(12,4) unsigned default '1.0000',
  PRIMARY KEY  (`website_id`),
  KEY `IDX_DATE` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_website`
--

INSERT INTO `catalog_product_index_website` VALUES(1, '2011-04-27', 1.0000);

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_link`
--

CREATE TABLE `catalog_product_link` (
  `link_id` int(11) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `linked_product_id` int(10) unsigned NOT NULL default '0',
  `link_type_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`link_id`),
  UNIQUE KEY `IDX_UNIQUE` (`link_type_id`,`product_id`,`linked_product_id`),
  KEY `FK_LINK_PRODUCT` (`product_id`),
  KEY `FK_LINKED_PRODUCT` (`linked_product_id`),
  KEY `FK_PRODUCT_LINK_TYPE` (`link_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Related products' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_link_attribute`
--

CREATE TABLE `catalog_product_link_attribute` (
  `product_link_attribute_id` smallint(6) unsigned NOT NULL auto_increment,
  `link_type_id` tinyint(3) unsigned NOT NULL default '0',
  `product_link_attribute_code` varchar(32) NOT NULL default '',
  `data_type` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`product_link_attribute_id`),
  KEY `FK_ATTRIBUTE_PRODUCT_LINK_TYPE` (`link_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Attributes for product link' AUTO_INCREMENT=9 ;

--
-- Dumping data for table `catalog_product_link_attribute`
--

INSERT INTO `catalog_product_link_attribute` VALUES(1, 2, 'qty', 'decimal');
INSERT INTO `catalog_product_link_attribute` VALUES(2, 1, 'position', 'int');
INSERT INTO `catalog_product_link_attribute` VALUES(3, 4, 'position', 'int');
INSERT INTO `catalog_product_link_attribute` VALUES(4, 5, 'position', 'int');
INSERT INTO `catalog_product_link_attribute` VALUES(6, 1, 'qty', 'decimal');
INSERT INTO `catalog_product_link_attribute` VALUES(7, 3, 'position', 'int');
INSERT INTO `catalog_product_link_attribute` VALUES(8, 3, 'qty', 'decimal');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_link_attribute_decimal`
--

CREATE TABLE `catalog_product_link_attribute_decimal` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `product_link_attribute_id` smallint(6) unsigned default NULL,
  `link_id` int(11) unsigned default NULL,
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  KEY `FK_DECIMAL_PRODUCT_LINK_ATTRIBUTE` (`product_link_attribute_id`),
  KEY `FK_DECIMAL_LINK` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Decimal attributes values' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_link_attribute_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_link_attribute_int`
--

CREATE TABLE `catalog_product_link_attribute_int` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `product_link_attribute_id` smallint(6) unsigned default NULL,
  `link_id` int(11) unsigned default NULL,
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_product_link_attribute_id_link_id` (`product_link_attribute_id`,`link_id`),
  KEY `FK_INT_PRODUCT_LINK_ATTRIBUTE` (`product_link_attribute_id`),
  KEY `FK_INT_PRODUCT_LINK` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_link_attribute_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_link_attribute_varchar`
--

CREATE TABLE `catalog_product_link_attribute_varchar` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `product_link_attribute_id` smallint(6) unsigned NOT NULL default '0',
  `link_id` int(11) unsigned default NULL,
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_VARCHAR_PRODUCT_LINK_ATTRIBUTE` (`product_link_attribute_id`),
  KEY `FK_VARCHAR_LINK` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Varchar attributes values' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_link_attribute_varchar`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_link_type`
--

CREATE TABLE `catalog_product_link_type` (
  `link_type_id` tinyint(3) unsigned NOT NULL auto_increment,
  `code` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`link_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Types of product link(Related, superproduct, bundles)' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `catalog_product_link_type`
--

INSERT INTO `catalog_product_link_type` VALUES(1, 'relation');
INSERT INTO `catalog_product_link_type` VALUES(2, 'bundle');
INSERT INTO `catalog_product_link_type` VALUES(3, 'super');
INSERT INTO `catalog_product_link_type` VALUES(4, 'up_sell');
INSERT INTO `catalog_product_link_type` VALUES(5, 'cross_sell');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_option`
--

CREATE TABLE `catalog_product_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `type` varchar(50) NOT NULL default '',
  `is_require` tinyint(1) NOT NULL default '1',
  `sku` varchar(64) NOT NULL default '',
  `max_characters` int(10) unsigned default NULL,
  `file_extension` varchar(50) default NULL,
  `image_size_x` smallint(5) unsigned NOT NULL,
  `image_size_y` smallint(5) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`),
  KEY `CATALOG_PRODUCT_OPTION_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_option`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_option_price`
--

CREATE TABLE `catalog_product_option_price` (
  `option_price_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `price_type` enum('fixed','percent') NOT NULL default 'fixed',
  PRIMARY KEY  (`option_price_id`),
  UNIQUE KEY `UNQ_OPTION_STORE` (`option_id`,`store_id`),
  KEY `CATALOG_PRODUCT_OPTION_PRICE_OPTION` (`option_id`),
  KEY `CATALOG_PRODUCT_OPTION_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_option_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_option_title`
--

CREATE TABLE `catalog_product_option_title` (
  `option_title_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`option_title_id`),
  UNIQUE KEY `UNQ_OPTION_STORE` (`option_id`,`store_id`),
  KEY `CATALOG_PRODUCT_OPTION_TITLE_OPTION` (`option_id`),
  KEY `CATALOG_PRODUCT_OPTION_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_option_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_option_type_price`
--

CREATE TABLE `catalog_product_option_type_price` (
  `option_type_price_id` int(10) unsigned NOT NULL auto_increment,
  `option_type_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `price_type` enum('fixed','percent') NOT NULL default 'fixed',
  PRIMARY KEY  (`option_type_price_id`),
  UNIQUE KEY `UNQ_OPTION_TYPE_STORE` (`option_type_id`,`store_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_PRICE_OPTION_TYPE` (`option_type_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_PRICE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_option_type_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_option_type_title`
--

CREATE TABLE `catalog_product_option_type_title` (
  `option_type_title_id` int(10) unsigned NOT NULL auto_increment,
  `option_type_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`option_type_title_id`),
  UNIQUE KEY `UNQ_OPTION_TYPE_STORE` (`option_type_id`,`store_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_TITLE_OPTION` (`option_type_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_option_type_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_option_type_value`
--

CREATE TABLE `catalog_product_option_type_value` (
  `option_type_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `sku` varchar(64) NOT NULL default '',
  `sort_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_type_id`),
  KEY `CATALOG_PRODUCT_OPTION_TYPE_VALUE_OPTION` (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_option_type_value`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_relation`
--

CREATE TABLE `catalog_product_relation` (
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`parent_id`,`child_id`),
  KEY `IDX_CHILD` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Dumping data for table `catalog_product_relation`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_super_attribute`
--

CREATE TABLE `catalog_product_super_attribute` (
  `product_super_attribute_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `position` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`product_super_attribute_id`),
  UNIQUE KEY `UNQ_product_id_attribute_id` (`product_id`,`attribute_id`),
  KEY `FK_SUPER_PRODUCT_ATTRIBUTE_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_super_attribute`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_super_attribute_label`
--

CREATE TABLE `catalog_product_super_attribute_label` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `product_super_attribute_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `use_default` tinyint(1) unsigned default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ATTRIBUTE_STORE` (`product_super_attribute_id`,`store_id`),
  KEY `FK_SUPER_PRODUCT_ATTRIBUTE_LABEL` (`product_super_attribute_id`),
  KEY `FK_CATALOG_PRODUCT_SUPER_ATTRIBUTE_LABEL_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_super_attribute_label`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_super_attribute_pricing`
--

CREATE TABLE `catalog_product_super_attribute_pricing` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `product_super_attribute_id` int(10) unsigned NOT NULL default '0',
  `value_index` varchar(255) NOT NULL default '',
  `is_percent` tinyint(1) unsigned default '0',
  `pricing_value` decimal(12,4) default NULL,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_product_super_attribute_id_value_index_website_id` (`product_super_attribute_id`,`value_index`,`website_id`),
  KEY `FK_SUPER_PRODUCT_ATTRIBUTE_PRICING` (`product_super_attribute_id`),
  KEY `FK_CATALOG_PRODUCT_SUPER_PRICE_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_super_attribute_pricing`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_super_link`
--

CREATE TABLE `catalog_product_super_link` (
  `link_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`link_id`),
  UNIQUE KEY `UNQ_product_id_parent_id` (`product_id`,`parent_id`),
  KEY `FK_SUPER_PRODUCT_LINK_PARENT` (`parent_id`),
  KEY `FK_catalog_product_super_link` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_super_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_website`
--

CREATE TABLE `catalog_product_website` (
  `product_id` int(10) unsigned NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`product_id`,`website_id`),
  KEY `FK_CATALOG_PRODUCT_WEBSITE_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catalog_product_website`
--


-- --------------------------------------------------------

--
-- Table structure for table `checkout_agreement`
--

CREATE TABLE `checkout_agreement` (
  `agreement_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `content_height` varchar(25) default NULL,
  `checkbox_text` text NOT NULL,
  `is_active` tinyint(4) NOT NULL default '0',
  `is_html` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`agreement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `checkout_agreement`
--


-- --------------------------------------------------------

--
-- Table structure for table `checkout_agreement_store`
--

CREATE TABLE `checkout_agreement_store` (
  `agreement_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  UNIQUE KEY `agreement_id` (`agreement_id`,`store_id`),
  KEY `FK_CHECKOUT_AGREEMENT_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `checkout_agreement_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `cms_block`
--

CREATE TABLE `cms_block` (
  `block_id` smallint(6) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `identifier` varchar(255) NOT NULL default '',
  `content` mediumtext,
  `creation_time` datetime default NULL,
  `update_time` datetime default NULL,
  `is_active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`block_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Blocks' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cms_block`
--

INSERT INTO `cms_block` VALUES(5, 'Footer Links', 'footer_links', '<ul>\r\n<li><a href="{{store direct_url="about-magento-demo-store"}}">About Us</a></li>\r\n<li class="last"><a href="{{store direct_url="customer-service"}}">Customer Service</a></li>\r\n</ul>', '2011-04-27 14:39:07', '2011-04-27 14:39:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_block_store`
--

CREATE TABLE `cms_block_store` (
  `block_id` smallint(6) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`block_id`,`store_id`),
  KEY `FK_CMS_BLOCK_STORE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Blocks to Stores';

--
-- Dumping data for table `cms_block_store`
--

INSERT INTO `cms_block_store` VALUES(5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cms_page`
--

CREATE TABLE `cms_page` (
  `page_id` smallint(6) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `root_template` varchar(255) NOT NULL default '',
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `identifier` varchar(100) NOT NULL default '',
  `content_heading` varchar(255) NOT NULL default '',
  `content` mediumtext,
  `creation_time` datetime default NULL,
  `update_time` datetime default NULL,
  `is_active` tinyint(1) NOT NULL default '1',
  `sort_order` tinyint(4) NOT NULL default '0',
  `layout_update_xml` text,
  `custom_theme` varchar(100) default NULL,
  `custom_root_template` varchar(255) NOT NULL default '',
  `custom_layout_update_xml` text,
  `custom_theme_from` date default NULL,
  `custom_theme_to` date default NULL,
  PRIMARY KEY  (`page_id`),
  KEY `identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS pages' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cms_page`
--

INSERT INTO `cms_page` VALUES(1, '404 Not Found 1', 'two_columns_right', 'Page keywords', 'Page description', 'no-route', '', '<div class="page-title"><h1>Whoops, our bad...</h1></div>\r\n<dl>\r\n<dt>The page you requested was not found, and we have a fine guess why.</dt>\r\n<dd>\r\n<ul class="disc">\r\n<li>If you typed the URL directly, please make sure the spelling is correct.</li>\r\n<li>If you clicked on a link to get here, the link is outdated.</li>\r\n</ul></dd>\r\n</dl>\r\n<dl>\r\n<dt>What can you do?</dt>\r\n<dd>Have no fear, help is near! There are many ways you can get back on track with Magento Store.</dd>\r\n<dd>\r\n<ul class="disc">\r\n<li><a href="#" onclick="history.back(); return false;">Go back</a> to the previous page.</li>\r\n<li>Use the search bar at the top of the page to search for your products.</li>\r\n<li>Follow these links to get you back on track!<br /><a href="{{store url=""}}">Store Home</a> <span class="separator">|</span> <a href="{{store url="customer/account"}}">My Account</a></li></ul></dd></dl>\r\n', '2007-06-20 18:38:32', '2007-08-26 19:11:13', 1, 0, NULL, NULL, '', NULL, NULL, NULL);
INSERT INTO `cms_page` VALUES(2, 'Home page', 'homepage', '', '', 'home', '', '<div class="page-title">\r\n<h2>Home Page</h2>\r\n</div>', '2007-08-23 10:03:25', '2011-05-18 22:14:42', 1, 0, '<!--<reference name="content">\r\n<block type="catalog/product_new" name="home.catalog.product.new" alias="product_new" template="catalog/product/new.phtml" after="cms_page"><action method="addPriceBlockType"><type>bundle</type><block>bundle/catalog_product_price</block><template>bundle/catalog/product/price.phtml</template></action></block>\r\n<block type="reports/product_viewed" name="home.reports.product.viewed" alias="product_viewed" template="reports/home_product_viewed.phtml" after="product_new"><action method="addPriceBlockType"><type>bundle</type><block>bundle/catalog_product_price</block><template>bundle/catalog/product/price.phtml</template></action></block>\r\n<block type="reports/product_compared" name="home.reports.product.compared" template="reports/home_product_compared.phtml" after="product_viewed"><action method="addPriceBlockType"><type>bundle</type><block>bundle/catalog_product_price</block><template>bundle/catalog/product/price.phtml</template></action></block>\r\n</reference><reference name="right">\r\n<action method="unsetChild"><alias>right.reports.product.viewed</alias></action>\r\n<action method="unsetChild"><alias>right.reports.product.compared</alias></action>\r\n</reference>-->', '', '', '', NULL, NULL);
INSERT INTO `cms_page` VALUES(3, 'About  Us', 'one_column', '', '', 'about-magento-demo-store', '', '<div class="page-title">\r\n<h1>About Magento Store</h1>\r\n</div>\r\n<div class="col3-set">\r\n<div class="col-1"><p><a href="http://www.varien.com/"><img src="{{skin url=''images/media/about_us_img.jpg''}}" title="Varien" alt="Varien" /></a></p><p style="line-height:1.2em;"><small>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede.</small></p>\r\n<p style="color:#888; font:1.2em/1.4em georgia, serif;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta.</p></div>\r\n<div class="col-2">\r\n<p><strong style="color:#de036f;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit.</strong></p>\r\n<p>Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo. </p>\r\n<p>Maecenas ullamcorper, odio vel tempus egestas, dui orci faucibus orci, sit amet aliquet lectus dolor et quam. Pellentesque consequat luctus purus. Nunc et risus. Etiam a nibh. Phasellus dignissim metus eget nisi. Vestibulum sapien dolor, aliquet nec, porta ac, malesuada a, libero. Praesent feugiat purus eget est. Nulla facilisi. Vestibulum tincidunt sapien eu velit. Mauris purus. Maecenas eget mauris eu orci accumsan feugiat. Pellentesque eget velit. Nunc tincidunt.</p></div>\r\n<div class="col-3">\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper </p>\r\n<p><strong style="color:#de036f;">Maecenas ullamcorper, odio vel tempus egestas, dui orci faucibus orci, sit amet aliquet lectus dolor et quam. Pellentesque consequat luctus purus.</strong></p>\r\n<p>Nunc et risus. Etiam a nibh. Phasellus dignissim metus eget nisi.</p>\r\n<div class="divider"></div>\r\n<p>To all of you, from all of us at Magento Store - Thank you and Happy eCommerce!</p>\r\n<p style="line-height:1.2em;"><strong style="font:italic 2em Georgia, serif;">John Doe</strong><br /><small>Some important guy</small></p></div>\r\n</div>', '2007-08-30 14:01:18', '2007-08-30 14:01:18', 1, 0, NULL, NULL, '', NULL, NULL, NULL);
INSERT INTO `cms_page` VALUES(4, 'Customer Service', 'three_columns', '', '', 'customer-service', '', '<div class="page-title">\r\n<h1>Customer Service</h1>\r\n</div>\r\n<ul class="disc">\r\n<li><a href="#answer1">Shipping &amp; Delivery</a></li>\r\n<li><a href="#answer2">Privacy &amp; Security</a></li>\r\n<li><a href="#answer3">Returns &amp; Replacements</a></li>\r\n<li><a href="#answer4">Ordering</a></li>\r\n<li><a href="#answer5">Payment, Pricing &amp; Promotions</a></li>\r\n<li><a href="#answer6">Viewing Orders</a></li>\r\n<li><a href="#answer7">Updating Account Information</a></li>\r\n</ul>\r\n<dl>\r\n<dt id="answer1">Shipping &amp; Delivery</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id="answer2">Privacy &amp; Security</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id="answer3">Returns &amp; Replacements</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id="answer4">Ordering</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id="answer5">Payment, Pricing &amp; Promotions</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id="answer6">Viewing Orders</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n<dt id="answer7">Updating Account Information</dt>\r\n<dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</dd>\r\n</dl>', '2007-08-30 14:02:20', '2007-08-30 14:03:37', 1, 0, NULL, NULL, '', NULL, NULL, NULL);
INSERT INTO `cms_page` VALUES(5, 'Enable Cookies', 'one_column', '', '', 'enable-cookies', '', '<div class="std">\r\n    <ul class="messages">\r\n        <li class="notice-msg">\r\n            <ul>\r\n                <li>Please enable cookies in your web browser to continue.</li>\r\n            </ul>\r\n        </li>\r\n    </ul>\r\n    <div class="page-title">\r\n        <h1><a name="top"></a>What are Cookies?</h1>\r\n    </div>\r\n    <p>Cookies are short pieces of data that are sent to your computer when you visit a website. On later visits, this data is then returned to that website. Cookies allow us to recognize you automatically whenever you visit our site so that we can personalize your experience and provide you with better service. We also use cookies (and similar browser data, such as Flash cookies) for fraud prevention and other purposes. If your web browser is set to refuse cookies from our website, you will not be able to complete a purchase or take advantage of certain features of our website, such as storing items in your Shopping Cart or receiving personalized recommendations. As a result, we strongly encourage you to configure your web browser to accept cookies from our website.</p>\r\n    <h2 class="subtitle">Enabling Cookies</h2>\r\n    <ul class="disc">\r\n        <li><a href="#ie7">Internet Explorer 7.x</a></li>\r\n        <li><a href="#ie6">Internet Explorer 6.x</a></li>\r\n        <li><a href="#firefox">Mozilla/Firefox</a></li>\r\n        <li><a href="#opera">Opera 7.x</a></li>\r\n    </ul>\r\n    <h3><a name="ie7"></a>Internet Explorer 7.x</h3>\r\n    <ol>\r\n        <li>\r\n            <p>Start Internet Explorer</p>\r\n        </li>\r\n        <li>\r\n            <p>Under the <strong>Tools</strong> menu, click <strong>Internet Options</strong></p>\r\n            <p><img src="{{skin url="images/cookies/ie7-1.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Click the <strong>Privacy</strong> tab</p>\r\n            <p><img src="{{skin url="images/cookies/ie7-2.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Click the <strong>Advanced</strong> button</p>\r\n            <p><img src="{{skin url="images/cookies/ie7-3.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Put a check mark in the box for <strong>Override Automatic Cookie Handling</strong>, put another check mark in the <strong>Always accept session cookies </strong>box</p>\r\n            <p><img src="{{skin url="images/cookies/ie7-4.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Click <strong>OK</strong></p>\r\n            <p><img src="{{skin url="images/cookies/ie7-5.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Click <strong>OK</strong></p>\r\n            <p><img src="{{skin url="images/cookies/ie7-6.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Restart Internet Explore</p>\r\n        </li>\r\n    </ol>\r\n    <p class="a-top"><a href="#top">Back to Top</a></p>\r\n    <h3><a name="ie6"></a>Internet Explorer 6.x</h3>\r\n    <ol>\r\n        <li>\r\n            <p>Select <strong>Internet Options</strong> from the Tools menu</p>\r\n            <p><img src="{{skin url="images/cookies/ie6-1.gif"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Click on the <strong>Privacy</strong> tab</p>\r\n        </li>\r\n        <li>\r\n            <p>Click the <strong>Default</strong> button (or manually slide the bar down to <strong>Medium</strong>) under <strong>Settings</strong>. Click <strong>OK</strong></p>\r\n            <p><img src="{{skin url="images/cookies/ie6-2.gif"}}" alt="" /></p>\r\n        </li>\r\n    </ol>\r\n    <p class="a-top"><a href="#top">Back to Top</a></p>\r\n    <h3><a name="firefox"></a>Mozilla/Firefox</h3>\r\n    <ol>\r\n        <li>\r\n            <p>Click on the <strong>Tools</strong>-menu in Mozilla</p>\r\n        </li>\r\n        <li>\r\n            <p>Click on the <strong>Options...</strong> item in the menu - a new window open</p>\r\n        </li>\r\n        <li>\r\n            <p>Click on the <strong>Privacy</strong> selection in the left part of the window. (See image below)</p>\r\n            <p><img src="{{skin url="images/cookies/firefox.png"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>Expand the <strong>Cookies</strong> section</p>\r\n        </li>\r\n        <li>\r\n            <p>Check the <strong>Enable cookies</strong> and <strong>Accept cookies normally</strong> checkboxes</p>\r\n        </li>\r\n        <li>\r\n            <p>Save changes by clicking <strong>Ok</strong>.</p>\r\n        </li>\r\n    </ol>\r\n    <p class="a-top"><a href="#top">Back to Top</a></p>\r\n    <h3><a name="opera"></a>Opera 7.x</h3>\r\n    <ol>\r\n        <li>\r\n            <p>Click on the <strong>Tools</strong> menu in Opera</p>\r\n        </li>\r\n        <li>\r\n            <p>Click on the <strong>Preferences...</strong> item in the menu - a new window open</p>\r\n        </li>\r\n        <li>\r\n            <p>Click on the <strong>Privacy</strong> selection near the bottom left of the window. (See image below)</p>\r\n            <p><img src="{{skin url="images/cookies/opera.png"}}" alt="" /></p>\r\n        </li>\r\n        <li>\r\n            <p>The <strong>Enable cookies</strong> checkbox must be checked, and <strong>Accept all cookies</strong> should be selected in the &quot;<strong>Normal cookies</strong>&quot; drop-down</p>\r\n        </li>\r\n        <li>\r\n            <p>Save changes by clicking <strong>Ok</strong></p>\r\n        </li>\r\n    </ol>\r\n    <p class="a-top"><a href="#top">Back to Top</a></p>\r\n</div>\r\n', '2011-04-27 19:39:07', '2011-04-27 19:39:07', 1, 0, NULL, NULL, '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_page_store`
--

CREATE TABLE `cms_page_store` (
  `page_id` smallint(6) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`page_id`,`store_id`),
  KEY `FK_CMS_PAGE_STORE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Pages to Stores';

--
-- Dumping data for table `cms_page_store`
--

INSERT INTO `cms_page_store` VALUES(1, 0);
INSERT INTO `cms_page_store` VALUES(3, 0);
INSERT INTO `cms_page_store` VALUES(4, 0);
INSERT INTO `cms_page_store` VALUES(5, 0);
INSERT INTO `cms_page_store` VALUES(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `core_cache`
--

CREATE TABLE `core_cache` (
  `id` varchar(255) NOT NULL,
  `data` mediumblob,
  `create_time` int(11) default NULL,
  `update_time` int(11) default NULL,
  `expire_time` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `IDX_EXPIRE_TIME` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `core_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_cache_option`
--

CREATE TABLE `core_cache_option` (
  `code` varchar(32) NOT NULL,
  `value` tinyint(3) default NULL,
  PRIMARY KEY  (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `core_cache_option`
--

INSERT INTO `core_cache_option` VALUES('block_html', 0);
INSERT INTO `core_cache_option` VALUES('collections', 0);
INSERT INTO `core_cache_option` VALUES('config', 0);
INSERT INTO `core_cache_option` VALUES('config_api', 0);
INSERT INTO `core_cache_option` VALUES('eav', 0);
INSERT INTO `core_cache_option` VALUES('layout', 0);
INSERT INTO `core_cache_option` VALUES('translate', 0);

-- --------------------------------------------------------

--
-- Table structure for table `core_cache_tag`
--

CREATE TABLE `core_cache_tag` (
  `tag` varchar(100) NOT NULL default '',
  `cache_id` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`tag`,`cache_id`),
  KEY `IDX_CACHE_ID` (`cache_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `core_cache_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_config_data`
--

CREATE TABLE `core_config_data` (
  `config_id` int(10) unsigned NOT NULL auto_increment,
  `scope` enum('default','websites','stores','config') NOT NULL default 'default',
  `scope_id` int(11) NOT NULL default '0',
  `path` varchar(255) NOT NULL default 'general',
  `value` text NOT NULL,
  PRIMARY KEY  (`config_id`),
  UNIQUE KEY `config_scope` (`scope`,`scope_id`,`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `core_config_data`
--

INSERT INTO `core_config_data` VALUES(1, 'default', 0, 'catalog/category/root_id', '2');
INSERT INTO `core_config_data` VALUES(2, 'default', 0, 'admin/dashboard/enable_charts', '1');
INSERT INTO `core_config_data` VALUES(3, 'default', 0, 'web/unsecure/base_url', 'http://local.rooja/');
INSERT INTO `core_config_data` VALUES(4, 'default', 0, 'web/secure/base_url', 'http://local.rooja/');
INSERT INTO `core_config_data` VALUES(5, 'default', 0, 'general/locale/code', 'en_US');
INSERT INTO `core_config_data` VALUES(6, 'default', 0, 'general/locale/timezone', 'America/Los_Angeles');
INSERT INTO `core_config_data` VALUES(7, 'default', 0, 'currency/options/base', 'USD');
INSERT INTO `core_config_data` VALUES(8, 'default', 0, 'currency/options/default', 'USD');
INSERT INTO `core_config_data` VALUES(9, 'default', 0, 'currency/options/allow', 'USD');
INSERT INTO `core_config_data` VALUES(10, 'default', 0, 'design/package/name', 'default');
INSERT INTO `core_config_data` VALUES(11, 'default', 0, 'design/package/ua_regexp', 'a:0:{}');
INSERT INTO `core_config_data` VALUES(12, 'default', 0, 'design/theme/locale', '');
INSERT INTO `core_config_data` VALUES(13, 'default', 0, 'design/theme/template', 'rooja');
INSERT INTO `core_config_data` VALUES(14, 'default', 0, 'design/theme/template_ua_regexp', 'a:0:{}');
INSERT INTO `core_config_data` VALUES(15, 'default', 0, 'design/theme/skin', 'rooja');
INSERT INTO `core_config_data` VALUES(16, 'default', 0, 'design/theme/skin_ua_regexp', 'a:0:{}');
INSERT INTO `core_config_data` VALUES(17, 'default', 0, 'design/theme/layout', 'rooja');
INSERT INTO `core_config_data` VALUES(18, 'default', 0, 'design/theme/layout_ua_regexp', 'a:0:{}');
INSERT INTO `core_config_data` VALUES(19, 'default', 0, 'design/theme/default', '');
INSERT INTO `core_config_data` VALUES(20, 'default', 0, 'design/theme/default_ua_regexp', 'a:0:{}');
INSERT INTO `core_config_data` VALUES(21, 'default', 0, 'design/head/default_title', 'Magento Commerce');
INSERT INTO `core_config_data` VALUES(22, 'default', 0, 'design/head/title_prefix', '');
INSERT INTO `core_config_data` VALUES(23, 'default', 0, 'design/head/title_suffix', '');
INSERT INTO `core_config_data` VALUES(24, 'default', 0, 'design/head/default_description', 'Default Description');
INSERT INTO `core_config_data` VALUES(25, 'default', 0, 'design/head/default_keywords', 'Magento, Varien, E-commerce');
INSERT INTO `core_config_data` VALUES(26, 'default', 0, 'design/head/default_robots', 'INDEX,FOLLOW');
INSERT INTO `core_config_data` VALUES(27, 'default', 0, 'design/head/includes', '');
INSERT INTO `core_config_data` VALUES(28, 'default', 0, 'design/head/demonotice', '0');
INSERT INTO `core_config_data` VALUES(29, 'default', 0, 'design/header/logo_src', 'images/logo.gif');
INSERT INTO `core_config_data` VALUES(30, 'default', 0, 'design/header/logo_alt', 'Magento Commerce');
INSERT INTO `core_config_data` VALUES(31, 'default', 0, 'design/header/welcome', 'Default welcome msg!');
INSERT INTO `core_config_data` VALUES(32, 'default', 0, 'design/footer/copyright', '&copy; 2008 Magento Demo Store. All Rights Reserved.');
INSERT INTO `core_config_data` VALUES(33, 'default', 0, 'design/footer/absolute_footer', '');
INSERT INTO `core_config_data` VALUES(34, 'default', 0, 'design/watermark/image_size', '');
INSERT INTO `core_config_data` VALUES(35, 'default', 0, 'design/watermark/image_imageOpacity', '');
INSERT INTO `core_config_data` VALUES(36, 'default', 0, 'design/watermark/image_position', 'stretch');
INSERT INTO `core_config_data` VALUES(37, 'default', 0, 'design/watermark/small_image_size', '');
INSERT INTO `core_config_data` VALUES(38, 'default', 0, 'design/watermark/small_image_imageOpacity', '');
INSERT INTO `core_config_data` VALUES(39, 'default', 0, 'design/watermark/small_image_position', 'stretch');
INSERT INTO `core_config_data` VALUES(40, 'default', 0, 'design/watermark/thumbnail_size', '');
INSERT INTO `core_config_data` VALUES(41, 'default', 0, 'design/watermark/thumbnail_imageOpacity', '');
INSERT INTO `core_config_data` VALUES(42, 'default', 0, 'design/watermark/thumbnail_position', 'stretch');
INSERT INTO `core_config_data` VALUES(43, 'default', 0, 'design/pagination/pagination_frame', '5');
INSERT INTO `core_config_data` VALUES(44, 'default', 0, 'design/pagination/pagination_frame_skip', '');
INSERT INTO `core_config_data` VALUES(45, 'default', 0, 'design/pagination/anchor_text_for_previous', '');
INSERT INTO `core_config_data` VALUES(46, 'default', 0, 'design/pagination/anchor_text_for_next', '');

-- --------------------------------------------------------

--
-- Table structure for table `core_email_template`
--

CREATE TABLE `core_email_template` (
  `template_id` int(7) unsigned NOT NULL auto_increment,
  `template_code` varchar(150) default NULL,
  `template_text` text,
  `template_styles` text,
  `template_type` int(3) unsigned default NULL,
  `template_subject` varchar(200) default NULL,
  `template_sender_name` varchar(200) default NULL,
  `template_sender_email` varchar(200) character set latin1 collate latin1_general_ci default NULL,
  `added_at` datetime default NULL,
  `modified_at` datetime default NULL,
  `orig_template_code` varchar(200) default NULL,
  `orig_template_variables` text NOT NULL,
  PRIMARY KEY  (`template_id`),
  UNIQUE KEY `template_code` (`template_code`),
  KEY `added_at` (`added_at`),
  KEY `modified_at` (`modified_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Email templates' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_email_template`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_flag`
--

CREATE TABLE `core_flag` (
  `flag_id` int(10) unsigned NOT NULL auto_increment,
  `flag_code` varchar(255) NOT NULL,
  `state` smallint(5) unsigned NOT NULL default '0',
  `flag_data` text,
  `last_update` datetime NOT NULL,
  PRIMARY KEY  (`flag_id`),
  KEY `last_update` (`last_update`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `core_flag`
--

INSERT INTO `core_flag` VALUES(1, 'admin_notification_survey', 0, 'a:1:{s:13:"survey_viewed";b:1;}', '2011-04-27 19:40:08');
INSERT INTO `core_flag` VALUES(2, 'catalog_product_flat', 0, 'a:1:{s:8:"is_built";b:1;}', '2011-04-27 19:40:54');

-- --------------------------------------------------------

--
-- Table structure for table `core_layout_link`
--

CREATE TABLE `core_layout_link` (
  `layout_link_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `area` varchar(64) NOT NULL default '',
  `package` varchar(64) NOT NULL default '',
  `theme` varchar(64) NOT NULL default '',
  `layout_update_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`layout_link_id`),
  UNIQUE KEY `store_id` (`store_id`,`package`,`theme`,`layout_update_id`),
  KEY `FK_core_layout_link_update` (`layout_update_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_layout_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_layout_update`
--

CREATE TABLE `core_layout_update` (
  `layout_update_id` int(10) unsigned NOT NULL auto_increment,
  `handle` varchar(255) default NULL,
  `xml` text,
  `sort_order` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`layout_update_id`),
  KEY `handle` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_layout_update`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_resource`
--

CREATE TABLE `core_resource` (
  `code` varchar(50) NOT NULL default '',
  `version` varchar(50) NOT NULL default '',
  `data_version` varchar(50) default NULL,
  PRIMARY KEY  (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Resource version registry';

--
-- Dumping data for table `core_resource`
--

INSERT INTO `core_resource` VALUES('adminnotification_setup', '1.0.0', '1.0.0');
INSERT INTO `core_resource` VALUES('admin_setup', '0.7.2', '0.7.2');
INSERT INTO `core_resource` VALUES('api_setup', '0.8.1', '0.8.1');
INSERT INTO `core_resource` VALUES('backup_setup', '0.7.0', '0.7.0');
INSERT INTO `core_resource` VALUES('bundle_setup', '0.1.14', '0.1.14');
INSERT INTO `core_resource` VALUES('catalogindex_setup', '0.7.10', '0.7.10');
INSERT INTO `core_resource` VALUES('cataloginventory_setup', '0.7.8', '0.7.8');
INSERT INTO `core_resource` VALUES('catalogrule_setup', '0.7.10', '0.7.10');
INSERT INTO `core_resource` VALUES('catalogsearch_setup', '0.7.7', '0.7.7');
INSERT INTO `core_resource` VALUES('catalog_setup', '1.4.0.0.44', '1.4.0.0.44');
INSERT INTO `core_resource` VALUES('checkout_setup', '0.9.5', '0.9.5');
INSERT INTO `core_resource` VALUES('cms_setup', '0.7.13', '0.7.13');
INSERT INTO `core_resource` VALUES('compiler_setup', '0.1.0', '0.1.0');
INSERT INTO `core_resource` VALUES('contacts_setup', '0.8.0', '0.8.0');
INSERT INTO `core_resource` VALUES('core_setup', '0.8.28', '0.8.28');
INSERT INTO `core_resource` VALUES('cron_setup', '0.7.1', '0.7.1');
INSERT INTO `core_resource` VALUES('customer_setup', '1.4.0.0.14', '1.4.0.0.14');
INSERT INTO `core_resource` VALUES('dataflow_setup', '0.7.4', '0.7.4');
INSERT INTO `core_resource` VALUES('directory_setup', '0.8.11', '0.8.11');
INSERT INTO `core_resource` VALUES('downloadable_setup', '1.4.0.3', '1.4.0.3');
INSERT INTO `core_resource` VALUES('eav_setup', '0.7.16', '0.7.16');
INSERT INTO `core_resource` VALUES('find_feed_setup', '0.0.2', '0.0.2');
INSERT INTO `core_resource` VALUES('giftmessage_setup', '0.7.6', '0.7.6');
INSERT INTO `core_resource` VALUES('googlebase_setup', '0.1.2', '0.1.2');
INSERT INTO `core_resource` VALUES('googlecheckout_setup', '0.7.4', '0.7.4');
INSERT INTO `core_resource` VALUES('googleoptimizer_setup', '0.1.2', '0.1.2');
INSERT INTO `core_resource` VALUES('importexport_setup', '0.1.0', '0.1.0');
INSERT INTO `core_resource` VALUES('index_setup', '1.4.0.2', '1.4.0.2');
INSERT INTO `core_resource` VALUES('log_setup', '0.7.7', '0.7.7');
INSERT INTO `core_resource` VALUES('moneybookers_setup', '1.2.0.1', '1.2.0.1');
INSERT INTO `core_resource` VALUES('newsletter_setup', '0.8.3', '0.8.3');
INSERT INTO `core_resource` VALUES('paygate_setup', '0.7.1', '0.7.1');
INSERT INTO `core_resource` VALUES('payment_setup', '0.7.0', '0.7.0');
INSERT INTO `core_resource` VALUES('paypaluk_setup', '0.7.0', '0.7.0');
INSERT INTO `core_resource` VALUES('paypal_setup', '1.4.0.2', '1.4.0.2');
INSERT INTO `core_resource` VALUES('poll_setup', '0.7.2', '0.7.2');
INSERT INTO `core_resource` VALUES('productalert_setup', '0.7.2', '0.7.2');
INSERT INTO `core_resource` VALUES('rating_setup', '0.7.2', '0.7.2');
INSERT INTO `core_resource` VALUES('reports_setup', '0.7.10', '0.7.10');
INSERT INTO `core_resource` VALUES('review_setup', '0.7.6', '0.7.6');
INSERT INTO `core_resource` VALUES('salesrule_setup', '1.4.0.0.6', '1.4.0.0.6');
INSERT INTO `core_resource` VALUES('sales_setup', '1.4.0.25', '1.4.0.25');
INSERT INTO `core_resource` VALUES('sendfriend_setup', '0.7.4', '0.7.4');
INSERT INTO `core_resource` VALUES('shipping_setup', '0.7.0', '0.7.0');
INSERT INTO `core_resource` VALUES('sitemap_setup', '0.7.2', '0.7.2');
INSERT INTO `core_resource` VALUES('tag_setup', '0.7.7', '0.7.7');
INSERT INTO `core_resource` VALUES('tax_setup', '1.4.0.1', '1.4.0.1');
INSERT INTO `core_resource` VALUES('usa_setup', '0.7.1', '0.7.1');
INSERT INTO `core_resource` VALUES('weee_setup', '0.13', '0.13');
INSERT INTO `core_resource` VALUES('widget_setup', '1.4.0.0.0', '1.4.0.0.0');
INSERT INTO `core_resource` VALUES('wishlist_setup', '0.7.9', '0.7.9');
INSERT INTO `core_resource` VALUES('xmlconnect_setup', '1.4.0.13', '1.4.0.13');

-- --------------------------------------------------------

--
-- Table structure for table `core_session`
--

CREATE TABLE `core_session` (
  `session_id` varchar(255) NOT NULL default '',
  `website_id` smallint(5) unsigned default NULL,
  `session_expires` int(10) unsigned NOT NULL default '0',
  `session_data` mediumblob NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `FK_SESSION_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Session data store';

--
-- Dumping data for table `core_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_store`
--

CREATE TABLE `core_store` (
  `store_id` smallint(5) unsigned NOT NULL auto_increment,
  `code` varchar(32) NOT NULL default '',
  `website_id` smallint(5) unsigned default '0',
  `group_id` smallint(5) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `sort_order` smallint(5) unsigned NOT NULL default '0',
  `is_active` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`store_id`),
  UNIQUE KEY `code` (`code`),
  KEY `FK_STORE_WEBSITE` (`website_id`),
  KEY `is_active` (`is_active`,`sort_order`),
  KEY `FK_STORE_GROUP` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `core_store`
--

INSERT INTO `core_store` VALUES(0, 'admin', 0, 0, 'Admin', 0, 1);
INSERT INTO `core_store` VALUES(1, 'default', 1, 1, 'Default Store View', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `core_store_group`
--

CREATE TABLE `core_store_group` (
  `group_id` smallint(5) unsigned NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `root_category_id` int(10) unsigned NOT NULL default '0',
  `default_store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`group_id`),
  KEY `FK_STORE_GROUP_WEBSITE` (`website_id`),
  KEY `default_store_id` (`default_store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `core_store_group`
--

INSERT INTO `core_store_group` VALUES(0, 0, 'Default', 0, 0);
INSERT INTO `core_store_group` VALUES(1, 1, 'Main Website Store', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `core_translate`
--

CREATE TABLE `core_translate` (
  `key_id` int(10) unsigned NOT NULL auto_increment,
  `string` varchar(255) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `translate` varchar(255) NOT NULL default '',
  `locale` varchar(20) NOT NULL default 'en_US',
  PRIMARY KEY  (`key_id`),
  UNIQUE KEY `IDX_CODE` (`store_id`,`locale`,`string`),
  KEY `FK_CORE_TRANSLATE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Translation data' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_translate`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_url_rewrite`
--

CREATE TABLE `core_url_rewrite` (
  `url_rewrite_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `category_id` int(10) unsigned default NULL,
  `product_id` int(10) unsigned default NULL,
  `id_path` varchar(255) NOT NULL default '',
  `request_path` varchar(255) NOT NULL default '',
  `target_path` varchar(255) NOT NULL default '',
  `is_system` tinyint(1) unsigned default '1',
  `options` varchar(255) NOT NULL default '',
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`url_rewrite_id`),
  UNIQUE KEY `UNQ_REQUEST_PATH` (`request_path`,`store_id`),
  UNIQUE KEY `UNQ_PATH` (`id_path`,`is_system`,`store_id`),
  KEY `FK_CORE_URL_REWRITE_STORE` (`store_id`),
  KEY `IDX_ID_PATH` (`id_path`),
  KEY `IDX_TARGET_PATH` (`target_path`,`store_id`),
  KEY `FK_CORE_URL_REWRITE_PRODUCT` (`product_id`),
  KEY `IDX_CATEGORY_REWRITE` (`category_id`,`is_system`,`product_id`,`store_id`,`id_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_url_rewrite`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_variable`
--

CREATE TABLE `core_variable` (
  `variable_id` int(11) unsigned NOT NULL auto_increment,
  `code` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`variable_id`),
  UNIQUE KEY `IDX_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_variable`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_variable_value`
--

CREATE TABLE `core_variable_value` (
  `value_id` int(11) unsigned NOT NULL auto_increment,
  `variable_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `plain_value` text NOT NULL,
  `html_value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_VARIABLE_STORE` (`variable_id`,`store_id`),
  KEY `IDX_VARIABLE_ID` (`variable_id`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `core_variable_value`
--


-- --------------------------------------------------------

--
-- Table structure for table `core_website`
--

CREATE TABLE `core_website` (
  `website_id` smallint(5) unsigned NOT NULL auto_increment,
  `code` varchar(32) NOT NULL default '',
  `name` varchar(64) NOT NULL default '',
  `sort_order` smallint(5) unsigned NOT NULL default '0',
  `default_group_id` smallint(5) unsigned NOT NULL default '0',
  `is_default` tinyint(1) unsigned default '0',
  PRIMARY KEY  (`website_id`),
  UNIQUE KEY `code` (`code`),
  KEY `sort_order` (`sort_order`),
  KEY `default_group_id` (`default_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Websites' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `core_website`
--

INSERT INTO `core_website` VALUES(0, 'admin', 'Admin', 0, 0, 0);
INSERT INTO `core_website` VALUES(1, 'base', 'Main Website', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `coupon_aggregated`
--

CREATE TABLE `coupon_aggregated` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `coupon_code` varchar(50) NOT NULL default '',
  `coupon_uses` int(11) NOT NULL default '0',
  `subtotal_amount` decimal(12,4) NOT NULL default '0.0000',
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_amount` decimal(12,4) NOT NULL default '0.0000',
  `subtotal_amount_actual` decimal(12,4) NOT NULL default '0.0000',
  `discount_amount_actual` decimal(12,4) NOT NULL default '0.0000',
  `total_amount_actual` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_COUPON_AGGREGATED_PSOC` (`period`,`store_id`,`order_status`,`coupon_code`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `coupon_aggregated`
--


-- --------------------------------------------------------

--
-- Table structure for table `coupon_aggregated_order`
--

CREATE TABLE `coupon_aggregated_order` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `coupon_code` varchar(50) NOT NULL default '',
  `coupon_uses` int(11) NOT NULL default '0',
  `subtotal_amount` decimal(12,4) NOT NULL default '0.0000',
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_amount` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_COUPON_AGGREGATED_ORDER_PSOC` (`period`,`store_id`,`order_status`,`coupon_code`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `coupon_aggregated_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `cron_schedule`
--

CREATE TABLE `cron_schedule` (
  `schedule_id` int(10) unsigned NOT NULL auto_increment,
  `job_code` varchar(255) NOT NULL default '0',
  `status` enum('pending','running','success','missed','error') NOT NULL default 'pending',
  `messages` text,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `scheduled_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `executed_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `finished_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`schedule_id`),
  KEY `task_name` (`job_code`),
  KEY `scheduled_at` (`scheduled_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cron_schedule`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_address_entity`
--

CREATE TABLE `customer_address_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `parent_id` int(10) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_CUSTOMER_ADDRESS_CUSTOMER_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Customer Address Entities' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_address_entity`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_address_entity_datetime`
--

CREATE TABLE `customer_address_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_address_entity_datetime`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_address_entity_decimal`
--

CREATE TABLE `customer_address_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_address_entity_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_address_entity_int`
--

CREATE TABLE `customer_address_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_INT_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_address_entity_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_address_entity_text`
--

CREATE TABLE `customer_address_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_TEXT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_address_entity_text`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_address_entity_varchar`
--

CREATE TABLE `customer_address_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_ADDRESS_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_address_entity_varchar`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_eav_attribute`
--

CREATE TABLE `customer_eav_attribute` (
  `attribute_id` smallint(5) unsigned NOT NULL auto_increment,
  `is_visible` tinyint(1) unsigned NOT NULL default '1',
  `input_filter` varchar(255) default NULL,
  `multiline_count` tinyint(3) unsigned NOT NULL default '1',
  `validate_rules` text,
  `is_system` tinyint(3) unsigned NOT NULL default '0',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `data_model` varchar(255) default NULL,
  PRIMARY KEY  (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `customer_eav_attribute`
--

INSERT INTO `customer_eav_attribute` VALUES(1, 1, '', 0, NULL, 1, 10, NULL);
INSERT INTO `customer_eav_attribute` VALUES(2, 0, '', 0, NULL, 1, 0, NULL);
INSERT INTO `customer_eav_attribute` VALUES(3, 1, '', 0, NULL, 1, 20, NULL);
INSERT INTO `customer_eav_attribute` VALUES(4, 0, '', 0, NULL, 0, 30, NULL);
INSERT INTO `customer_eav_attribute` VALUES(5, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 40, NULL);
INSERT INTO `customer_eav_attribute` VALUES(6, 0, '', 0, NULL, 0, 50, NULL);
INSERT INTO `customer_eav_attribute` VALUES(7, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 60, NULL);
INSERT INTO `customer_eav_attribute` VALUES(8, 0, '', 0, NULL, 0, 70, NULL);
INSERT INTO `customer_eav_attribute` VALUES(9, 1, '', 0, 'a:1:{s:16:"input_validation";s:5:"email";}', 1, 80, NULL);
INSERT INTO `customer_eav_attribute` VALUES(10, 1, '', 0, NULL, 1, 25, NULL);
INSERT INTO `customer_eav_attribute` VALUES(11, 0, 'date', 0, 'a:1:{s:16:"input_validation";s:4:"date";}', 0, 90, NULL);
INSERT INTO `customer_eav_attribute` VALUES(12, 0, '', 0, NULL, 1, 0, NULL);
INSERT INTO `customer_eav_attribute` VALUES(13, 0, '', 0, NULL, 1, 0, NULL);
INSERT INTO `customer_eav_attribute` VALUES(14, 0, '', 0, NULL, 1, 0, NULL);
INSERT INTO `customer_eav_attribute` VALUES(15, 0, '', 0, 'a:1:{s:15:"max_text_length";i:255;}', 0, 100, NULL);
INSERT INTO `customer_eav_attribute` VALUES(16, 0, '', 0, NULL, 1, 0, NULL);
INSERT INTO `customer_eav_attribute` VALUES(17, 0, '', 0, NULL, 0, 0, NULL);
INSERT INTO `customer_eav_attribute` VALUES(18, 0, '', 0, NULL, 0, 10, NULL);
INSERT INTO `customer_eav_attribute` VALUES(19, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 20, NULL);
INSERT INTO `customer_eav_attribute` VALUES(20, 0, '', 0, NULL, 0, 30, NULL);
INSERT INTO `customer_eav_attribute` VALUES(21, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 40, NULL);
INSERT INTO `customer_eav_attribute` VALUES(22, 0, '', 0, NULL, 0, 50, NULL);
INSERT INTO `customer_eav_attribute` VALUES(23, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 60, NULL);
INSERT INTO `customer_eav_attribute` VALUES(24, 1, '', 2, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 70, NULL);
INSERT INTO `customer_eav_attribute` VALUES(25, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 80, NULL);
INSERT INTO `customer_eav_attribute` VALUES(26, 1, '', 0, NULL, 1, 90, NULL);
INSERT INTO `customer_eav_attribute` VALUES(27, 1, '', 0, NULL, 1, 100, NULL);
INSERT INTO `customer_eav_attribute` VALUES(28, 1, '', 0, NULL, 1, 100, NULL);
INSERT INTO `customer_eav_attribute` VALUES(29, 1, '', 0, 'a:0:{}', 1, 110, 'customer/attribute_data_postcode');
INSERT INTO `customer_eav_attribute` VALUES(30, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 120, NULL);
INSERT INTO `customer_eav_attribute` VALUES(31, 1, '', 0, 'a:2:{s:15:"max_text_length";i:255;s:15:"min_text_length";i:1;}', 1, 130, NULL);
INSERT INTO `customer_eav_attribute` VALUES(32, 0, '', 0, 'a:0:{}', 0, 110, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_eav_attribute_website`
--

CREATE TABLE `customer_eav_attribute_website` (
  `attribute_id` smallint(5) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `is_visible` tinyint(1) unsigned default NULL,
  `is_required` tinyint(1) unsigned default NULL,
  `default_value` text,
  `multiline_count` tinyint(3) unsigned default NULL,
  PRIMARY KEY  (`attribute_id`,`website_id`),
  KEY `IDX_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_eav_attribute_website`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_entity`
--

CREATE TABLE `customer_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned default NULL,
  `email` varchar(255) NOT NULL default '',
  `group_id` smallint(3) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `store_id` smallint(5) unsigned default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_CUSTOMER_ENTITY_STORE` (`store_id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type_id`),
  KEY `IDX_AUTH` (`email`,`website_id`),
  KEY `FK_CUSTOMER_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Customer Entityies' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customer_entity`
--

INSERT INTO `customer_entity` VALUES(1, 1, 0, 1, 'adamjmccombs@gmail.com', 1, '', 1, '2011-05-18 20:40:25', '2011-05-18 20:40:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_entity_datetime`
--

CREATE TABLE `customer_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_DATETIME_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_entity_datetime`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_entity_decimal`
--

CREATE TABLE `customer_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_DECIMAL_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_entity_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_entity_int`
--

CREATE TABLE `customer_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_INT_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_entity_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_entity_text`
--

CREATE TABLE `customer_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_TEXT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_entity_text`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_entity_varchar`
--

CREATE TABLE `customer_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `IDX_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`),
  KEY `FK_CUSTOMER_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_CUSTOMER_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_CUSTOMER_VARCHAR_ENTITY` (`entity_id`),
  KEY `IDX_VALUE` (`entity_id`,`attribute_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `customer_entity_varchar`
--

INSERT INTO `customer_entity_varchar` VALUES(1, 1, 5, 1, 'Adam');
INSERT INTO `customer_entity_varchar` VALUES(2, 1, 7, 1, 'McCombs');
INSERT INTO `customer_entity_varchar` VALUES(3, 1, 12, 1, '95138a0be788871d060cddab22dce181:9W');
INSERT INTO `customer_entity_varchar` VALUES(5, 1, 3, 1, 'Default Store View');

-- --------------------------------------------------------

--
-- Table structure for table `customer_form_attribute`
--

CREATE TABLE `customer_form_attribute` (
  `form_code` char(32) NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`form_code`,`attribute_id`),
  KEY `IDX_CUSTOMER_FORM_ATTRIBUTE_ATTRIBUTE` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customer attributes/forms relations';

--
-- Dumping data for table `customer_form_attribute`
--

INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 1);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 3);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 4);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 4);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 4);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 4);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 5);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 5);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 5);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 5);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 6);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 6);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 6);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 6);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 7);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 7);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 7);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 7);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 8);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 8);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 8);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 8);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_checkout', 9);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 9);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 9);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 9);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 9);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_checkout', 10);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 10);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_checkout', 11);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 11);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 11);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 11);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 11);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_checkout', 15);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 15);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 15);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 15);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 15);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 18);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 18);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 18);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 19);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 19);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 19);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 20);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 20);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 20);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 21);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 21);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 21);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 22);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 22);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 22);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 23);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 23);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 23);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 24);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 24);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 24);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 25);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 25);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 25);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 26);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 26);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 26);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 27);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 27);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 27);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 28);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 28);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 28);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 29);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 29);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 29);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 30);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 30);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 30);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer_address', 31);
INSERT INTO `customer_form_attribute` VALUES('customer_address_edit', 31);
INSERT INTO `customer_form_attribute` VALUES('customer_register_address', 31);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_checkout', 32);
INSERT INTO `customer_form_attribute` VALUES('adminhtml_customer', 32);
INSERT INTO `customer_form_attribute` VALUES('checkout_register', 32);
INSERT INTO `customer_form_attribute` VALUES('customer_account_create', 32);
INSERT INTO `customer_form_attribute` VALUES('customer_account_edit', 32);

-- --------------------------------------------------------

--
-- Table structure for table `customer_group`
--

CREATE TABLE `customer_group` (
  `customer_group_id` smallint(3) unsigned NOT NULL auto_increment,
  `customer_group_code` varchar(32) NOT NULL default '',
  `tax_class_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`customer_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customer groups' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customer_group`
--

INSERT INTO `customer_group` VALUES(0, 'NOT LOGGED IN', 3);
INSERT INTO `customer_group` VALUES(1, 'General', 3);
INSERT INTO `customer_group` VALUES(2, 'Wholesale', 3);
INSERT INTO `customer_group` VALUES(3, 'Retailer', 3);

-- --------------------------------------------------------

--
-- Table structure for table `dataflow_batch`
--

CREATE TABLE `dataflow_batch` (
  `batch_id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `adapter` varchar(128) default NULL,
  `params` text,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`batch_id`),
  KEY `FK_DATAFLOW_BATCH_PROFILE` (`profile_id`),
  KEY `FK_DATAFLOW_BATCH_STORE` (`store_id`),
  KEY `IDX_CREATED_AT` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dataflow_batch`
--


-- --------------------------------------------------------

--
-- Table structure for table `dataflow_batch_export`
--

CREATE TABLE `dataflow_batch_export` (
  `batch_export_id` bigint(20) unsigned NOT NULL auto_increment,
  `batch_id` int(10) unsigned NOT NULL default '0',
  `batch_data` longtext,
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`batch_export_id`),
  KEY `FK_DATAFLOW_BATCH_EXPORT_BATCH` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dataflow_batch_export`
--


-- --------------------------------------------------------

--
-- Table structure for table `dataflow_batch_import`
--

CREATE TABLE `dataflow_batch_import` (
  `batch_import_id` bigint(20) unsigned NOT NULL auto_increment,
  `batch_id` int(10) unsigned NOT NULL default '0',
  `batch_data` longtext,
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`batch_import_id`),
  KEY `FK_DATAFLOW_BATCH_IMPORT_BATCH` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dataflow_batch_import`
--


-- --------------------------------------------------------

--
-- Table structure for table `dataflow_import_data`
--

CREATE TABLE `dataflow_import_data` (
  `import_id` int(11) NOT NULL auto_increment,
  `session_id` int(11) default NULL,
  `serial_number` int(11) NOT NULL default '0',
  `value` text,
  `status` int(1) NOT NULL default '0',
  PRIMARY KEY  (`import_id`),
  KEY `FK_dataflow_import_data` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dataflow_import_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `dataflow_profile`
--

CREATE TABLE `dataflow_profile` (
  `profile_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `actions_xml` text,
  `gui_data` text,
  `direction` enum('import','export') default NULL,
  `entity_type` varchar(64) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `data_transfer` enum('file','interactive') default NULL,
  PRIMARY KEY  (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `dataflow_profile`
--

INSERT INTO `dataflow_profile` VALUES(1, 'Export All Products', '2011-04-27 14:39:07', '2011-04-27 14:39:07', '<action type="catalog/convert_adapter_product" method="load">\r\n    <var name="store"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type="catalog/convert_parser_product" method="unparse">\r\n    <var name="store"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type="dataflow/convert_mapper_column" method="map">\r\n</action>\r\n\r\n<action type="dataflow/convert_parser_csv" method="unparse">\r\n    <var name="delimiter"><![CDATA[,]]></var>\r\n    <var name="enclose"><![CDATA["]]></var>\r\n    <var name="fieldnames">true</var>\r\n</action>\r\n\r\n<action type="dataflow/convert_adapter_io" method="save">\r\n    <var name="type">file</var>\r\n    <var name="path">var/export</var>\r\n    <var name="filename"><![CDATA[export_all_products.csv]]></var>\r\n</action>\r\n\r\n', 'a:5:{s:4:"file";a:7:{s:4:"type";s:4:"file";s:8:"filename";s:23:"export_all_products.csv";s:4:"path";s:10:"var/export";s:4:"host";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:7:"passive";s:0:"";}s:5:"parse";a:5:{s:4:"type";s:3:"csv";s:12:"single_sheet";s:0:"";s:9:"delimiter";s:1:",";s:7:"enclose";s:1:""";s:10:"fieldnames";s:4:"true";}s:3:"map";a:3:{s:14:"only_specified";s:0:"";s:7:"product";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}s:8:"customer";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}}s:7:"product";a:1:{s:6:"filter";a:8:{s:4:"name";s:0:"";s:3:"sku";s:0:"";s:4:"type";s:1:"0";s:13:"attribute_set";s:0:"";s:5:"price";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:3:"qty";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:10:"visibility";s:1:"0";s:6:"status";s:1:"0";}}s:8:"customer";a:1:{s:6:"filter";a:10:{s:9:"firstname";s:0:"";s:8:"lastname";s:0:"";s:5:"email";s:0:"";s:5:"group";s:1:"0";s:10:"adressType";s:15:"default_billing";s:9:"telephone";s:0:"";s:8:"postcode";s:0:"";s:7:"country";s:0:"";s:6:"region";s:0:"";s:10:"created_at";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}}}}', 'export', 'product', 0, 'file');
INSERT INTO `dataflow_profile` VALUES(2, 'Export Product Stocks', '2011-04-27 14:39:07', '2011-04-27 14:39:07', '<action type="catalog/convert_adapter_product" method="load">\r\n    <var name="store"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type="catalog/convert_parser_product" method="unparse">\r\n    <var name="store"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type="dataflow/convert_mapper_column" method="map">\r\n    <var name="map">\r\n        <map name="store"><![CDATA[store]]></map>\r\n        <map name="sku"><![CDATA[sku]]></map>\r\n        <map name="qty"><![CDATA[qty]]></map>\r\n        <map name="is_in_stock"><![CDATA[is_in_stock]]></map>\r\n    </var>\r\n    <var name="_only_specified">true</var>\r\n</action>\r\n\r\n<action type="dataflow/convert_parser_csv" method="unparse">\r\n    <var name="delimiter"><![CDATA[,]]></var>\r\n    <var name="enclose"><![CDATA["]]></var>\r\n    <var name="fieldnames">true</var>\r\n</action>\r\n\r\n<action type="dataflow/convert_adapter_io" method="save">\r\n    <var name="type">file</var>\r\n    <var name="path">var/export</var>\r\n    <var name="filename"><![CDATA[export_product_stocks.csv]]></var>\r\n</action>\r\n\r\n', 'a:5:{s:4:"file";a:7:{s:4:"type";s:4:"file";s:8:"filename";s:25:"export_product_stocks.csv";s:4:"path";s:10:"var/export";s:4:"host";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:7:"passive";s:0:"";}s:5:"parse";a:5:{s:4:"type";s:3:"csv";s:12:"single_sheet";s:0:"";s:9:"delimiter";s:1:",";s:7:"enclose";s:1:""";s:10:"fieldnames";s:4:"true";}s:3:"map";a:3:{s:14:"only_specified";s:4:"true";s:7:"product";a:2:{s:2:"db";a:4:{i:1;s:5:"store";i:2;s:3:"sku";i:3;s:3:"qty";i:4;s:11:"is_in_stock";}s:4:"file";a:4:{i:1;s:5:"store";i:2;s:3:"sku";i:3;s:3:"qty";i:4;s:11:"is_in_stock";}}s:8:"customer";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}}s:7:"product";a:1:{s:6:"filter";a:8:{s:4:"name";s:0:"";s:3:"sku";s:0:"";s:4:"type";s:1:"0";s:13:"attribute_set";s:0:"";s:5:"price";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:3:"qty";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:10:"visibility";s:1:"0";s:6:"status";s:1:"0";}}s:8:"customer";a:1:{s:6:"filter";a:10:{s:9:"firstname";s:0:"";s:8:"lastname";s:0:"";s:5:"email";s:0:"";s:5:"group";s:1:"0";s:10:"adressType";s:15:"default_billing";s:9:"telephone";s:0:"";s:8:"postcode";s:0:"";s:7:"country";s:0:"";s:6:"region";s:0:"";s:10:"created_at";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}}}}', 'export', 'product', 0, 'file');
INSERT INTO `dataflow_profile` VALUES(3, 'Import All Products', '2011-04-27 14:39:07', '2011-04-27 14:39:07', '<action type="dataflow/convert_parser_csv" method="parse">\r\n    <var name="delimiter"><![CDATA[,]]></var>\r\n    <var name="enclose"><![CDATA["]]></var>\r\n    <var name="fieldnames">true</var>\r\n    <var name="store"><![CDATA[0]]></var>\r\n    <var name="adapter">catalog/convert_adapter_product</var>\r\n    <var name="method">parse</var>\r\n</action>', 'a:5:{s:4:"file";a:7:{s:4:"type";s:4:"file";s:8:"filename";s:23:"export_all_products.csv";s:4:"path";s:10:"var/export";s:4:"host";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:7:"passive";s:0:"";}s:5:"parse";a:5:{s:4:"type";s:3:"csv";s:12:"single_sheet";s:0:"";s:9:"delimiter";s:1:",";s:7:"enclose";s:1:""";s:10:"fieldnames";s:4:"true";}s:3:"map";a:3:{s:14:"only_specified";s:0:"";s:7:"product";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}s:8:"customer";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}}s:7:"product";a:1:{s:6:"filter";a:8:{s:4:"name";s:0:"";s:3:"sku";s:0:"";s:4:"type";s:1:"0";s:13:"attribute_set";s:0:"";s:5:"price";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:3:"qty";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:10:"visibility";s:1:"0";s:6:"status";s:1:"0";}}s:8:"customer";a:1:{s:6:"filter";a:10:{s:9:"firstname";s:0:"";s:8:"lastname";s:0:"";s:5:"email";s:0:"";s:5:"group";s:1:"0";s:10:"adressType";s:15:"default_billing";s:9:"telephone";s:0:"";s:8:"postcode";s:0:"";s:7:"country";s:0:"";s:6:"region";s:0:"";s:10:"created_at";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}}}}', 'import', 'product', 0, 'interactive');
INSERT INTO `dataflow_profile` VALUES(4, 'Import Product Stocks', '2011-04-27 14:39:07', '2011-04-27 14:39:07', '<action type="dataflow/convert_parser_csv" method="parse">\r\n    <var name="delimiter"><![CDATA[,]]></var>\r\n    <var name="enclose"><![CDATA["]]></var>\r\n    <var name="fieldnames">true</var>\r\n    <var name="store"><![CDATA[0]]></var>\r\n    <var name="adapter">catalog/convert_adapter_product</var>\r\n    <var name="method">parse</var>\r\n</action>', 'a:5:{s:4:"file";a:7:{s:4:"type";s:4:"file";s:8:"filename";s:18:"export_product.csv";s:4:"path";s:10:"var/export";s:4:"host";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:7:"passive";s:0:"";}s:5:"parse";a:5:{s:4:"type";s:3:"csv";s:12:"single_sheet";s:0:"";s:9:"delimiter";s:1:",";s:7:"enclose";s:1:""";s:10:"fieldnames";s:4:"true";}s:3:"map";a:3:{s:14:"only_specified";s:0:"";s:7:"product";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}s:8:"customer";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}}s:7:"product";a:1:{s:6:"filter";a:8:{s:4:"name";s:0:"";s:3:"sku";s:0:"";s:4:"type";s:1:"0";s:13:"attribute_set";s:0:"";s:5:"price";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:3:"qty";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:10:"visibility";s:1:"0";s:6:"status";s:1:"0";}}s:8:"customer";a:1:{s:6:"filter";a:10:{s:9:"firstname";s:0:"";s:8:"lastname";s:0:"";s:5:"email";s:0:"";s:5:"group";s:1:"0";s:10:"adressType";s:15:"default_billing";s:9:"telephone";s:0:"";s:8:"postcode";s:0:"";s:7:"country";s:0:"";s:6:"region";s:0:"";s:10:"created_at";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}}}}', 'import', 'product', 0, 'interactive');
INSERT INTO `dataflow_profile` VALUES(5, 'Export Customers', '2011-04-27 14:39:07', '2011-04-27 14:39:07', '<action type="customer/convert_adapter_customer" method="load">\r\n    <var name="store"><![CDATA[0]]></var>\r\n    <var name="filter/adressType"><![CDATA[default_billing]]></var>\r\n</action>\r\n\r\n<action type="customer/convert_parser_customer" method="unparse">\r\n    <var name="store"><![CDATA[0]]></var>\r\n</action>\r\n\r\n<action type="dataflow/convert_mapper_column" method="map">\r\n</action>\r\n\r\n<action type="dataflow/convert_parser_csv" method="unparse">\r\n    <var name="delimiter"><![CDATA[,]]></var>\r\n    <var name="enclose"><![CDATA["]]></var>\r\n    <var name="fieldnames">true</var>\r\n</action>\r\n\r\n<action type="dataflow/convert_adapter_io" method="save">\r\n    <var name="type">file</var>\r\n    <var name="path">var/export</var>\r\n    <var name="filename"><![CDATA[export_customers.csv]]></var>\r\n</action>\r\n\r\n', 'a:5:{s:4:"file";a:7:{s:4:"type";s:4:"file";s:8:"filename";s:20:"export_customers.csv";s:4:"path";s:10:"var/export";s:4:"host";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:7:"passive";s:0:"";}s:5:"parse";a:5:{s:4:"type";s:3:"csv";s:12:"single_sheet";s:0:"";s:9:"delimiter";s:1:",";s:7:"enclose";s:1:""";s:10:"fieldnames";s:4:"true";}s:3:"map";a:3:{s:14:"only_specified";s:0:"";s:7:"product";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}s:8:"customer";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}}s:7:"product";a:1:{s:6:"filter";a:8:{s:4:"name";s:0:"";s:3:"sku";s:0:"";s:4:"type";s:1:"0";s:13:"attribute_set";s:0:"";s:5:"price";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:3:"qty";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:10:"visibility";s:1:"0";s:6:"status";s:1:"0";}}s:8:"customer";a:1:{s:6:"filter";a:10:{s:9:"firstname";s:0:"";s:8:"lastname";s:0:"";s:5:"email";s:0:"";s:5:"group";s:1:"0";s:10:"adressType";s:15:"default_billing";s:9:"telephone";s:0:"";s:8:"postcode";s:0:"";s:7:"country";s:0:"";s:6:"region";s:0:"";s:10:"created_at";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}}}}', 'export', 'customer', 0, 'file');
INSERT INTO `dataflow_profile` VALUES(6, 'Import Customers', '2011-04-27 14:39:07', '2011-04-27 14:39:07', '<action type="dataflow/convert_parser_csv" method="parse">\r\n    <var name="delimiter"><![CDATA[,]]></var>\r\n    <var name="enclose"><![CDATA["]]></var>\r\n    <var name="fieldnames">true</var>\r\n    <var name="store"><![CDATA[0]]></var>\r\n    <var name="adapter">customer/convert_adapter_customer</var>\r\n    <var name="method">parse</var>\r\n</action>', 'a:5:{s:4:"file";a:7:{s:4:"type";s:4:"file";s:8:"filename";s:19:"export_customer.csv";s:4:"path";s:10:"var/export";s:4:"host";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:7:"passive";s:0:"";}s:5:"parse";a:5:{s:4:"type";s:3:"csv";s:12:"single_sheet";s:0:"";s:9:"delimiter";s:1:",";s:7:"enclose";s:1:""";s:10:"fieldnames";s:4:"true";}s:3:"map";a:3:{s:14:"only_specified";s:0:"";s:7:"product";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}s:8:"customer";a:2:{s:2:"db";a:0:{}s:4:"file";a:0:{}}}s:7:"product";a:1:{s:6:"filter";a:8:{s:4:"name";s:0:"";s:3:"sku";s:0:"";s:4:"type";s:1:"0";s:13:"attribute_set";s:0:"";s:5:"price";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:3:"qty";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}s:10:"visibility";s:1:"0";s:6:"status";s:1:"0";}}s:8:"customer";a:1:{s:6:"filter";a:10:{s:9:"firstname";s:0:"";s:8:"lastname";s:0:"";s:5:"email";s:0:"";s:5:"group";s:1:"0";s:10:"adressType";s:15:"default_billing";s:9:"telephone";s:0:"";s:8:"postcode";s:0:"";s:7:"country";s:0:"";s:6:"region";s:0:"";s:10:"created_at";a:2:{s:4:"from";s:0:"";s:2:"to";s:0:"";}}}}', 'import', 'customer', 0, 'interactive');

-- --------------------------------------------------------

--
-- Table structure for table `dataflow_profile_history`
--

CREATE TABLE `dataflow_profile_history` (
  `history_id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL default '0',
  `action_code` varchar(64) default NULL,
  `user_id` int(10) unsigned NOT NULL default '0',
  `performed_at` datetime default NULL,
  PRIMARY KEY  (`history_id`),
  KEY `FK_dataflow_profile_history` (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dataflow_profile_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `dataflow_session`
--

CREATE TABLE `dataflow_session` (
  `session_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `created_date` datetime default NULL,
  `file` varchar(255) default NULL,
  `type` varchar(32) default NULL,
  `direction` varchar(32) default NULL,
  `comment` varchar(255) default NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dataflow_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `design_change`
--

CREATE TABLE `design_change` (
  `design_change_id` int(11) NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `design` varchar(255) NOT NULL default '',
  `date_from` date default NULL,
  `date_to` date default NULL,
  PRIMARY KEY  (`design_change_id`),
  KEY `FK_DESIGN_CHANGE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `design_change`
--


-- --------------------------------------------------------

--
-- Table structure for table `directory_country`
--

CREATE TABLE `directory_country` (
  `country_id` varchar(2) NOT NULL default '',
  `iso2_code` varchar(2) NOT NULL default '',
  `iso3_code` varchar(3) NOT NULL default '',
  PRIMARY KEY  (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Countries';

--
-- Dumping data for table `directory_country`
--

INSERT INTO `directory_country` VALUES('AD', 'AD', 'AND');
INSERT INTO `directory_country` VALUES('AE', 'AE', 'ARE');
INSERT INTO `directory_country` VALUES('AF', 'AF', 'AFG');
INSERT INTO `directory_country` VALUES('AG', 'AG', 'ATG');
INSERT INTO `directory_country` VALUES('AI', 'AI', 'AIA');
INSERT INTO `directory_country` VALUES('AL', 'AL', 'ALB');
INSERT INTO `directory_country` VALUES('AM', 'AM', 'ARM');
INSERT INTO `directory_country` VALUES('AN', 'AN', 'ANT');
INSERT INTO `directory_country` VALUES('AO', 'AO', 'AGO');
INSERT INTO `directory_country` VALUES('AQ', 'AQ', 'ATA');
INSERT INTO `directory_country` VALUES('AR', 'AR', 'ARG');
INSERT INTO `directory_country` VALUES('AS', 'AS', 'ASM');
INSERT INTO `directory_country` VALUES('AT', 'AT', 'AUT');
INSERT INTO `directory_country` VALUES('AU', 'AU', 'AUS');
INSERT INTO `directory_country` VALUES('AW', 'AW', 'ABW');
INSERT INTO `directory_country` VALUES('AX', 'AX', 'ALA');
INSERT INTO `directory_country` VALUES('AZ', 'AZ', 'AZE');
INSERT INTO `directory_country` VALUES('BA', 'BA', 'BIH');
INSERT INTO `directory_country` VALUES('BB', 'BB', 'BRB');
INSERT INTO `directory_country` VALUES('BD', 'BD', 'BGD');
INSERT INTO `directory_country` VALUES('BE', 'BE', 'BEL');
INSERT INTO `directory_country` VALUES('BF', 'BF', 'BFA');
INSERT INTO `directory_country` VALUES('BG', 'BG', 'BGR');
INSERT INTO `directory_country` VALUES('BH', 'BH', 'BHR');
INSERT INTO `directory_country` VALUES('BI', 'BI', 'BDI');
INSERT INTO `directory_country` VALUES('BJ', 'BJ', 'BEN');
INSERT INTO `directory_country` VALUES('BL', 'BL', 'BLM');
INSERT INTO `directory_country` VALUES('BM', 'BM', 'BMU');
INSERT INTO `directory_country` VALUES('BN', 'BN', 'BRN');
INSERT INTO `directory_country` VALUES('BO', 'BO', 'BOL');
INSERT INTO `directory_country` VALUES('BR', 'BR', 'BRA');
INSERT INTO `directory_country` VALUES('BS', 'BS', 'BHS');
INSERT INTO `directory_country` VALUES('BT', 'BT', 'BTN');
INSERT INTO `directory_country` VALUES('BV', 'BV', 'BVT');
INSERT INTO `directory_country` VALUES('BW', 'BW', 'BWA');
INSERT INTO `directory_country` VALUES('BY', 'BY', 'BLR');
INSERT INTO `directory_country` VALUES('BZ', 'BZ', 'BLZ');
INSERT INTO `directory_country` VALUES('CA', 'CA', 'CAN');
INSERT INTO `directory_country` VALUES('CC', 'CC', 'CCK');
INSERT INTO `directory_country` VALUES('CD', 'CD', 'COD');
INSERT INTO `directory_country` VALUES('CF', 'CF', 'CAF');
INSERT INTO `directory_country` VALUES('CG', 'CG', 'COG');
INSERT INTO `directory_country` VALUES('CH', 'CH', 'CHE');
INSERT INTO `directory_country` VALUES('CI', 'CI', 'CIV');
INSERT INTO `directory_country` VALUES('CK', 'CK', 'COK');
INSERT INTO `directory_country` VALUES('CL', 'CL', 'CHL');
INSERT INTO `directory_country` VALUES('CM', 'CM', 'CMR');
INSERT INTO `directory_country` VALUES('CN', 'CN', 'CHN');
INSERT INTO `directory_country` VALUES('CO', 'CO', 'COL');
INSERT INTO `directory_country` VALUES('CR', 'CR', 'CRI');
INSERT INTO `directory_country` VALUES('CU', 'CU', 'CUB');
INSERT INTO `directory_country` VALUES('CV', 'CV', 'CPV');
INSERT INTO `directory_country` VALUES('CX', 'CX', 'CXR');
INSERT INTO `directory_country` VALUES('CY', 'CY', 'CYP');
INSERT INTO `directory_country` VALUES('CZ', 'CZ', 'CZE');
INSERT INTO `directory_country` VALUES('DE', 'DE', 'DEU');
INSERT INTO `directory_country` VALUES('DJ', 'DJ', 'DJI');
INSERT INTO `directory_country` VALUES('DK', 'DK', 'DNK');
INSERT INTO `directory_country` VALUES('DM', 'DM', 'DMA');
INSERT INTO `directory_country` VALUES('DO', 'DO', 'DOM');
INSERT INTO `directory_country` VALUES('DZ', 'DZ', 'DZA');
INSERT INTO `directory_country` VALUES('EC', 'EC', 'ECU');
INSERT INTO `directory_country` VALUES('EE', 'EE', 'EST');
INSERT INTO `directory_country` VALUES('EG', 'EG', 'EGY');
INSERT INTO `directory_country` VALUES('EH', 'EH', 'ESH');
INSERT INTO `directory_country` VALUES('ER', 'ER', 'ERI');
INSERT INTO `directory_country` VALUES('ES', 'ES', 'ESP');
INSERT INTO `directory_country` VALUES('ET', 'ET', 'ETH');
INSERT INTO `directory_country` VALUES('FI', 'FI', 'FIN');
INSERT INTO `directory_country` VALUES('FJ', 'FJ', 'FJI');
INSERT INTO `directory_country` VALUES('FK', 'FK', 'FLK');
INSERT INTO `directory_country` VALUES('FM', 'FM', 'FSM');
INSERT INTO `directory_country` VALUES('FO', 'FO', 'FRO');
INSERT INTO `directory_country` VALUES('FR', 'FR', 'FRA');
INSERT INTO `directory_country` VALUES('GA', 'GA', 'GAB');
INSERT INTO `directory_country` VALUES('GB', 'GB', 'GBR');
INSERT INTO `directory_country` VALUES('GD', 'GD', 'GRD');
INSERT INTO `directory_country` VALUES('GE', 'GE', 'GEO');
INSERT INTO `directory_country` VALUES('GF', 'GF', 'GUF');
INSERT INTO `directory_country` VALUES('GG', 'GG', 'GGY');
INSERT INTO `directory_country` VALUES('GH', 'GH', 'GHA');
INSERT INTO `directory_country` VALUES('GI', 'GI', 'GIB');
INSERT INTO `directory_country` VALUES('GL', 'GL', 'GRL');
INSERT INTO `directory_country` VALUES('GM', 'GM', 'GMB');
INSERT INTO `directory_country` VALUES('GN', 'GN', 'GIN');
INSERT INTO `directory_country` VALUES('GP', 'GP', 'GLP');
INSERT INTO `directory_country` VALUES('GQ', 'GQ', 'GNQ');
INSERT INTO `directory_country` VALUES('GR', 'GR', 'GRC');
INSERT INTO `directory_country` VALUES('GS', 'GS', 'SGS');
INSERT INTO `directory_country` VALUES('GT', 'GT', 'GTM');
INSERT INTO `directory_country` VALUES('GU', 'GU', 'GUM');
INSERT INTO `directory_country` VALUES('GW', 'GW', 'GNB');
INSERT INTO `directory_country` VALUES('GY', 'GY', 'GUY');
INSERT INTO `directory_country` VALUES('HK', 'HK', 'HKG');
INSERT INTO `directory_country` VALUES('HM', 'HM', 'HMD');
INSERT INTO `directory_country` VALUES('HN', 'HN', 'HND');
INSERT INTO `directory_country` VALUES('HR', 'HR', 'HRV');
INSERT INTO `directory_country` VALUES('HT', 'HT', 'HTI');
INSERT INTO `directory_country` VALUES('HU', 'HU', 'HUN');
INSERT INTO `directory_country` VALUES('ID', 'ID', 'IDN');
INSERT INTO `directory_country` VALUES('IE', 'IE', 'IRL');
INSERT INTO `directory_country` VALUES('IL', 'IL', 'ISR');
INSERT INTO `directory_country` VALUES('IM', 'IM', 'IMN');
INSERT INTO `directory_country` VALUES('IN', 'IN', 'IND');
INSERT INTO `directory_country` VALUES('IO', 'IO', 'IOT');
INSERT INTO `directory_country` VALUES('IQ', 'IQ', 'IRQ');
INSERT INTO `directory_country` VALUES('IR', 'IR', 'IRN');
INSERT INTO `directory_country` VALUES('IS', 'IS', 'ISL');
INSERT INTO `directory_country` VALUES('IT', 'IT', 'ITA');
INSERT INTO `directory_country` VALUES('JE', 'JE', 'JEY');
INSERT INTO `directory_country` VALUES('JM', 'JM', 'JAM');
INSERT INTO `directory_country` VALUES('JO', 'JO', 'JOR');
INSERT INTO `directory_country` VALUES('JP', 'JP', 'JPN');
INSERT INTO `directory_country` VALUES('KE', 'KE', 'KEN');
INSERT INTO `directory_country` VALUES('KG', 'KG', 'KGZ');
INSERT INTO `directory_country` VALUES('KH', 'KH', 'KHM');
INSERT INTO `directory_country` VALUES('KI', 'KI', 'KIR');
INSERT INTO `directory_country` VALUES('KM', 'KM', 'COM');
INSERT INTO `directory_country` VALUES('KN', 'KN', 'KNA');
INSERT INTO `directory_country` VALUES('KP', 'KP', 'PRK');
INSERT INTO `directory_country` VALUES('KR', 'KR', 'KOR');
INSERT INTO `directory_country` VALUES('KW', 'KW', 'KWT');
INSERT INTO `directory_country` VALUES('KY', 'KY', 'CYM');
INSERT INTO `directory_country` VALUES('KZ', 'KZ', 'KAZ');
INSERT INTO `directory_country` VALUES('LA', 'LA', 'LAO');
INSERT INTO `directory_country` VALUES('LB', 'LB', 'LBN');
INSERT INTO `directory_country` VALUES('LC', 'LC', 'LCA');
INSERT INTO `directory_country` VALUES('LI', 'LI', 'LIE');
INSERT INTO `directory_country` VALUES('LK', 'LK', 'LKA');
INSERT INTO `directory_country` VALUES('LR', 'LR', 'LBR');
INSERT INTO `directory_country` VALUES('LS', 'LS', 'LSO');
INSERT INTO `directory_country` VALUES('LT', 'LT', 'LTU');
INSERT INTO `directory_country` VALUES('LU', 'LU', 'LUX');
INSERT INTO `directory_country` VALUES('LV', 'LV', 'LVA');
INSERT INTO `directory_country` VALUES('LY', 'LY', 'LBY');
INSERT INTO `directory_country` VALUES('MA', 'MA', 'MAR');
INSERT INTO `directory_country` VALUES('MC', 'MC', 'MCO');
INSERT INTO `directory_country` VALUES('MD', 'MD', 'MDA');
INSERT INTO `directory_country` VALUES('ME', 'ME', 'MNE');
INSERT INTO `directory_country` VALUES('MF', 'MF', 'MAF');
INSERT INTO `directory_country` VALUES('MG', 'MG', 'MDG');
INSERT INTO `directory_country` VALUES('MH', 'MH', 'MHL');
INSERT INTO `directory_country` VALUES('MK', 'MK', 'MKD');
INSERT INTO `directory_country` VALUES('ML', 'ML', 'MLI');
INSERT INTO `directory_country` VALUES('MM', 'MM', 'MMR');
INSERT INTO `directory_country` VALUES('MN', 'MN', 'MNG');
INSERT INTO `directory_country` VALUES('MO', 'MO', 'MAC');
INSERT INTO `directory_country` VALUES('MP', 'MP', 'MNP');
INSERT INTO `directory_country` VALUES('MQ', 'MQ', 'MTQ');
INSERT INTO `directory_country` VALUES('MR', 'MR', 'MRT');
INSERT INTO `directory_country` VALUES('MS', 'MS', 'MSR');
INSERT INTO `directory_country` VALUES('MT', 'MT', 'MLT');
INSERT INTO `directory_country` VALUES('MU', 'MU', 'MUS');
INSERT INTO `directory_country` VALUES('MV', 'MV', 'MDV');
INSERT INTO `directory_country` VALUES('MW', 'MW', 'MWI');
INSERT INTO `directory_country` VALUES('MX', 'MX', 'MEX');
INSERT INTO `directory_country` VALUES('MY', 'MY', 'MYS');
INSERT INTO `directory_country` VALUES('MZ', 'MZ', 'MOZ');
INSERT INTO `directory_country` VALUES('NA', 'NA', 'NAM');
INSERT INTO `directory_country` VALUES('NC', 'NC', 'NCL');
INSERT INTO `directory_country` VALUES('NE', 'NE', 'NER');
INSERT INTO `directory_country` VALUES('NF', 'NF', 'NFK');
INSERT INTO `directory_country` VALUES('NG', 'NG', 'NGA');
INSERT INTO `directory_country` VALUES('NI', 'NI', 'NIC');
INSERT INTO `directory_country` VALUES('NL', 'NL', 'NLD');
INSERT INTO `directory_country` VALUES('NO', 'NO', 'NOR');
INSERT INTO `directory_country` VALUES('NP', 'NP', 'NPL');
INSERT INTO `directory_country` VALUES('NR', 'NR', 'NRU');
INSERT INTO `directory_country` VALUES('NU', 'NU', 'NIU');
INSERT INTO `directory_country` VALUES('NZ', 'NZ', 'NZL');
INSERT INTO `directory_country` VALUES('OM', 'OM', 'OMN');
INSERT INTO `directory_country` VALUES('PA', 'PA', 'PAN');
INSERT INTO `directory_country` VALUES('PE', 'PE', 'PER');
INSERT INTO `directory_country` VALUES('PF', 'PF', 'PYF');
INSERT INTO `directory_country` VALUES('PG', 'PG', 'PNG');
INSERT INTO `directory_country` VALUES('PH', 'PH', 'PHL');
INSERT INTO `directory_country` VALUES('PK', 'PK', 'PAK');
INSERT INTO `directory_country` VALUES('PL', 'PL', 'POL');
INSERT INTO `directory_country` VALUES('PM', 'PM', 'SPM');
INSERT INTO `directory_country` VALUES('PN', 'PN', 'PCN');
INSERT INTO `directory_country` VALUES('PR', 'PR', 'PRI');
INSERT INTO `directory_country` VALUES('PS', 'PS', 'PSE');
INSERT INTO `directory_country` VALUES('PT', 'PT', 'PRT');
INSERT INTO `directory_country` VALUES('PW', 'PW', 'PLW');
INSERT INTO `directory_country` VALUES('PY', 'PY', 'PRY');
INSERT INTO `directory_country` VALUES('QA', 'QA', 'QAT');
INSERT INTO `directory_country` VALUES('RE', 'RE', 'REU');
INSERT INTO `directory_country` VALUES('RO', 'RO', 'ROU');
INSERT INTO `directory_country` VALUES('RS', 'RS', 'SRB');
INSERT INTO `directory_country` VALUES('RU', 'RU', 'RUS');
INSERT INTO `directory_country` VALUES('RW', 'RW', 'RWA');
INSERT INTO `directory_country` VALUES('SA', 'SA', 'SAU');
INSERT INTO `directory_country` VALUES('SB', 'SB', 'SLB');
INSERT INTO `directory_country` VALUES('SC', 'SC', 'SYC');
INSERT INTO `directory_country` VALUES('SD', 'SD', 'SDN');
INSERT INTO `directory_country` VALUES('SE', 'SE', 'SWE');
INSERT INTO `directory_country` VALUES('SG', 'SG', 'SGP');
INSERT INTO `directory_country` VALUES('SH', 'SH', 'SHN');
INSERT INTO `directory_country` VALUES('SI', 'SI', 'SVN');
INSERT INTO `directory_country` VALUES('SJ', 'SJ', 'SJM');
INSERT INTO `directory_country` VALUES('SK', 'SK', 'SVK');
INSERT INTO `directory_country` VALUES('SL', 'SL', 'SLE');
INSERT INTO `directory_country` VALUES('SM', 'SM', 'SMR');
INSERT INTO `directory_country` VALUES('SN', 'SN', 'SEN');
INSERT INTO `directory_country` VALUES('SO', 'SO', 'SOM');
INSERT INTO `directory_country` VALUES('SR', 'SR', 'SUR');
INSERT INTO `directory_country` VALUES('ST', 'ST', 'STP');
INSERT INTO `directory_country` VALUES('SV', 'SV', 'SLV');
INSERT INTO `directory_country` VALUES('SY', 'SY', 'SYR');
INSERT INTO `directory_country` VALUES('SZ', 'SZ', 'SWZ');
INSERT INTO `directory_country` VALUES('TC', 'TC', 'TCA');
INSERT INTO `directory_country` VALUES('TD', 'TD', 'TCD');
INSERT INTO `directory_country` VALUES('TF', 'TF', 'ATF');
INSERT INTO `directory_country` VALUES('TG', 'TG', 'TGO');
INSERT INTO `directory_country` VALUES('TH', 'TH', 'THA');
INSERT INTO `directory_country` VALUES('TJ', 'TJ', 'TJK');
INSERT INTO `directory_country` VALUES('TK', 'TK', 'TKL');
INSERT INTO `directory_country` VALUES('TL', 'TL', 'TLS');
INSERT INTO `directory_country` VALUES('TM', 'TM', 'TKM');
INSERT INTO `directory_country` VALUES('TN', 'TN', 'TUN');
INSERT INTO `directory_country` VALUES('TO', 'TO', 'TON');
INSERT INTO `directory_country` VALUES('TR', 'TR', 'TUR');
INSERT INTO `directory_country` VALUES('TT', 'TT', 'TTO');
INSERT INTO `directory_country` VALUES('TV', 'TV', 'TUV');
INSERT INTO `directory_country` VALUES('TW', 'TW', 'TWN');
INSERT INTO `directory_country` VALUES('TZ', 'TZ', 'TZA');
INSERT INTO `directory_country` VALUES('UA', 'UA', 'UKR');
INSERT INTO `directory_country` VALUES('UG', 'UG', 'UGA');
INSERT INTO `directory_country` VALUES('UM', 'UM', 'UMI');
INSERT INTO `directory_country` VALUES('US', 'US', 'USA');
INSERT INTO `directory_country` VALUES('UY', 'UY', 'URY');
INSERT INTO `directory_country` VALUES('UZ', 'UZ', 'UZB');
INSERT INTO `directory_country` VALUES('VA', 'VA', 'VAT');
INSERT INTO `directory_country` VALUES('VC', 'VC', 'VCT');
INSERT INTO `directory_country` VALUES('VE', 'VE', 'VEN');
INSERT INTO `directory_country` VALUES('VG', 'VG', 'VGB');
INSERT INTO `directory_country` VALUES('VI', 'VI', 'VIR');
INSERT INTO `directory_country` VALUES('VN', 'VN', 'VNM');
INSERT INTO `directory_country` VALUES('VU', 'VU', 'VUT');
INSERT INTO `directory_country` VALUES('WF', 'WF', 'WLF');
INSERT INTO `directory_country` VALUES('WS', 'WS', 'WSM');
INSERT INTO `directory_country` VALUES('YE', 'YE', 'YEM');
INSERT INTO `directory_country` VALUES('YT', 'YT', 'MYT');
INSERT INTO `directory_country` VALUES('ZA', 'ZA', 'ZAF');
INSERT INTO `directory_country` VALUES('ZM', 'ZM', 'ZMB');
INSERT INTO `directory_country` VALUES('ZW', 'ZW', 'ZWE');

-- --------------------------------------------------------

--
-- Table structure for table `directory_country_format`
--

CREATE TABLE `directory_country_format` (
  `country_format_id` int(10) unsigned NOT NULL auto_increment,
  `country_id` varchar(2) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `format` text NOT NULL,
  PRIMARY KEY  (`country_format_id`),
  UNIQUE KEY `country_type` (`country_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Countries format' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `directory_country_format`
--


-- --------------------------------------------------------

--
-- Table structure for table `directory_country_region`
--

CREATE TABLE `directory_country_region` (
  `region_id` mediumint(8) unsigned NOT NULL auto_increment,
  `country_id` varchar(4) NOT NULL default '0',
  `code` varchar(32) NOT NULL default '',
  `default_name` varchar(255) default NULL,
  PRIMARY KEY  (`region_id`),
  KEY `FK_REGION_COUNTRY` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Country regions' AUTO_INCREMENT=485 ;

--
-- Dumping data for table `directory_country_region`
--

INSERT INTO `directory_country_region` VALUES(1, 'US', 'AL', 'Alabama');
INSERT INTO `directory_country_region` VALUES(2, 'US', 'AK', 'Alaska');
INSERT INTO `directory_country_region` VALUES(3, 'US', 'AS', 'American Samoa');
INSERT INTO `directory_country_region` VALUES(4, 'US', 'AZ', 'Arizona');
INSERT INTO `directory_country_region` VALUES(5, 'US', 'AR', 'Arkansas');
INSERT INTO `directory_country_region` VALUES(6, 'US', 'AF', 'Armed Forces Africa');
INSERT INTO `directory_country_region` VALUES(7, 'US', 'AA', 'Armed Forces Americas');
INSERT INTO `directory_country_region` VALUES(8, 'US', 'AC', 'Armed Forces Canada');
INSERT INTO `directory_country_region` VALUES(9, 'US', 'AE', 'Armed Forces Europe');
INSERT INTO `directory_country_region` VALUES(10, 'US', 'AM', 'Armed Forces Middle East');
INSERT INTO `directory_country_region` VALUES(11, 'US', 'AP', 'Armed Forces Pacific');
INSERT INTO `directory_country_region` VALUES(12, 'US', 'CA', 'California');
INSERT INTO `directory_country_region` VALUES(13, 'US', 'CO', 'Colorado');
INSERT INTO `directory_country_region` VALUES(14, 'US', 'CT', 'Connecticut');
INSERT INTO `directory_country_region` VALUES(15, 'US', 'DE', 'Delaware');
INSERT INTO `directory_country_region` VALUES(16, 'US', 'DC', 'District of Columbia');
INSERT INTO `directory_country_region` VALUES(17, 'US', 'FM', 'Federated States Of Micronesia');
INSERT INTO `directory_country_region` VALUES(18, 'US', 'FL', 'Florida');
INSERT INTO `directory_country_region` VALUES(19, 'US', 'GA', 'Georgia');
INSERT INTO `directory_country_region` VALUES(20, 'US', 'GU', 'Guam');
INSERT INTO `directory_country_region` VALUES(21, 'US', 'HI', 'Hawaii');
INSERT INTO `directory_country_region` VALUES(22, 'US', 'ID', 'Idaho');
INSERT INTO `directory_country_region` VALUES(23, 'US', 'IL', 'Illinois');
INSERT INTO `directory_country_region` VALUES(24, 'US', 'IN', 'Indiana');
INSERT INTO `directory_country_region` VALUES(25, 'US', 'IA', 'Iowa');
INSERT INTO `directory_country_region` VALUES(26, 'US', 'KS', 'Kansas');
INSERT INTO `directory_country_region` VALUES(27, 'US', 'KY', 'Kentucky');
INSERT INTO `directory_country_region` VALUES(28, 'US', 'LA', 'Louisiana');
INSERT INTO `directory_country_region` VALUES(29, 'US', 'ME', 'Maine');
INSERT INTO `directory_country_region` VALUES(30, 'US', 'MH', 'Marshall Islands');
INSERT INTO `directory_country_region` VALUES(31, 'US', 'MD', 'Maryland');
INSERT INTO `directory_country_region` VALUES(32, 'US', 'MA', 'Massachusetts');
INSERT INTO `directory_country_region` VALUES(33, 'US', 'MI', 'Michigan');
INSERT INTO `directory_country_region` VALUES(34, 'US', 'MN', 'Minnesota');
INSERT INTO `directory_country_region` VALUES(35, 'US', 'MS', 'Mississippi');
INSERT INTO `directory_country_region` VALUES(36, 'US', 'MO', 'Missouri');
INSERT INTO `directory_country_region` VALUES(37, 'US', 'MT', 'Montana');
INSERT INTO `directory_country_region` VALUES(38, 'US', 'NE', 'Nebraska');
INSERT INTO `directory_country_region` VALUES(39, 'US', 'NV', 'Nevada');
INSERT INTO `directory_country_region` VALUES(40, 'US', 'NH', 'New Hampshire');
INSERT INTO `directory_country_region` VALUES(41, 'US', 'NJ', 'New Jersey');
INSERT INTO `directory_country_region` VALUES(42, 'US', 'NM', 'New Mexico');
INSERT INTO `directory_country_region` VALUES(43, 'US', 'NY', 'New York');
INSERT INTO `directory_country_region` VALUES(44, 'US', 'NC', 'North Carolina');
INSERT INTO `directory_country_region` VALUES(45, 'US', 'ND', 'North Dakota');
INSERT INTO `directory_country_region` VALUES(46, 'US', 'MP', 'Northern Mariana Islands');
INSERT INTO `directory_country_region` VALUES(47, 'US', 'OH', 'Ohio');
INSERT INTO `directory_country_region` VALUES(48, 'US', 'OK', 'Oklahoma');
INSERT INTO `directory_country_region` VALUES(49, 'US', 'OR', 'Oregon');
INSERT INTO `directory_country_region` VALUES(50, 'US', 'PW', 'Palau');
INSERT INTO `directory_country_region` VALUES(51, 'US', 'PA', 'Pennsylvania');
INSERT INTO `directory_country_region` VALUES(52, 'US', 'PR', 'Puerto Rico');
INSERT INTO `directory_country_region` VALUES(53, 'US', 'RI', 'Rhode Island');
INSERT INTO `directory_country_region` VALUES(54, 'US', 'SC', 'South Carolina');
INSERT INTO `directory_country_region` VALUES(55, 'US', 'SD', 'South Dakota');
INSERT INTO `directory_country_region` VALUES(56, 'US', 'TN', 'Tennessee');
INSERT INTO `directory_country_region` VALUES(57, 'US', 'TX', 'Texas');
INSERT INTO `directory_country_region` VALUES(58, 'US', 'UT', 'Utah');
INSERT INTO `directory_country_region` VALUES(59, 'US', 'VT', 'Vermont');
INSERT INTO `directory_country_region` VALUES(60, 'US', 'VI', 'Virgin Islands');
INSERT INTO `directory_country_region` VALUES(61, 'US', 'VA', 'Virginia');
INSERT INTO `directory_country_region` VALUES(62, 'US', 'WA', 'Washington');
INSERT INTO `directory_country_region` VALUES(63, 'US', 'WV', 'West Virginia');
INSERT INTO `directory_country_region` VALUES(64, 'US', 'WI', 'Wisconsin');
INSERT INTO `directory_country_region` VALUES(65, 'US', 'WY', 'Wyoming');
INSERT INTO `directory_country_region` VALUES(66, 'CA', 'AB', 'Alberta');
INSERT INTO `directory_country_region` VALUES(67, 'CA', 'BC', 'British Columbia');
INSERT INTO `directory_country_region` VALUES(68, 'CA', 'MB', 'Manitoba');
INSERT INTO `directory_country_region` VALUES(69, 'CA', 'NL', 'Newfoundland and Labrador');
INSERT INTO `directory_country_region` VALUES(70, 'CA', 'NB', 'New Brunswick');
INSERT INTO `directory_country_region` VALUES(71, 'CA', 'NS', 'Nova Scotia');
INSERT INTO `directory_country_region` VALUES(72, 'CA', 'NT', 'Northwest Territories');
INSERT INTO `directory_country_region` VALUES(73, 'CA', 'NU', 'Nunavut');
INSERT INTO `directory_country_region` VALUES(74, 'CA', 'ON', 'Ontario');
INSERT INTO `directory_country_region` VALUES(75, 'CA', 'PE', 'Prince Edward Island');
INSERT INTO `directory_country_region` VALUES(76, 'CA', 'QC', 'Quebec');
INSERT INTO `directory_country_region` VALUES(77, 'CA', 'SK', 'Saskatchewan');
INSERT INTO `directory_country_region` VALUES(78, 'CA', 'YT', 'Yukon Territory');
INSERT INTO `directory_country_region` VALUES(79, 'DE', 'NDS', 'Niedersachsen');
INSERT INTO `directory_country_region` VALUES(80, 'DE', 'BAW', 'Baden-Württemberg');
INSERT INTO `directory_country_region` VALUES(81, 'DE', 'BAY', 'Bayern');
INSERT INTO `directory_country_region` VALUES(82, 'DE', 'BER', 'Berlin');
INSERT INTO `directory_country_region` VALUES(83, 'DE', 'BRG', 'Brandenburg');
INSERT INTO `directory_country_region` VALUES(84, 'DE', 'BRE', 'Bremen');
INSERT INTO `directory_country_region` VALUES(85, 'DE', 'HAM', 'Hamburg');
INSERT INTO `directory_country_region` VALUES(86, 'DE', 'HES', 'Hessen');
INSERT INTO `directory_country_region` VALUES(87, 'DE', 'MEC', 'Mecklenburg-Vorpommern');
INSERT INTO `directory_country_region` VALUES(88, 'DE', 'NRW', 'Nordrhein-Westfalen');
INSERT INTO `directory_country_region` VALUES(89, 'DE', 'RHE', 'Rheinland-Pfalz');
INSERT INTO `directory_country_region` VALUES(90, 'DE', 'SAR', 'Saarland');
INSERT INTO `directory_country_region` VALUES(91, 'DE', 'SAS', 'Sachsen');
INSERT INTO `directory_country_region` VALUES(92, 'DE', 'SAC', 'Sachsen-Anhalt');
INSERT INTO `directory_country_region` VALUES(93, 'DE', 'SCN', 'Schleswig-Holstein');
INSERT INTO `directory_country_region` VALUES(94, 'DE', 'THE', 'Thüringen');
INSERT INTO `directory_country_region` VALUES(95, 'AT', 'WI', 'Wien');
INSERT INTO `directory_country_region` VALUES(96, 'AT', 'NO', 'Niederösterreich');
INSERT INTO `directory_country_region` VALUES(97, 'AT', 'OO', 'Oberösterreich');
INSERT INTO `directory_country_region` VALUES(98, 'AT', 'SB', 'Salzburg');
INSERT INTO `directory_country_region` VALUES(99, 'AT', 'KN', 'Kärnten');
INSERT INTO `directory_country_region` VALUES(100, 'AT', 'ST', 'Steiermark');
INSERT INTO `directory_country_region` VALUES(101, 'AT', 'TI', 'Tirol');
INSERT INTO `directory_country_region` VALUES(102, 'AT', 'BL', 'Burgenland');
INSERT INTO `directory_country_region` VALUES(103, 'AT', 'VB', 'Voralberg');
INSERT INTO `directory_country_region` VALUES(104, 'CH', 'AG', 'Aargau');
INSERT INTO `directory_country_region` VALUES(105, 'CH', 'AI', 'Appenzell Innerrhoden');
INSERT INTO `directory_country_region` VALUES(106, 'CH', 'AR', 'Appenzell Ausserrhoden');
INSERT INTO `directory_country_region` VALUES(107, 'CH', 'BE', 'Bern');
INSERT INTO `directory_country_region` VALUES(108, 'CH', 'BL', 'Basel-Landschaft');
INSERT INTO `directory_country_region` VALUES(109, 'CH', 'BS', 'Basel-Stadt');
INSERT INTO `directory_country_region` VALUES(110, 'CH', 'FR', 'Freiburg');
INSERT INTO `directory_country_region` VALUES(111, 'CH', 'GE', 'Genf');
INSERT INTO `directory_country_region` VALUES(112, 'CH', 'GL', 'Glarus');
INSERT INTO `directory_country_region` VALUES(113, 'CH', 'GR', 'Graubünden');
INSERT INTO `directory_country_region` VALUES(114, 'CH', 'JU', 'Jura');
INSERT INTO `directory_country_region` VALUES(115, 'CH', 'LU', 'Luzern');
INSERT INTO `directory_country_region` VALUES(116, 'CH', 'NE', 'Neuenburg');
INSERT INTO `directory_country_region` VALUES(117, 'CH', 'NW', 'Nidwalden');
INSERT INTO `directory_country_region` VALUES(118, 'CH', 'OW', 'Obwalden');
INSERT INTO `directory_country_region` VALUES(119, 'CH', 'SG', 'St. Gallen');
INSERT INTO `directory_country_region` VALUES(120, 'CH', 'SH', 'Schaffhausen');
INSERT INTO `directory_country_region` VALUES(121, 'CH', 'SO', 'Solothurn');
INSERT INTO `directory_country_region` VALUES(122, 'CH', 'SZ', 'Schwyz');
INSERT INTO `directory_country_region` VALUES(123, 'CH', 'TG', 'Thurgau');
INSERT INTO `directory_country_region` VALUES(124, 'CH', 'TI', 'Tessin');
INSERT INTO `directory_country_region` VALUES(125, 'CH', 'UR', 'Uri');
INSERT INTO `directory_country_region` VALUES(126, 'CH', 'VD', 'Waadt');
INSERT INTO `directory_country_region` VALUES(127, 'CH', 'VS', 'Wallis');
INSERT INTO `directory_country_region` VALUES(128, 'CH', 'ZG', 'Zug');
INSERT INTO `directory_country_region` VALUES(129, 'CH', 'ZH', 'Zürich');
INSERT INTO `directory_country_region` VALUES(130, 'ES', 'A Coruсa', 'A Coruña');
INSERT INTO `directory_country_region` VALUES(131, 'ES', 'Alava', 'Alava');
INSERT INTO `directory_country_region` VALUES(132, 'ES', 'Albacete', 'Albacete');
INSERT INTO `directory_country_region` VALUES(133, 'ES', 'Alicante', 'Alicante');
INSERT INTO `directory_country_region` VALUES(134, 'ES', 'Almeria', 'Almeria');
INSERT INTO `directory_country_region` VALUES(135, 'ES', 'Asturias', 'Asturias');
INSERT INTO `directory_country_region` VALUES(136, 'ES', 'Avila', 'Avila');
INSERT INTO `directory_country_region` VALUES(137, 'ES', 'Badajoz', 'Badajoz');
INSERT INTO `directory_country_region` VALUES(138, 'ES', 'Baleares', 'Baleares');
INSERT INTO `directory_country_region` VALUES(139, 'ES', 'Barcelona', 'Barcelona');
INSERT INTO `directory_country_region` VALUES(140, 'ES', 'Burgos', 'Burgos');
INSERT INTO `directory_country_region` VALUES(141, 'ES', 'Caceres', 'Caceres');
INSERT INTO `directory_country_region` VALUES(142, 'ES', 'Cadiz', 'Cadiz');
INSERT INTO `directory_country_region` VALUES(143, 'ES', 'Cantabria', 'Cantabria');
INSERT INTO `directory_country_region` VALUES(144, 'ES', 'Castellon', 'Castellon');
INSERT INTO `directory_country_region` VALUES(145, 'ES', 'Ceuta', 'Ceuta');
INSERT INTO `directory_country_region` VALUES(146, 'ES', 'Ciudad Real', 'Ciudad Real');
INSERT INTO `directory_country_region` VALUES(147, 'ES', 'Cordoba', 'Cordoba');
INSERT INTO `directory_country_region` VALUES(148, 'ES', 'Cuenca', 'Cuenca');
INSERT INTO `directory_country_region` VALUES(149, 'ES', 'Girona', 'Girona');
INSERT INTO `directory_country_region` VALUES(150, 'ES', 'Granada', 'Granada');
INSERT INTO `directory_country_region` VALUES(151, 'ES', 'Guadalajara', 'Guadalajara');
INSERT INTO `directory_country_region` VALUES(152, 'ES', 'Guipuzcoa', 'Guipuzcoa');
INSERT INTO `directory_country_region` VALUES(153, 'ES', 'Huelva', 'Huelva');
INSERT INTO `directory_country_region` VALUES(154, 'ES', 'Huesca', 'Huesca');
INSERT INTO `directory_country_region` VALUES(155, 'ES', 'Jaen', 'Jaen');
INSERT INTO `directory_country_region` VALUES(156, 'ES', 'La Rioja', 'La Rioja');
INSERT INTO `directory_country_region` VALUES(157, 'ES', 'Las Palmas', 'Las Palmas');
INSERT INTO `directory_country_region` VALUES(158, 'ES', 'Leon', 'Leon');
INSERT INTO `directory_country_region` VALUES(159, 'ES', 'Lleida', 'Lleida');
INSERT INTO `directory_country_region` VALUES(160, 'ES', 'Lugo', 'Lugo');
INSERT INTO `directory_country_region` VALUES(161, 'ES', 'Madrid', 'Madrid');
INSERT INTO `directory_country_region` VALUES(162, 'ES', 'Malaga', 'Malaga');
INSERT INTO `directory_country_region` VALUES(163, 'ES', 'Melilla', 'Melilla');
INSERT INTO `directory_country_region` VALUES(164, 'ES', 'Murcia', 'Murcia');
INSERT INTO `directory_country_region` VALUES(165, 'ES', 'Navarra', 'Navarra');
INSERT INTO `directory_country_region` VALUES(166, 'ES', 'Ourense', 'Ourense');
INSERT INTO `directory_country_region` VALUES(167, 'ES', 'Palencia', 'Palencia');
INSERT INTO `directory_country_region` VALUES(168, 'ES', 'Pontevedra', 'Pontevedra');
INSERT INTO `directory_country_region` VALUES(169, 'ES', 'Salamanca', 'Salamanca');
INSERT INTO `directory_country_region` VALUES(170, 'ES', 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife');
INSERT INTO `directory_country_region` VALUES(171, 'ES', 'Segovia', 'Segovia');
INSERT INTO `directory_country_region` VALUES(172, 'ES', 'Sevilla', 'Sevilla');
INSERT INTO `directory_country_region` VALUES(173, 'ES', 'Soria', 'Soria');
INSERT INTO `directory_country_region` VALUES(174, 'ES', 'Tarragona', 'Tarragona');
INSERT INTO `directory_country_region` VALUES(175, 'ES', 'Teruel', 'Teruel');
INSERT INTO `directory_country_region` VALUES(176, 'ES', 'Toledo', 'Toledo');
INSERT INTO `directory_country_region` VALUES(177, 'ES', 'Valencia', 'Valencia');
INSERT INTO `directory_country_region` VALUES(178, 'ES', 'Valladolid', 'Valladolid');
INSERT INTO `directory_country_region` VALUES(179, 'ES', 'Vizcaya', 'Vizcaya');
INSERT INTO `directory_country_region` VALUES(180, 'ES', 'Zamora', 'Zamora');
INSERT INTO `directory_country_region` VALUES(181, 'ES', 'Zaragoza', 'Zaragoza');
INSERT INTO `directory_country_region` VALUES(182, 'FR', '01', 'Ain');
INSERT INTO `directory_country_region` VALUES(183, 'FR', '02', 'Aisne');
INSERT INTO `directory_country_region` VALUES(184, 'FR', '03', 'Allier');
INSERT INTO `directory_country_region` VALUES(185, 'FR', '04', 'Alpes-de-Haute-Provence');
INSERT INTO `directory_country_region` VALUES(186, 'FR', '05', 'Hautes-Alpes');
INSERT INTO `directory_country_region` VALUES(187, 'FR', '06', 'Alpes-Maritimes');
INSERT INTO `directory_country_region` VALUES(188, 'FR', '07', 'Ardèche');
INSERT INTO `directory_country_region` VALUES(189, 'FR', '08', 'Ardennes');
INSERT INTO `directory_country_region` VALUES(190, 'FR', '09', 'Ariège');
INSERT INTO `directory_country_region` VALUES(191, 'FR', '10', 'Aube');
INSERT INTO `directory_country_region` VALUES(192, 'FR', '11', 'Aude');
INSERT INTO `directory_country_region` VALUES(193, 'FR', '12', 'Aveyron');
INSERT INTO `directory_country_region` VALUES(194, 'FR', '13', 'Bouches-du-Rhône');
INSERT INTO `directory_country_region` VALUES(195, 'FR', '14', 'Calvados');
INSERT INTO `directory_country_region` VALUES(196, 'FR', '15', 'Cantal');
INSERT INTO `directory_country_region` VALUES(197, 'FR', '16', 'Charente');
INSERT INTO `directory_country_region` VALUES(198, 'FR', '17', 'Charente-Maritime');
INSERT INTO `directory_country_region` VALUES(199, 'FR', '18', 'Cher');
INSERT INTO `directory_country_region` VALUES(200, 'FR', '19', 'Corrèze');
INSERT INTO `directory_country_region` VALUES(201, 'FR', '2A', 'Corse-du-Sud');
INSERT INTO `directory_country_region` VALUES(202, 'FR', '2B', 'Haute-Corse');
INSERT INTO `directory_country_region` VALUES(203, 'FR', '21', 'Côte-d''Or');
INSERT INTO `directory_country_region` VALUES(204, 'FR', '22', 'Côtes-d''Armor');
INSERT INTO `directory_country_region` VALUES(205, 'FR', '23', 'Creuse');
INSERT INTO `directory_country_region` VALUES(206, 'FR', '24', 'Dordogne');
INSERT INTO `directory_country_region` VALUES(207, 'FR', '25', 'Doubs');
INSERT INTO `directory_country_region` VALUES(208, 'FR', '26', 'Drôme');
INSERT INTO `directory_country_region` VALUES(209, 'FR', '27', 'Eure');
INSERT INTO `directory_country_region` VALUES(210, 'FR', '28', 'Eure-et-Loir');
INSERT INTO `directory_country_region` VALUES(211, 'FR', '29', 'Finistère');
INSERT INTO `directory_country_region` VALUES(212, 'FR', '30', 'Gard');
INSERT INTO `directory_country_region` VALUES(213, 'FR', '31', 'Haute-Garonne');
INSERT INTO `directory_country_region` VALUES(214, 'FR', '32', 'Gers');
INSERT INTO `directory_country_region` VALUES(215, 'FR', '33', 'Gironde');
INSERT INTO `directory_country_region` VALUES(216, 'FR', '34', 'Hérault');
INSERT INTO `directory_country_region` VALUES(217, 'FR', '35', 'Ille-et-Vilaine');
INSERT INTO `directory_country_region` VALUES(218, 'FR', '36', 'Indre');
INSERT INTO `directory_country_region` VALUES(219, 'FR', '37', 'Indre-et-Loire');
INSERT INTO `directory_country_region` VALUES(220, 'FR', '38', 'Isère');
INSERT INTO `directory_country_region` VALUES(221, 'FR', '39', 'Jura');
INSERT INTO `directory_country_region` VALUES(222, 'FR', '40', 'Landes');
INSERT INTO `directory_country_region` VALUES(223, 'FR', '41', 'Loir-et-Cher');
INSERT INTO `directory_country_region` VALUES(224, 'FR', '42', 'Loire');
INSERT INTO `directory_country_region` VALUES(225, 'FR', '43', 'Haute-Loire');
INSERT INTO `directory_country_region` VALUES(226, 'FR', '44', 'Loire-Atlantique');
INSERT INTO `directory_country_region` VALUES(227, 'FR', '45', 'Loiret');
INSERT INTO `directory_country_region` VALUES(228, 'FR', '46', 'Lot');
INSERT INTO `directory_country_region` VALUES(229, 'FR', '47', 'Lot-et-Garonne');
INSERT INTO `directory_country_region` VALUES(230, 'FR', '48', 'Lozère');
INSERT INTO `directory_country_region` VALUES(231, 'FR', '49', 'Maine-et-Loire');
INSERT INTO `directory_country_region` VALUES(232, 'FR', '50', 'Manche');
INSERT INTO `directory_country_region` VALUES(233, 'FR', '51', 'Marne');
INSERT INTO `directory_country_region` VALUES(234, 'FR', '52', 'Haute-Marne');
INSERT INTO `directory_country_region` VALUES(235, 'FR', '53', 'Mayenne');
INSERT INTO `directory_country_region` VALUES(236, 'FR', '54', 'Meurthe-et-Moselle');
INSERT INTO `directory_country_region` VALUES(237, 'FR', '55', 'Meuse');
INSERT INTO `directory_country_region` VALUES(238, 'FR', '56', 'Morbihan');
INSERT INTO `directory_country_region` VALUES(239, 'FR', '57', 'Moselle');
INSERT INTO `directory_country_region` VALUES(240, 'FR', '58', 'Nièvre');
INSERT INTO `directory_country_region` VALUES(241, 'FR', '59', 'Nord');
INSERT INTO `directory_country_region` VALUES(242, 'FR', '60', 'Oise');
INSERT INTO `directory_country_region` VALUES(243, 'FR', '61', 'Orne');
INSERT INTO `directory_country_region` VALUES(244, 'FR', '62', 'Pas-de-Calais');
INSERT INTO `directory_country_region` VALUES(245, 'FR', '63', 'Puy-de-Dôme');
INSERT INTO `directory_country_region` VALUES(246, 'FR', '64', 'Pyrénées-Atlantiques');
INSERT INTO `directory_country_region` VALUES(247, 'FR', '65', 'Hautes-Pyrénées');
INSERT INTO `directory_country_region` VALUES(248, 'FR', '66', 'Pyrénées-Orientales');
INSERT INTO `directory_country_region` VALUES(249, 'FR', '67', 'Bas-Rhin');
INSERT INTO `directory_country_region` VALUES(250, 'FR', '68', 'Haut-Rhin');
INSERT INTO `directory_country_region` VALUES(251, 'FR', '69', 'Rhône');
INSERT INTO `directory_country_region` VALUES(252, 'FR', '70', 'Haute-Saône');
INSERT INTO `directory_country_region` VALUES(253, 'FR', '71', 'Saône-et-Loire');
INSERT INTO `directory_country_region` VALUES(254, 'FR', '72', 'Sarthe');
INSERT INTO `directory_country_region` VALUES(255, 'FR', '73', 'Savoie');
INSERT INTO `directory_country_region` VALUES(256, 'FR', '74', 'Haute-Savoie');
INSERT INTO `directory_country_region` VALUES(257, 'FR', '75', 'Paris');
INSERT INTO `directory_country_region` VALUES(258, 'FR', '76', 'Seine-Maritime');
INSERT INTO `directory_country_region` VALUES(259, 'FR', '77', 'Seine-et-Marne');
INSERT INTO `directory_country_region` VALUES(260, 'FR', '78', 'Yvelines');
INSERT INTO `directory_country_region` VALUES(261, 'FR', '79', 'Deux-Sèvres');
INSERT INTO `directory_country_region` VALUES(262, 'FR', '80', 'Somme');
INSERT INTO `directory_country_region` VALUES(263, 'FR', '81', 'Tarn');
INSERT INTO `directory_country_region` VALUES(264, 'FR', '82', 'Tarn-et-Garonne');
INSERT INTO `directory_country_region` VALUES(265, 'FR', '83', 'Var');
INSERT INTO `directory_country_region` VALUES(266, 'FR', '84', 'Vaucluse');
INSERT INTO `directory_country_region` VALUES(267, 'FR', '85', 'Vendée');
INSERT INTO `directory_country_region` VALUES(268, 'FR', '86', 'Vienne');
INSERT INTO `directory_country_region` VALUES(269, 'FR', '87', 'Haute-Vienne');
INSERT INTO `directory_country_region` VALUES(270, 'FR', '88', 'Vosges');
INSERT INTO `directory_country_region` VALUES(271, 'FR', '89', 'Yonne');
INSERT INTO `directory_country_region` VALUES(272, 'FR', '90', 'Territoire-de-Belfort');
INSERT INTO `directory_country_region` VALUES(273, 'FR', '91', 'Essonne');
INSERT INTO `directory_country_region` VALUES(274, 'FR', '92', 'Hauts-de-Seine');
INSERT INTO `directory_country_region` VALUES(275, 'FR', '93', 'Seine-Saint-Denis');
INSERT INTO `directory_country_region` VALUES(276, 'FR', '94', 'Val-de-Marne');
INSERT INTO `directory_country_region` VALUES(277, 'FR', '95', 'Val-d''Oise');
INSERT INTO `directory_country_region` VALUES(278, 'RO', 'AB', 'Alba');
INSERT INTO `directory_country_region` VALUES(279, 'RO', 'AR', 'Arad');
INSERT INTO `directory_country_region` VALUES(280, 'RO', 'AG', 'Argeş');
INSERT INTO `directory_country_region` VALUES(281, 'RO', 'BC', 'Bacău');
INSERT INTO `directory_country_region` VALUES(282, 'RO', 'BH', 'Bihor');
INSERT INTO `directory_country_region` VALUES(283, 'RO', 'BN', 'Bistriţa-Năsăud');
INSERT INTO `directory_country_region` VALUES(284, 'RO', 'BT', 'Botoşani');
INSERT INTO `directory_country_region` VALUES(285, 'RO', 'BV', 'Braşov');
INSERT INTO `directory_country_region` VALUES(286, 'RO', 'BR', 'Brăila');
INSERT INTO `directory_country_region` VALUES(287, 'RO', 'B', 'Bucureşti');
INSERT INTO `directory_country_region` VALUES(288, 'RO', 'BZ', 'Buzău');
INSERT INTO `directory_country_region` VALUES(289, 'RO', 'CS', 'Caraş-Severin');
INSERT INTO `directory_country_region` VALUES(290, 'RO', 'CL', 'Călăraşi');
INSERT INTO `directory_country_region` VALUES(291, 'RO', 'CJ', 'Cluj');
INSERT INTO `directory_country_region` VALUES(292, 'RO', 'CT', 'Constanţa');
INSERT INTO `directory_country_region` VALUES(293, 'RO', 'CV', 'Covasna');
INSERT INTO `directory_country_region` VALUES(294, 'RO', 'DB', 'Dâmboviţa');
INSERT INTO `directory_country_region` VALUES(295, 'RO', 'DJ', 'Dolj');
INSERT INTO `directory_country_region` VALUES(296, 'RO', 'GL', 'Galaţi');
INSERT INTO `directory_country_region` VALUES(297, 'RO', 'GR', 'Giurgiu');
INSERT INTO `directory_country_region` VALUES(298, 'RO', 'GJ', 'Gorj');
INSERT INTO `directory_country_region` VALUES(299, 'RO', 'HR', 'Harghita');
INSERT INTO `directory_country_region` VALUES(300, 'RO', 'HD', 'Hunedoara');
INSERT INTO `directory_country_region` VALUES(301, 'RO', 'IL', 'Ialomiţa');
INSERT INTO `directory_country_region` VALUES(302, 'RO', 'IS', 'Iaşi');
INSERT INTO `directory_country_region` VALUES(303, 'RO', 'IF', 'Ilfov');
INSERT INTO `directory_country_region` VALUES(304, 'RO', 'MM', 'Maramureş');
INSERT INTO `directory_country_region` VALUES(305, 'RO', 'MH', 'Mehedinţi');
INSERT INTO `directory_country_region` VALUES(306, 'RO', 'MS', 'Mureş');
INSERT INTO `directory_country_region` VALUES(307, 'RO', 'NT', 'Neamţ');
INSERT INTO `directory_country_region` VALUES(308, 'RO', 'OT', 'Olt');
INSERT INTO `directory_country_region` VALUES(309, 'RO', 'PH', 'Prahova');
INSERT INTO `directory_country_region` VALUES(310, 'RO', 'SM', 'Satu-Mare');
INSERT INTO `directory_country_region` VALUES(311, 'RO', 'SJ', 'Sălaj');
INSERT INTO `directory_country_region` VALUES(312, 'RO', 'SB', 'Sibiu');
INSERT INTO `directory_country_region` VALUES(313, 'RO', 'SV', 'Suceava');
INSERT INTO `directory_country_region` VALUES(314, 'RO', 'TR', 'Teleorman');
INSERT INTO `directory_country_region` VALUES(315, 'RO', 'TM', 'Timiş');
INSERT INTO `directory_country_region` VALUES(316, 'RO', 'TL', 'Tulcea');
INSERT INTO `directory_country_region` VALUES(317, 'RO', 'VS', 'Vaslui');
INSERT INTO `directory_country_region` VALUES(318, 'RO', 'VL', 'Vâlcea');
INSERT INTO `directory_country_region` VALUES(319, 'RO', 'VN', 'Vrancea');
INSERT INTO `directory_country_region` VALUES(320, 'FI', 'Lappi', 'Lappi');
INSERT INTO `directory_country_region` VALUES(321, 'FI', 'Pohjois-Pohjanmaa', 'Pohjois-Pohjanmaa');
INSERT INTO `directory_country_region` VALUES(322, 'FI', 'Kainuu', 'Kainuu');
INSERT INTO `directory_country_region` VALUES(323, 'FI', 'Pohjois-Karjala', 'Pohjois-Karjala');
INSERT INTO `directory_country_region` VALUES(324, 'FI', 'Pohjois-Savo', 'Pohjois-Savo');
INSERT INTO `directory_country_region` VALUES(325, 'FI', 'Etelä-Savo', 'Etelä-Savo');
INSERT INTO `directory_country_region` VALUES(326, 'FI', 'Etelä-Pohjanmaa', 'Etelä-Pohjanmaa');
INSERT INTO `directory_country_region` VALUES(327, 'FI', 'Pohjanmaa', 'Pohjanmaa');
INSERT INTO `directory_country_region` VALUES(328, 'FI', 'Pirkanmaa', 'Pirkanmaa');
INSERT INTO `directory_country_region` VALUES(329, 'FI', 'Satakunta', 'Satakunta');
INSERT INTO `directory_country_region` VALUES(330, 'FI', 'Keski-Pohjanmaa', 'Keski-Pohjanmaa');
INSERT INTO `directory_country_region` VALUES(331, 'FI', 'Keski-Suomi', 'Keski-Suomi');
INSERT INTO `directory_country_region` VALUES(332, 'FI', 'Varsinais-Suomi', 'Varsinais-Suomi');
INSERT INTO `directory_country_region` VALUES(333, 'FI', 'Etelä-Karjala', 'Etelä-Karjala');
INSERT INTO `directory_country_region` VALUES(334, 'FI', 'Päijät-Häme', 'Päijät-Häme');
INSERT INTO `directory_country_region` VALUES(335, 'FI', 'Kanta-Häme', 'Kanta-Häme');
INSERT INTO `directory_country_region` VALUES(336, 'FI', 'Uusimaa', 'Uusimaa');
INSERT INTO `directory_country_region` VALUES(337, 'FI', 'Itä-Uusimaa', 'Itä-Uusimaa');
INSERT INTO `directory_country_region` VALUES(338, 'FI', 'Kymenlaakso', 'Kymenlaakso');
INSERT INTO `directory_country_region` VALUES(339, 'FI', 'Ahvenanmaa', 'Ahvenanmaa');
INSERT INTO `directory_country_region` VALUES(340, 'EE', 'EE-37', 'Harjumaa');
INSERT INTO `directory_country_region` VALUES(341, 'EE', 'EE-39', 'Hiiumaa');
INSERT INTO `directory_country_region` VALUES(342, 'EE', 'EE-44', 'Ida-Virumaa');
INSERT INTO `directory_country_region` VALUES(343, 'EE', 'EE-49', 'Jõgevamaa');
INSERT INTO `directory_country_region` VALUES(344, 'EE', 'EE-51', 'Järvamaa');
INSERT INTO `directory_country_region` VALUES(345, 'EE', 'EE-57', 'Läänemaa');
INSERT INTO `directory_country_region` VALUES(346, 'EE', 'EE-59', 'Lääne-Virumaa');
INSERT INTO `directory_country_region` VALUES(347, 'EE', 'EE-65', 'Põlvamaa');
INSERT INTO `directory_country_region` VALUES(348, 'EE', 'EE-67', 'Pärnumaa');
INSERT INTO `directory_country_region` VALUES(349, 'EE', 'EE-70', 'Raplamaa');
INSERT INTO `directory_country_region` VALUES(350, 'EE', 'EE-74', 'Saaremaa');
INSERT INTO `directory_country_region` VALUES(351, 'EE', 'EE-78', 'Tartumaa');
INSERT INTO `directory_country_region` VALUES(352, 'EE', 'EE-82', 'Valgamaa');
INSERT INTO `directory_country_region` VALUES(353, 'EE', 'EE-84', 'Viljandimaa');
INSERT INTO `directory_country_region` VALUES(354, 'EE', 'EE-86', 'Võrumaa');
INSERT INTO `directory_country_region` VALUES(355, 'LV', 'LV-DGV', 'Daugavpils');
INSERT INTO `directory_country_region` VALUES(356, 'LV', 'LV-JEL', 'Jelgava');
INSERT INTO `directory_country_region` VALUES(357, 'LV', 'Jēkabpils', 'Jēkabpils');
INSERT INTO `directory_country_region` VALUES(358, 'LV', 'LV-JUR', 'Jūrmala');
INSERT INTO `directory_country_region` VALUES(359, 'LV', 'LV-LPX', 'Liepāja');
INSERT INTO `directory_country_region` VALUES(360, 'LV', 'LV-LE', 'Liepājas novads');
INSERT INTO `directory_country_region` VALUES(361, 'LV', 'LV-REZ', 'Rēzekne');
INSERT INTO `directory_country_region` VALUES(362, 'LV', 'LV-RIX', 'Rīga');
INSERT INTO `directory_country_region` VALUES(363, 'LV', 'LV-RI', 'Rīgas novads');
INSERT INTO `directory_country_region` VALUES(364, 'LV', 'Valmiera', 'Valmiera');
INSERT INTO `directory_country_region` VALUES(365, 'LV', 'LV-VEN', 'Ventspils');
INSERT INTO `directory_country_region` VALUES(366, 'LV', 'Aglonas novads', 'Aglonas novads');
INSERT INTO `directory_country_region` VALUES(367, 'LV', 'LV-AI', 'Aizkraukles novads');
INSERT INTO `directory_country_region` VALUES(368, 'LV', 'Aizputes novads', 'Aizputes novads');
INSERT INTO `directory_country_region` VALUES(369, 'LV', 'Aknīstes novads', 'Aknīstes novads');
INSERT INTO `directory_country_region` VALUES(370, 'LV', 'Alojas novads', 'Alojas novads');
INSERT INTO `directory_country_region` VALUES(371, 'LV', 'Alsungas novads', 'Alsungas novads');
INSERT INTO `directory_country_region` VALUES(372, 'LV', 'LV-AL', 'Alūksnes novads');
INSERT INTO `directory_country_region` VALUES(373, 'LV', 'Amatas novads', 'Amatas novads');
INSERT INTO `directory_country_region` VALUES(374, 'LV', 'Apes novads', 'Apes novads');
INSERT INTO `directory_country_region` VALUES(375, 'LV', 'Auces novads', 'Auces novads');
INSERT INTO `directory_country_region` VALUES(376, 'LV', 'Babītes novads', 'Babītes novads');
INSERT INTO `directory_country_region` VALUES(377, 'LV', 'Baldones novads', 'Baldones novads');
INSERT INTO `directory_country_region` VALUES(378, 'LV', 'Baltinavas novads', 'Baltinavas novads');
INSERT INTO `directory_country_region` VALUES(379, 'LV', 'LV-BL', 'Balvu novads');
INSERT INTO `directory_country_region` VALUES(380, 'LV', 'LV-BU', 'Bauskas novads');
INSERT INTO `directory_country_region` VALUES(381, 'LV', 'Beverīnas novads', 'Beverīnas novads');
INSERT INTO `directory_country_region` VALUES(382, 'LV', 'Brocēnu novads', 'Brocēnu novads');
INSERT INTO `directory_country_region` VALUES(383, 'LV', 'Burtnieku novads', 'Burtnieku novads');
INSERT INTO `directory_country_region` VALUES(384, 'LV', 'Carnikavas novads', 'Carnikavas novads');
INSERT INTO `directory_country_region` VALUES(385, 'LV', 'Cesvaines novads', 'Cesvaines novads');
INSERT INTO `directory_country_region` VALUES(386, 'LV', 'Ciblas novads', 'Ciblas novads');
INSERT INTO `directory_country_region` VALUES(387, 'LV', 'LV-CE', 'Cēsu novads');
INSERT INTO `directory_country_region` VALUES(388, 'LV', 'Dagdas novads', 'Dagdas novads');
INSERT INTO `directory_country_region` VALUES(389, 'LV', 'LV-DA', 'Daugavpils novads');
INSERT INTO `directory_country_region` VALUES(390, 'LV', 'LV-DO', 'Dobeles novads');
INSERT INTO `directory_country_region` VALUES(391, 'LV', 'Dundagas novads', 'Dundagas novads');
INSERT INTO `directory_country_region` VALUES(392, 'LV', 'Durbes novads', 'Durbes novads');
INSERT INTO `directory_country_region` VALUES(393, 'LV', 'Engures novads', 'Engures novads');
INSERT INTO `directory_country_region` VALUES(394, 'LV', 'Garkalnes novads', 'Garkalnes novads');
INSERT INTO `directory_country_region` VALUES(395, 'LV', 'Grobiņas novads', 'Grobiņas novads');
INSERT INTO `directory_country_region` VALUES(396, 'LV', 'LV-GU', 'Gulbenes novads');
INSERT INTO `directory_country_region` VALUES(397, 'LV', 'Iecavas novads', 'Iecavas novads');
INSERT INTO `directory_country_region` VALUES(398, 'LV', 'Ikšķiles novads', 'Ikšķiles novads');
INSERT INTO `directory_country_region` VALUES(399, 'LV', 'Ilūkstes novads', 'Ilūkstes novads');
INSERT INTO `directory_country_region` VALUES(400, 'LV', 'Inčukalna novads', 'Inčukalna novads');
INSERT INTO `directory_country_region` VALUES(401, 'LV', 'Jaunjelgavas novads', 'Jaunjelgavas novads');
INSERT INTO `directory_country_region` VALUES(402, 'LV', 'Jaunpiebalgas novads', 'Jaunpiebalgas novads');
INSERT INTO `directory_country_region` VALUES(403, 'LV', 'Jaunpils novads', 'Jaunpils novads');
INSERT INTO `directory_country_region` VALUES(404, 'LV', 'LV-JL', 'Jelgavas novads');
INSERT INTO `directory_country_region` VALUES(405, 'LV', 'LV-JK', 'Jēkabpils novads');
INSERT INTO `directory_country_region` VALUES(406, 'LV', 'Kandavas novads', 'Kandavas novads');
INSERT INTO `directory_country_region` VALUES(407, 'LV', 'Kokneses novads', 'Kokneses novads');
INSERT INTO `directory_country_region` VALUES(408, 'LV', 'Krimuldas novads', 'Krimuldas novads');
INSERT INTO `directory_country_region` VALUES(409, 'LV', 'Krustpils novads', 'Krustpils novads');
INSERT INTO `directory_country_region` VALUES(410, 'LV', 'LV-KR', 'Krāslavas novads');
INSERT INTO `directory_country_region` VALUES(411, 'LV', 'LV-KU', 'Kuldīgas novads');
INSERT INTO `directory_country_region` VALUES(412, 'LV', 'Kārsavas novads', 'Kārsavas novads');
INSERT INTO `directory_country_region` VALUES(413, 'LV', 'Lielvārdes novads', 'Lielvārdes novads');
INSERT INTO `directory_country_region` VALUES(414, 'LV', 'LV-LM', 'Limbažu novads');
INSERT INTO `directory_country_region` VALUES(415, 'LV', 'Lubānas novads', 'Lubānas novads');
INSERT INTO `directory_country_region` VALUES(416, 'LV', 'LV-LU', 'Ludzas novads');
INSERT INTO `directory_country_region` VALUES(417, 'LV', 'Līgatnes novads', 'Līgatnes novads');
INSERT INTO `directory_country_region` VALUES(418, 'LV', 'Līvānu novads', 'Līvānu novads');
INSERT INTO `directory_country_region` VALUES(419, 'LV', 'LV-MA', 'Madonas novads');
INSERT INTO `directory_country_region` VALUES(420, 'LV', 'Mazsalacas novads', 'Mazsalacas novads');
INSERT INTO `directory_country_region` VALUES(421, 'LV', 'Mālpils novads', 'Mālpils novads');
INSERT INTO `directory_country_region` VALUES(422, 'LV', 'Mārupes novads', 'Mārupes novads');
INSERT INTO `directory_country_region` VALUES(423, 'LV', 'Naukšēnu novads', 'Naukšēnu novads');
INSERT INTO `directory_country_region` VALUES(424, 'LV', 'Neretas novads', 'Neretas novads');
INSERT INTO `directory_country_region` VALUES(425, 'LV', 'Nīcas novads', 'Nīcas novads');
INSERT INTO `directory_country_region` VALUES(426, 'LV', 'LV-OG', 'Ogres novads');
INSERT INTO `directory_country_region` VALUES(427, 'LV', 'Olaines novads', 'Olaines novads');
INSERT INTO `directory_country_region` VALUES(428, 'LV', 'Ozolnieku novads', 'Ozolnieku novads');
INSERT INTO `directory_country_region` VALUES(429, 'LV', 'LV-PR', 'Preiļu novads');
INSERT INTO `directory_country_region` VALUES(430, 'LV', 'Priekules novads', 'Priekules novads');
INSERT INTO `directory_country_region` VALUES(431, 'LV', 'Priekuļu novads', 'Priekuļu novads');
INSERT INTO `directory_country_region` VALUES(432, 'LV', 'Pārgaujas novads', 'Pārgaujas novads');
INSERT INTO `directory_country_region` VALUES(433, 'LV', 'Pāvilostas novads', 'Pāvilostas novads');
INSERT INTO `directory_country_region` VALUES(434, 'LV', 'Pļaviņu novads', 'Pļaviņu novads');
INSERT INTO `directory_country_region` VALUES(435, 'LV', 'Raunas novads', 'Raunas novads');
INSERT INTO `directory_country_region` VALUES(436, 'LV', 'Riebiņu novads', 'Riebiņu novads');
INSERT INTO `directory_country_region` VALUES(437, 'LV', 'Rojas novads', 'Rojas novads');
INSERT INTO `directory_country_region` VALUES(438, 'LV', 'Ropažu novads', 'Ropažu novads');
INSERT INTO `directory_country_region` VALUES(439, 'LV', 'Rucavas novads', 'Rucavas novads');
INSERT INTO `directory_country_region` VALUES(440, 'LV', 'Rugāju novads', 'Rugāju novads');
INSERT INTO `directory_country_region` VALUES(441, 'LV', 'Rundāles novads', 'Rundāles novads');
INSERT INTO `directory_country_region` VALUES(442, 'LV', 'LV-RE', 'Rēzeknes novads');
INSERT INTO `directory_country_region` VALUES(443, 'LV', 'Rūjienas novads', 'Rūjienas novads');
INSERT INTO `directory_country_region` VALUES(444, 'LV', 'Salacgrīvas novads', 'Salacgrīvas novads');
INSERT INTO `directory_country_region` VALUES(445, 'LV', 'Salas novads', 'Salas novads');
INSERT INTO `directory_country_region` VALUES(446, 'LV', 'Salaspils novads', 'Salaspils novads');
INSERT INTO `directory_country_region` VALUES(447, 'LV', 'LV-SA', 'Saldus novads');
INSERT INTO `directory_country_region` VALUES(448, 'LV', 'Saulkrastu novads', 'Saulkrastu novads');
INSERT INTO `directory_country_region` VALUES(449, 'LV', 'Siguldas novads', 'Siguldas novads');
INSERT INTO `directory_country_region` VALUES(450, 'LV', 'Skrundas novads', 'Skrundas novads');
INSERT INTO `directory_country_region` VALUES(451, 'LV', 'Skrīveru novads', 'Skrīveru novads');
INSERT INTO `directory_country_region` VALUES(452, 'LV', 'Smiltenes novads', 'Smiltenes novads');
INSERT INTO `directory_country_region` VALUES(453, 'LV', 'Stopiņu novads', 'Stopiņu novads');
INSERT INTO `directory_country_region` VALUES(454, 'LV', 'Strenču novads', 'Strenču novads');
INSERT INTO `directory_country_region` VALUES(455, 'LV', 'Sējas novads', 'Sējas novads');
INSERT INTO `directory_country_region` VALUES(456, 'LV', 'LV-TA', 'Talsu novads');
INSERT INTO `directory_country_region` VALUES(457, 'LV', 'LV-TU', 'Tukuma novads');
INSERT INTO `directory_country_region` VALUES(458, 'LV', 'Tērvetes novads', 'Tērvetes novads');
INSERT INTO `directory_country_region` VALUES(459, 'LV', 'Vaiņodes novads', 'Vaiņodes novads');
INSERT INTO `directory_country_region` VALUES(460, 'LV', 'LV-VK', 'Valkas novads');
INSERT INTO `directory_country_region` VALUES(461, 'LV', 'LV-VM', 'Valmieras novads');
INSERT INTO `directory_country_region` VALUES(462, 'LV', 'Varakļānu novads', 'Varakļānu novads');
INSERT INTO `directory_country_region` VALUES(463, 'LV', 'Vecpiebalgas novads', 'Vecpiebalgas novads');
INSERT INTO `directory_country_region` VALUES(464, 'LV', 'Vecumnieku novads', 'Vecumnieku novads');
INSERT INTO `directory_country_region` VALUES(465, 'LV', 'LV-VE', 'Ventspils novads');
INSERT INTO `directory_country_region` VALUES(466, 'LV', 'Viesītes novads', 'Viesītes novads');
INSERT INTO `directory_country_region` VALUES(467, 'LV', 'Viļakas novads', 'Viļakas novads');
INSERT INTO `directory_country_region` VALUES(468, 'LV', 'Viļānu novads', 'Viļānu novads');
INSERT INTO `directory_country_region` VALUES(469, 'LV', 'Vārkavas novads', 'Vārkavas novads');
INSERT INTO `directory_country_region` VALUES(470, 'LV', 'Zilupes novads', 'Zilupes novads');
INSERT INTO `directory_country_region` VALUES(471, 'LV', 'Ādažu novads', 'Ādažu novads');
INSERT INTO `directory_country_region` VALUES(472, 'LV', 'Ērgļu novads', 'Ērgļu novads');
INSERT INTO `directory_country_region` VALUES(473, 'LV', 'Ķeguma novads', 'Ķeguma novads');
INSERT INTO `directory_country_region` VALUES(474, 'LV', 'Ķekavas novads', 'Ķekavas novads');
INSERT INTO `directory_country_region` VALUES(475, 'LT', 'LT-AL', 'Alytaus Apskritis');
INSERT INTO `directory_country_region` VALUES(476, 'LT', 'LT-KU', 'Kauno Apskritis');
INSERT INTO `directory_country_region` VALUES(477, 'LT', 'LT-KL', 'Klaipėdos Apskritis');
INSERT INTO `directory_country_region` VALUES(478, 'LT', 'LT-MR', 'Marijampolės Apskritis');
INSERT INTO `directory_country_region` VALUES(479, 'LT', 'LT-PN', 'Panevėžio Apskritis');
INSERT INTO `directory_country_region` VALUES(480, 'LT', 'LT-SA', 'Šiaulių Apskritis');
INSERT INTO `directory_country_region` VALUES(481, 'LT', 'LT-TA', 'Tauragės Apskritis');
INSERT INTO `directory_country_region` VALUES(482, 'LT', 'LT-TE', 'Telšių Apskritis');
INSERT INTO `directory_country_region` VALUES(483, 'LT', 'LT-UT', 'Utenos Apskritis');
INSERT INTO `directory_country_region` VALUES(484, 'LT', 'LT-VL', 'Vilniaus Apskritis');

-- --------------------------------------------------------

--
-- Table structure for table `directory_country_region_name`
--

CREATE TABLE `directory_country_region_name` (
  `locale` varchar(8) NOT NULL default '',
  `region_id` mediumint(8) unsigned NOT NULL default '0',
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`locale`,`region_id`),
  KEY `FK_DIRECTORY_REGION_NAME_REGION` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Regions names';

--
-- Dumping data for table `directory_country_region_name`
--

INSERT INTO `directory_country_region_name` VALUES('en_US', 1, 'Alabama');
INSERT INTO `directory_country_region_name` VALUES('en_US', 2, 'Alaska');
INSERT INTO `directory_country_region_name` VALUES('en_US', 3, 'American Samoa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 4, 'Arizona');
INSERT INTO `directory_country_region_name` VALUES('en_US', 5, 'Arkansas');
INSERT INTO `directory_country_region_name` VALUES('en_US', 6, 'Armed Forces Africa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 7, 'Armed Forces Americas');
INSERT INTO `directory_country_region_name` VALUES('en_US', 8, 'Armed Forces Canada');
INSERT INTO `directory_country_region_name` VALUES('en_US', 9, 'Armed Forces Europe');
INSERT INTO `directory_country_region_name` VALUES('en_US', 10, 'Armed Forces Middle East');
INSERT INTO `directory_country_region_name` VALUES('en_US', 11, 'Armed Forces Pacific');
INSERT INTO `directory_country_region_name` VALUES('en_US', 12, 'California');
INSERT INTO `directory_country_region_name` VALUES('en_US', 13, 'Colorado');
INSERT INTO `directory_country_region_name` VALUES('en_US', 14, 'Connecticut');
INSERT INTO `directory_country_region_name` VALUES('en_US', 15, 'Delaware');
INSERT INTO `directory_country_region_name` VALUES('en_US', 16, 'District of Columbia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 17, 'Federated States Of Micronesia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 18, 'Florida');
INSERT INTO `directory_country_region_name` VALUES('en_US', 19, 'Georgia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 20, 'Guam');
INSERT INTO `directory_country_region_name` VALUES('en_US', 21, 'Hawaii');
INSERT INTO `directory_country_region_name` VALUES('en_US', 22, 'Idaho');
INSERT INTO `directory_country_region_name` VALUES('en_US', 23, 'Illinois');
INSERT INTO `directory_country_region_name` VALUES('en_US', 24, 'Indiana');
INSERT INTO `directory_country_region_name` VALUES('en_US', 25, 'Iowa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 26, 'Kansas');
INSERT INTO `directory_country_region_name` VALUES('en_US', 27, 'Kentucky');
INSERT INTO `directory_country_region_name` VALUES('en_US', 28, 'Louisiana');
INSERT INTO `directory_country_region_name` VALUES('en_US', 29, 'Maine');
INSERT INTO `directory_country_region_name` VALUES('en_US', 30, 'Marshall Islands');
INSERT INTO `directory_country_region_name` VALUES('en_US', 31, 'Maryland');
INSERT INTO `directory_country_region_name` VALUES('en_US', 32, 'Massachusetts');
INSERT INTO `directory_country_region_name` VALUES('en_US', 33, 'Michigan');
INSERT INTO `directory_country_region_name` VALUES('en_US', 34, 'Minnesota');
INSERT INTO `directory_country_region_name` VALUES('en_US', 35, 'Mississippi');
INSERT INTO `directory_country_region_name` VALUES('en_US', 36, 'Missouri');
INSERT INTO `directory_country_region_name` VALUES('en_US', 37, 'Montana');
INSERT INTO `directory_country_region_name` VALUES('en_US', 38, 'Nebraska');
INSERT INTO `directory_country_region_name` VALUES('en_US', 39, 'Nevada');
INSERT INTO `directory_country_region_name` VALUES('en_US', 40, 'New Hampshire');
INSERT INTO `directory_country_region_name` VALUES('en_US', 41, 'New Jersey');
INSERT INTO `directory_country_region_name` VALUES('en_US', 42, 'New Mexico');
INSERT INTO `directory_country_region_name` VALUES('en_US', 43, 'New York');
INSERT INTO `directory_country_region_name` VALUES('en_US', 44, 'North Carolina');
INSERT INTO `directory_country_region_name` VALUES('en_US', 45, 'North Dakota');
INSERT INTO `directory_country_region_name` VALUES('en_US', 46, 'Northern Mariana Islands');
INSERT INTO `directory_country_region_name` VALUES('en_US', 47, 'Ohio');
INSERT INTO `directory_country_region_name` VALUES('en_US', 48, 'Oklahoma');
INSERT INTO `directory_country_region_name` VALUES('en_US', 49, 'Oregon');
INSERT INTO `directory_country_region_name` VALUES('en_US', 50, 'Palau');
INSERT INTO `directory_country_region_name` VALUES('en_US', 51, 'Pennsylvania');
INSERT INTO `directory_country_region_name` VALUES('en_US', 52, 'Puerto Rico');
INSERT INTO `directory_country_region_name` VALUES('en_US', 53, 'Rhode Island');
INSERT INTO `directory_country_region_name` VALUES('en_US', 54, 'South Carolina');
INSERT INTO `directory_country_region_name` VALUES('en_US', 55, 'South Dakota');
INSERT INTO `directory_country_region_name` VALUES('en_US', 56, 'Tennessee');
INSERT INTO `directory_country_region_name` VALUES('en_US', 57, 'Texas');
INSERT INTO `directory_country_region_name` VALUES('en_US', 58, 'Utah');
INSERT INTO `directory_country_region_name` VALUES('en_US', 59, 'Vermont');
INSERT INTO `directory_country_region_name` VALUES('en_US', 60, 'Virgin Islands');
INSERT INTO `directory_country_region_name` VALUES('en_US', 61, 'Virginia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 62, 'Washington');
INSERT INTO `directory_country_region_name` VALUES('en_US', 63, 'West Virginia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 64, 'Wisconsin');
INSERT INTO `directory_country_region_name` VALUES('en_US', 65, 'Wyoming');
INSERT INTO `directory_country_region_name` VALUES('en_US', 66, 'Alberta');
INSERT INTO `directory_country_region_name` VALUES('en_US', 67, 'British Columbia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 68, 'Manitoba');
INSERT INTO `directory_country_region_name` VALUES('en_US', 69, 'Newfoundland and Labrador');
INSERT INTO `directory_country_region_name` VALUES('en_US', 70, 'New Brunswick');
INSERT INTO `directory_country_region_name` VALUES('en_US', 71, 'Nova Scotia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 72, 'Northwest Territories');
INSERT INTO `directory_country_region_name` VALUES('en_US', 73, 'Nunavut');
INSERT INTO `directory_country_region_name` VALUES('en_US', 74, 'Ontario');
INSERT INTO `directory_country_region_name` VALUES('en_US', 75, 'Prince Edward Island');
INSERT INTO `directory_country_region_name` VALUES('en_US', 76, 'Quebec');
INSERT INTO `directory_country_region_name` VALUES('en_US', 77, 'Saskatchewan');
INSERT INTO `directory_country_region_name` VALUES('en_US', 78, 'Yukon Territory');
INSERT INTO `directory_country_region_name` VALUES('en_US', 79, 'Niedersachsen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 80, 'Baden-Württemberg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 81, 'Bayern');
INSERT INTO `directory_country_region_name` VALUES('en_US', 82, 'Berlin');
INSERT INTO `directory_country_region_name` VALUES('en_US', 83, 'Brandenburg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 84, 'Bremen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 85, 'Hamburg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 86, 'Hessen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 87, 'Mecklenburg-Vorpommern');
INSERT INTO `directory_country_region_name` VALUES('en_US', 88, 'Nordrhein-Westfalen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 89, 'Rheinland-Pfalz');
INSERT INTO `directory_country_region_name` VALUES('en_US', 90, 'Saarland');
INSERT INTO `directory_country_region_name` VALUES('en_US', 91, 'Sachsen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 92, 'Sachsen-Anhalt');
INSERT INTO `directory_country_region_name` VALUES('en_US', 93, 'Schleswig-Holstein');
INSERT INTO `directory_country_region_name` VALUES('en_US', 94, 'Thüringen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 95, 'Wien');
INSERT INTO `directory_country_region_name` VALUES('en_US', 96, 'Niederösterreich');
INSERT INTO `directory_country_region_name` VALUES('en_US', 97, 'Oberösterreich');
INSERT INTO `directory_country_region_name` VALUES('en_US', 98, 'Salzburg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 99, 'Kärnten');
INSERT INTO `directory_country_region_name` VALUES('en_US', 100, 'Steiermark');
INSERT INTO `directory_country_region_name` VALUES('en_US', 101, 'Tirol');
INSERT INTO `directory_country_region_name` VALUES('en_US', 102, 'Burgenland');
INSERT INTO `directory_country_region_name` VALUES('en_US', 103, 'Voralberg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 104, 'Aargau');
INSERT INTO `directory_country_region_name` VALUES('en_US', 105, 'Appenzell Innerrhoden');
INSERT INTO `directory_country_region_name` VALUES('en_US', 106, 'Appenzell Ausserrhoden');
INSERT INTO `directory_country_region_name` VALUES('en_US', 107, 'Bern');
INSERT INTO `directory_country_region_name` VALUES('en_US', 108, 'Basel-Landschaft');
INSERT INTO `directory_country_region_name` VALUES('en_US', 109, 'Basel-Stadt');
INSERT INTO `directory_country_region_name` VALUES('en_US', 110, 'Freiburg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 111, 'Genf');
INSERT INTO `directory_country_region_name` VALUES('en_US', 112, 'Glarus');
INSERT INTO `directory_country_region_name` VALUES('en_US', 113, 'Graubünden');
INSERT INTO `directory_country_region_name` VALUES('en_US', 114, 'Jura');
INSERT INTO `directory_country_region_name` VALUES('en_US', 115, 'Luzern');
INSERT INTO `directory_country_region_name` VALUES('en_US', 116, 'Neuenburg');
INSERT INTO `directory_country_region_name` VALUES('en_US', 117, 'Nidwalden');
INSERT INTO `directory_country_region_name` VALUES('en_US', 118, 'Obwalden');
INSERT INTO `directory_country_region_name` VALUES('en_US', 119, 'St. Gallen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 120, 'Schaffhausen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 121, 'Solothurn');
INSERT INTO `directory_country_region_name` VALUES('en_US', 122, 'Schwyz');
INSERT INTO `directory_country_region_name` VALUES('en_US', 123, 'Thurgau');
INSERT INTO `directory_country_region_name` VALUES('en_US', 124, 'Tessin');
INSERT INTO `directory_country_region_name` VALUES('en_US', 125, 'Uri');
INSERT INTO `directory_country_region_name` VALUES('en_US', 126, 'Waadt');
INSERT INTO `directory_country_region_name` VALUES('en_US', 127, 'Wallis');
INSERT INTO `directory_country_region_name` VALUES('en_US', 128, 'Zug');
INSERT INTO `directory_country_region_name` VALUES('en_US', 129, 'Zürich');
INSERT INTO `directory_country_region_name` VALUES('en_US', 130, 'A Coruña');
INSERT INTO `directory_country_region_name` VALUES('en_US', 131, 'Alava');
INSERT INTO `directory_country_region_name` VALUES('en_US', 132, 'Albacete');
INSERT INTO `directory_country_region_name` VALUES('en_US', 133, 'Alicante');
INSERT INTO `directory_country_region_name` VALUES('en_US', 134, 'Almeria');
INSERT INTO `directory_country_region_name` VALUES('en_US', 135, 'Asturias');
INSERT INTO `directory_country_region_name` VALUES('en_US', 136, 'Avila');
INSERT INTO `directory_country_region_name` VALUES('en_US', 137, 'Badajoz');
INSERT INTO `directory_country_region_name` VALUES('en_US', 138, 'Baleares');
INSERT INTO `directory_country_region_name` VALUES('en_US', 139, 'Barcelona');
INSERT INTO `directory_country_region_name` VALUES('en_US', 140, 'Burgos');
INSERT INTO `directory_country_region_name` VALUES('en_US', 141, 'Caceres');
INSERT INTO `directory_country_region_name` VALUES('en_US', 142, 'Cadiz');
INSERT INTO `directory_country_region_name` VALUES('en_US', 143, 'Cantabria');
INSERT INTO `directory_country_region_name` VALUES('en_US', 144, 'Castellon');
INSERT INTO `directory_country_region_name` VALUES('en_US', 145, 'Ceuta');
INSERT INTO `directory_country_region_name` VALUES('en_US', 146, 'Ciudad Real');
INSERT INTO `directory_country_region_name` VALUES('en_US', 147, 'Cordoba');
INSERT INTO `directory_country_region_name` VALUES('en_US', 148, 'Cuenca');
INSERT INTO `directory_country_region_name` VALUES('en_US', 149, 'Girona');
INSERT INTO `directory_country_region_name` VALUES('en_US', 150, 'Granada');
INSERT INTO `directory_country_region_name` VALUES('en_US', 151, 'Guadalajara');
INSERT INTO `directory_country_region_name` VALUES('en_US', 152, 'Guipuzcoa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 153, 'Huelva');
INSERT INTO `directory_country_region_name` VALUES('en_US', 154, 'Huesca');
INSERT INTO `directory_country_region_name` VALUES('en_US', 155, 'Jaen');
INSERT INTO `directory_country_region_name` VALUES('en_US', 156, 'La Rioja');
INSERT INTO `directory_country_region_name` VALUES('en_US', 157, 'Las Palmas');
INSERT INTO `directory_country_region_name` VALUES('en_US', 158, 'Leon');
INSERT INTO `directory_country_region_name` VALUES('en_US', 159, 'Lleida');
INSERT INTO `directory_country_region_name` VALUES('en_US', 160, 'Lugo');
INSERT INTO `directory_country_region_name` VALUES('en_US', 161, 'Madrid');
INSERT INTO `directory_country_region_name` VALUES('en_US', 162, 'Malaga');
INSERT INTO `directory_country_region_name` VALUES('en_US', 163, 'Melilla');
INSERT INTO `directory_country_region_name` VALUES('en_US', 164, 'Murcia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 165, 'Navarra');
INSERT INTO `directory_country_region_name` VALUES('en_US', 166, 'Ourense');
INSERT INTO `directory_country_region_name` VALUES('en_US', 167, 'Palencia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 168, 'Pontevedra');
INSERT INTO `directory_country_region_name` VALUES('en_US', 169, 'Salamanca');
INSERT INTO `directory_country_region_name` VALUES('en_US', 170, 'Santa Cruz de Tenerife');
INSERT INTO `directory_country_region_name` VALUES('en_US', 171, 'Segovia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 172, 'Sevilla');
INSERT INTO `directory_country_region_name` VALUES('en_US', 173, 'Soria');
INSERT INTO `directory_country_region_name` VALUES('en_US', 174, 'Tarragona');
INSERT INTO `directory_country_region_name` VALUES('en_US', 175, 'Teruel');
INSERT INTO `directory_country_region_name` VALUES('en_US', 176, 'Toledo');
INSERT INTO `directory_country_region_name` VALUES('en_US', 177, 'Valencia');
INSERT INTO `directory_country_region_name` VALUES('en_US', 178, 'Valladolid');
INSERT INTO `directory_country_region_name` VALUES('en_US', 179, 'Vizcaya');
INSERT INTO `directory_country_region_name` VALUES('en_US', 180, 'Zamora');
INSERT INTO `directory_country_region_name` VALUES('en_US', 181, 'Zaragoza');
INSERT INTO `directory_country_region_name` VALUES('en_US', 182, 'Ain');
INSERT INTO `directory_country_region_name` VALUES('en_US', 183, 'Aisne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 184, 'Allier');
INSERT INTO `directory_country_region_name` VALUES('en_US', 185, 'Alpes-de-Haute-Provence');
INSERT INTO `directory_country_region_name` VALUES('en_US', 186, 'Hautes-Alpes');
INSERT INTO `directory_country_region_name` VALUES('en_US', 187, 'Alpes-Maritimes');
INSERT INTO `directory_country_region_name` VALUES('en_US', 188, 'Ardèche');
INSERT INTO `directory_country_region_name` VALUES('en_US', 189, 'Ardennes');
INSERT INTO `directory_country_region_name` VALUES('en_US', 190, 'Ariège');
INSERT INTO `directory_country_region_name` VALUES('en_US', 191, 'Aube');
INSERT INTO `directory_country_region_name` VALUES('en_US', 192, 'Aude');
INSERT INTO `directory_country_region_name` VALUES('en_US', 193, 'Aveyron');
INSERT INTO `directory_country_region_name` VALUES('en_US', 194, 'Bouches-du-Rhône');
INSERT INTO `directory_country_region_name` VALUES('en_US', 195, 'Calvados');
INSERT INTO `directory_country_region_name` VALUES('en_US', 196, 'Cantal');
INSERT INTO `directory_country_region_name` VALUES('en_US', 197, 'Charente');
INSERT INTO `directory_country_region_name` VALUES('en_US', 198, 'Charente-Maritime');
INSERT INTO `directory_country_region_name` VALUES('en_US', 199, 'Cher');
INSERT INTO `directory_country_region_name` VALUES('en_US', 200, 'Corrèze');
INSERT INTO `directory_country_region_name` VALUES('en_US', 201, 'Corse-du-Sud');
INSERT INTO `directory_country_region_name` VALUES('en_US', 202, 'Haute-Corse');
INSERT INTO `directory_country_region_name` VALUES('en_US', 203, 'Côte-d''Or');
INSERT INTO `directory_country_region_name` VALUES('en_US', 204, 'Côtes-d''Armor');
INSERT INTO `directory_country_region_name` VALUES('en_US', 205, 'Creuse');
INSERT INTO `directory_country_region_name` VALUES('en_US', 206, 'Dordogne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 207, 'Doubs');
INSERT INTO `directory_country_region_name` VALUES('en_US', 208, 'Drôme');
INSERT INTO `directory_country_region_name` VALUES('en_US', 209, 'Eure');
INSERT INTO `directory_country_region_name` VALUES('en_US', 210, 'Eure-et-Loir');
INSERT INTO `directory_country_region_name` VALUES('en_US', 211, 'Finistère');
INSERT INTO `directory_country_region_name` VALUES('en_US', 212, 'Gard');
INSERT INTO `directory_country_region_name` VALUES('en_US', 213, 'Haute-Garonne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 214, 'Gers');
INSERT INTO `directory_country_region_name` VALUES('en_US', 215, 'Gironde');
INSERT INTO `directory_country_region_name` VALUES('en_US', 216, 'Hérault');
INSERT INTO `directory_country_region_name` VALUES('en_US', 217, 'Ille-et-Vilaine');
INSERT INTO `directory_country_region_name` VALUES('en_US', 218, 'Indre');
INSERT INTO `directory_country_region_name` VALUES('en_US', 219, 'Indre-et-Loire');
INSERT INTO `directory_country_region_name` VALUES('en_US', 220, 'Isère');
INSERT INTO `directory_country_region_name` VALUES('en_US', 221, 'Jura');
INSERT INTO `directory_country_region_name` VALUES('en_US', 222, 'Landes');
INSERT INTO `directory_country_region_name` VALUES('en_US', 223, 'Loir-et-Cher');
INSERT INTO `directory_country_region_name` VALUES('en_US', 224, 'Loire');
INSERT INTO `directory_country_region_name` VALUES('en_US', 225, 'Haute-Loire');
INSERT INTO `directory_country_region_name` VALUES('en_US', 226, 'Loire-Atlantique');
INSERT INTO `directory_country_region_name` VALUES('en_US', 227, 'Loiret');
INSERT INTO `directory_country_region_name` VALUES('en_US', 228, 'Lot');
INSERT INTO `directory_country_region_name` VALUES('en_US', 229, 'Lot-et-Garonne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 230, 'Lozère');
INSERT INTO `directory_country_region_name` VALUES('en_US', 231, 'Maine-et-Loire');
INSERT INTO `directory_country_region_name` VALUES('en_US', 232, 'Manche');
INSERT INTO `directory_country_region_name` VALUES('en_US', 233, 'Marne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 234, 'Haute-Marne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 235, 'Mayenne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 236, 'Meurthe-et-Moselle');
INSERT INTO `directory_country_region_name` VALUES('en_US', 237, 'Meuse');
INSERT INTO `directory_country_region_name` VALUES('en_US', 238, 'Morbihan');
INSERT INTO `directory_country_region_name` VALUES('en_US', 239, 'Moselle');
INSERT INTO `directory_country_region_name` VALUES('en_US', 240, 'Nièvre');
INSERT INTO `directory_country_region_name` VALUES('en_US', 241, 'Nord');
INSERT INTO `directory_country_region_name` VALUES('en_US', 242, 'Oise');
INSERT INTO `directory_country_region_name` VALUES('en_US', 243, 'Orne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 244, 'Pas-de-Calais');
INSERT INTO `directory_country_region_name` VALUES('en_US', 245, 'Puy-de-Dôme');
INSERT INTO `directory_country_region_name` VALUES('en_US', 246, 'Pyrénées-Atlantiques');
INSERT INTO `directory_country_region_name` VALUES('en_US', 247, 'Hautes-Pyrénées');
INSERT INTO `directory_country_region_name` VALUES('en_US', 248, 'Pyrénées-Orientales');
INSERT INTO `directory_country_region_name` VALUES('en_US', 249, 'Bas-Rhin');
INSERT INTO `directory_country_region_name` VALUES('en_US', 250, 'Haut-Rhin');
INSERT INTO `directory_country_region_name` VALUES('en_US', 251, 'Rhône');
INSERT INTO `directory_country_region_name` VALUES('en_US', 252, 'Haute-Saône');
INSERT INTO `directory_country_region_name` VALUES('en_US', 253, 'Saône-et-Loire');
INSERT INTO `directory_country_region_name` VALUES('en_US', 254, 'Sarthe');
INSERT INTO `directory_country_region_name` VALUES('en_US', 255, 'Savoie');
INSERT INTO `directory_country_region_name` VALUES('en_US', 256, 'Haute-Savoie');
INSERT INTO `directory_country_region_name` VALUES('en_US', 257, 'Paris');
INSERT INTO `directory_country_region_name` VALUES('en_US', 258, 'Seine-Maritime');
INSERT INTO `directory_country_region_name` VALUES('en_US', 259, 'Seine-et-Marne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 260, 'Yvelines');
INSERT INTO `directory_country_region_name` VALUES('en_US', 261, 'Deux-Sèvres');
INSERT INTO `directory_country_region_name` VALUES('en_US', 262, 'Somme');
INSERT INTO `directory_country_region_name` VALUES('en_US', 263, 'Tarn');
INSERT INTO `directory_country_region_name` VALUES('en_US', 264, 'Tarn-et-Garonne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 265, 'Var');
INSERT INTO `directory_country_region_name` VALUES('en_US', 266, 'Vaucluse');
INSERT INTO `directory_country_region_name` VALUES('en_US', 267, 'Vendée');
INSERT INTO `directory_country_region_name` VALUES('en_US', 268, 'Vienne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 269, 'Haute-Vienne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 270, 'Vosges');
INSERT INTO `directory_country_region_name` VALUES('en_US', 271, 'Yonne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 272, 'Territoire-de-Belfort');
INSERT INTO `directory_country_region_name` VALUES('en_US', 273, 'Essonne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 274, 'Hauts-de-Seine');
INSERT INTO `directory_country_region_name` VALUES('en_US', 275, 'Seine-Saint-Denis');
INSERT INTO `directory_country_region_name` VALUES('en_US', 276, 'Val-de-Marne');
INSERT INTO `directory_country_region_name` VALUES('en_US', 277, 'Val-d''Oise');
INSERT INTO `directory_country_region_name` VALUES('en_US', 278, 'Alba');
INSERT INTO `directory_country_region_name` VALUES('en_US', 279, 'Arad');
INSERT INTO `directory_country_region_name` VALUES('en_US', 280, 'Argeş');
INSERT INTO `directory_country_region_name` VALUES('en_US', 281, 'Bacău');
INSERT INTO `directory_country_region_name` VALUES('en_US', 282, 'Bihor');
INSERT INTO `directory_country_region_name` VALUES('en_US', 283, 'Bistriţa-Năsăud');
INSERT INTO `directory_country_region_name` VALUES('en_US', 284, 'Botoşani');
INSERT INTO `directory_country_region_name` VALUES('en_US', 285, 'Braşov');
INSERT INTO `directory_country_region_name` VALUES('en_US', 286, 'Brăila');
INSERT INTO `directory_country_region_name` VALUES('en_US', 287, 'Bucureşti');
INSERT INTO `directory_country_region_name` VALUES('en_US', 288, 'Buzău');
INSERT INTO `directory_country_region_name` VALUES('en_US', 289, 'Caraş-Severin');
INSERT INTO `directory_country_region_name` VALUES('en_US', 290, 'Călăraşi');
INSERT INTO `directory_country_region_name` VALUES('en_US', 291, 'Cluj');
INSERT INTO `directory_country_region_name` VALUES('en_US', 292, 'Constanţa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 293, 'Covasna');
INSERT INTO `directory_country_region_name` VALUES('en_US', 294, 'Dâmboviţa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 295, 'Dolj');
INSERT INTO `directory_country_region_name` VALUES('en_US', 296, 'Galaţi');
INSERT INTO `directory_country_region_name` VALUES('en_US', 297, 'Giurgiu');
INSERT INTO `directory_country_region_name` VALUES('en_US', 298, 'Gorj');
INSERT INTO `directory_country_region_name` VALUES('en_US', 299, 'Harghita');
INSERT INTO `directory_country_region_name` VALUES('en_US', 300, 'Hunedoara');
INSERT INTO `directory_country_region_name` VALUES('en_US', 301, 'Ialomiţa');
INSERT INTO `directory_country_region_name` VALUES('en_US', 302, 'Iaşi');
INSERT INTO `directory_country_region_name` VALUES('en_US', 303, 'Ilfov');
INSERT INTO `directory_country_region_name` VALUES('en_US', 304, 'Maramureş');
INSERT INTO `directory_country_region_name` VALUES('en_US', 305, 'Mehedinţi');
INSERT INTO `directory_country_region_name` VALUES('en_US', 306, 'Mureş');
INSERT INTO `directory_country_region_name` VALUES('en_US', 307, 'Neamţ');
INSERT INTO `directory_country_region_name` VALUES('en_US', 308, 'Olt');
INSERT INTO `directory_country_region_name` VALUES('en_US', 309, 'Prahova');
INSERT INTO `directory_country_region_name` VALUES('en_US', 310, 'Satu-Mare');
INSERT INTO `directory_country_region_name` VALUES('en_US', 311, 'Sălaj');
INSERT INTO `directory_country_region_name` VALUES('en_US', 312, 'Sibiu');
INSERT INTO `directory_country_region_name` VALUES('en_US', 313, 'Suceava');
INSERT INTO `directory_country_region_name` VALUES('en_US', 314, 'Teleorman');
INSERT INTO `directory_country_region_name` VALUES('en_US', 315, 'Timiş');
INSERT INTO `directory_country_region_name` VALUES('en_US', 316, 'Tulcea');
INSERT INTO `directory_country_region_name` VALUES('en_US', 317, 'Vaslui');
INSERT INTO `directory_country_region_name` VALUES('en_US', 318, 'Vâlcea');
INSERT INTO `directory_country_region_name` VALUES('en_US', 319, 'Vrancea');

-- --------------------------------------------------------

--
-- Table structure for table `directory_currency_rate`
--

CREATE TABLE `directory_currency_rate` (
  `currency_from` char(3) NOT NULL default '',
  `currency_to` char(3) NOT NULL default '',
  `rate` decimal(24,12) NOT NULL default '0.000000000000',
  PRIMARY KEY  (`currency_from`,`currency_to`),
  KEY `FK_CURRENCY_RATE_TO` (`currency_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `directory_currency_rate`
--

INSERT INTO `directory_currency_rate` VALUES('EUR', 'EUR', 1.000000000000);
INSERT INTO `directory_currency_rate` VALUES('EUR', 'USD', 1.415000000000);
INSERT INTO `directory_currency_rate` VALUES('USD', 'EUR', 0.706700000000);
INSERT INTO `directory_currency_rate` VALUES('USD', 'USD', 1.000000000000);

-- --------------------------------------------------------

--
-- Table structure for table `downloadable_link`
--

CREATE TABLE `downloadable_link` (
  `link_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `sort_order` int(10) unsigned NOT NULL default '0',
  `number_of_downloads` int(10) unsigned default NULL,
  `is_shareable` smallint(1) unsigned NOT NULL default '0',
  `link_url` varchar(255) NOT NULL default '',
  `link_file` varchar(255) NOT NULL default '',
  `link_type` varchar(20) NOT NULL default '',
  `sample_url` varchar(255) NOT NULL default '',
  `sample_file` varchar(255) NOT NULL default '',
  `sample_type` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`link_id`),
  KEY `DOWNLODABLE_LINK_PRODUCT` (`product_id`),
  KEY `DOWNLODABLE_LINK_PRODUCT_SORT_ORDER` (`product_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloadable_link_price`
--

CREATE TABLE `downloadable_link_price` (
  `price_id` int(10) unsigned NOT NULL auto_increment,
  `link_id` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`price_id`),
  KEY `DOWNLOADABLE_LINK_PRICE_LINK` (`link_id`),
  KEY `DOWNLOADABLE_LINK_PRICE_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_link_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloadable_link_purchased`
--

CREATE TABLE `downloadable_link_purchased` (
  `purchased_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) unsigned default '0',
  `order_increment_id` varchar(50) NOT NULL default '',
  `order_item_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_name` varchar(255) NOT NULL default '',
  `product_sku` varchar(255) NOT NULL default '',
  `link_section_title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`purchased_id`),
  KEY `DOWNLOADABLE_ORDER_ID` (`order_id`),
  KEY `DOWNLOADABLE_CUSTOMER_ID` (`customer_id`),
  KEY `KEY_DOWNLOADABLE_ORDER_ITEM_ID` (`order_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_link_purchased`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloadable_link_purchased_item`
--

CREATE TABLE `downloadable_link_purchased_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `purchased_id` int(10) unsigned NOT NULL default '0',
  `order_item_id` int(10) unsigned default '0',
  `product_id` int(10) unsigned default '0',
  `link_hash` varchar(255) NOT NULL default '',
  `number_of_downloads_bought` int(10) unsigned NOT NULL default '0',
  `number_of_downloads_used` int(10) unsigned NOT NULL default '0',
  `link_id` int(20) unsigned NOT NULL default '0',
  `link_title` varchar(255) NOT NULL default '',
  `is_shareable` smallint(1) unsigned NOT NULL default '0',
  `link_url` varchar(255) NOT NULL default '',
  `link_file` varchar(255) NOT NULL default '',
  `link_type` varchar(255) NOT NULL default '',
  `status` varchar(50) NOT NULL default '',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`item_id`),
  KEY `DOWNLOADABLE_LINK_PURCHASED_ID` (`purchased_id`),
  KEY `DOWNLOADABLE_ORDER_ITEM_ID` (`order_item_id`),
  KEY `DOWNLOADALBE_LINK_HASH` (`link_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_link_purchased_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloadable_link_title`
--

CREATE TABLE `downloadable_link_title` (
  `title_id` int(10) unsigned NOT NULL auto_increment,
  `link_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`title_id`),
  UNIQUE KEY `UNQ_LINK_TITLE_STORE` (`link_id`,`store_id`),
  KEY `DOWNLOADABLE_LINK_TITLE_LINK` (`link_id`),
  KEY `DOWNLOADABLE_LINK_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_link_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloadable_sample`
--

CREATE TABLE `downloadable_sample` (
  `sample_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `sample_url` varchar(255) NOT NULL default '',
  `sample_file` varchar(255) NOT NULL default '',
  `sample_type` varchar(20) NOT NULL default '',
  `sort_order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sample_id`),
  KEY `DOWNLODABLE_SAMPLE_PRODUCT` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_sample`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloadable_sample_title`
--

CREATE TABLE `downloadable_sample_title` (
  `title_id` int(10) unsigned NOT NULL auto_increment,
  `sample_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`title_id`),
  UNIQUE KEY `UNQ_SAMPLE_TITLE_STORE` (`sample_id`,`store_id`),
  KEY `DOWNLOADABLE_SAMPLE_TITLE_SAMPLE` (`sample_id`),
  KEY `DOWNLOADABLE_SAMPLE_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloadable_sample_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute`
--

CREATE TABLE `eav_attribute` (
  `attribute_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_code` varchar(255) NOT NULL default '',
  `attribute_model` varchar(255) default NULL,
  `backend_model` varchar(255) default NULL,
  `backend_type` enum('static','datetime','decimal','int','text','varchar') NOT NULL default 'static',
  `backend_table` varchar(255) default NULL,
  `frontend_model` varchar(255) default NULL,
  `frontend_input` varchar(50) default NULL,
  `frontend_label` varchar(255) default NULL,
  `frontend_class` varchar(255) default NULL,
  `source_model` varchar(255) default NULL,
  `is_required` tinyint(1) unsigned NOT NULL default '0',
  `is_user_defined` tinyint(1) unsigned NOT NULL default '0',
  `default_value` text,
  `is_unique` tinyint(1) unsigned NOT NULL default '0',
  `note` varchar(255) NOT NULL,
  PRIMARY KEY  (`attribute_id`),
  UNIQUE KEY `entity_type_id` (`entity_type_id`,`attribute_code`),
  KEY `IDX_USED_FOR_SORT_BY` (`entity_type_id`),
  KEY `IDX_USED_IN_PRODUCT_LISTING` (`entity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=122 ;

--
-- Dumping data for table `eav_attribute`
--

INSERT INTO `eav_attribute` VALUES(1, 1, 'website_id', NULL, 'customer/customer_attribute_backend_website', 'static', '', '', 'select', 'Associate to Website', '', 'customer/customer_attribute_source_website', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(2, 1, 'store_id', NULL, 'customer/customer_attribute_backend_store', 'static', '', '', 'select', 'Create In', '', 'customer/customer_attribute_source_store', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(3, 1, 'created_in', NULL, '', 'varchar', '', '', 'text', 'Created From', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(4, 1, 'prefix', NULL, '', 'varchar', '', '', 'text', 'Prefix', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(5, 1, 'firstname', NULL, '', 'varchar', '', '', 'text', 'First Name', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(6, 1, 'middlename', NULL, '', 'varchar', '', '', 'text', 'Middle Name/Initial', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(7, 1, 'lastname', NULL, '', 'varchar', '', '', 'text', 'Last Name', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(8, 1, 'suffix', NULL, '', 'varchar', '', '', 'text', 'Suffix', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(9, 1, 'email', NULL, '', 'static', '', '', 'text', 'Email', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(10, 1, 'group_id', NULL, '', 'static', '', '', 'select', 'Group', '', 'customer/customer_attribute_source_group', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(11, 1, 'dob', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', 'eav/entity_attribute_frontend_datetime', 'date', 'Date Of Birth', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(12, 1, 'password_hash', NULL, 'customer/customer_attribute_backend_password', 'varchar', '', '', 'hidden', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(13, 1, 'default_billing', NULL, 'customer/customer_attribute_backend_billing', 'int', '', '', 'text', 'Default Billing Address', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(14, 1, 'default_shipping', NULL, 'customer/customer_attribute_backend_shipping', 'int', '', '', 'text', 'Default Shipping Address', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(15, 1, 'taxvat', NULL, '', 'varchar', '', '', 'text', 'Tax/VAT Number', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(16, 1, 'confirmation', NULL, '', 'varchar', '', '', 'text', 'Is Confirmed', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(17, 1, 'created_at', NULL, '', 'static', '', '', 'date', 'Created At', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(18, 2, 'prefix', NULL, '', 'varchar', '', '', 'text', 'Prefix', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(19, 2, 'firstname', NULL, '', 'varchar', '', '', 'text', 'First Name', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(20, 2, 'middlename', NULL, '', 'varchar', '', '', 'text', 'Middle Name/Initial', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(21, 2, 'lastname', NULL, '', 'varchar', '', '', 'text', 'Last Name', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(22, 2, 'suffix', NULL, '', 'varchar', '', '', 'text', 'Suffix', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(23, 2, 'company', NULL, '', 'varchar', '', '', 'text', 'Company', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(24, 2, 'street', NULL, 'customer_entity/address_attribute_backend_street', 'text', '', '', 'multiline', 'Street Address', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(25, 2, 'city', NULL, '', 'varchar', '', '', 'text', 'City', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(26, 2, 'country_id', NULL, '', 'varchar', '', '', 'select', 'Country', '', 'customer_entity/address_attribute_source_country', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(27, 2, 'region', NULL, 'customer_entity/address_attribute_backend_region', 'varchar', '', '', 'text', 'State/Province', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(28, 2, 'region_id', NULL, '', 'int', '', '', 'hidden', 'State/Province', '', 'customer_entity/address_attribute_source_region', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(29, 2, 'postcode', NULL, '', 'varchar', '', '', 'text', 'Zip/Postal Code', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(30, 2, 'telephone', NULL, '', 'varchar', '', '', 'text', 'Telephone', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(31, 2, 'fax', NULL, '', 'varchar', '', '', 'text', 'Fax', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(32, 1, 'gender', NULL, '', 'int', '', '', 'select', 'Gender', '', 'eav/entity_attribute_source_table', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(33, 3, 'name', NULL, '', 'varchar', '', '', 'text', 'Name', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(34, 3, 'is_active', NULL, '', 'int', '', '', 'select', 'Is Active', '', 'eav/entity_attribute_source_boolean', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(35, 3, 'url_key', NULL, 'catalog/category_attribute_backend_urlkey', 'varchar', '', '', 'text', 'URL key', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(36, 3, 'description', NULL, '', 'text', '', '', 'textarea', 'Description', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(37, 3, 'image', NULL, 'catalog/category_attribute_backend_image', 'varchar', '', '', 'image', 'Image', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(38, 3, 'meta_title', NULL, '', 'varchar', '', '', 'text', 'Page Title', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(39, 3, 'meta_keywords', NULL, '', 'text', '', '', 'textarea', 'Meta Keywords', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(40, 3, 'meta_description', NULL, '', 'text', '', '', 'textarea', 'Meta Description', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(41, 3, 'display_mode', NULL, '', 'varchar', '', '', 'select', 'Display Mode', '', 'catalog/category_attribute_source_mode', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(42, 3, 'landing_page', NULL, '', 'int', '', '', 'select', 'CMS Block', '', 'catalog/category_attribute_source_page', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(43, 3, 'is_anchor', NULL, '', 'int', '', '', 'select', 'Is Anchor', '', 'eav/entity_attribute_source_boolean', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(44, 3, 'path', NULL, '', 'static', '', '', '', 'Path', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(45, 3, 'position', NULL, '', 'static', '', '', '', 'Position', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(46, 3, 'all_children', NULL, '', 'text', '', '', '', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(47, 3, 'path_in_store', NULL, '', 'text', '', '', '', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(48, 3, 'children', NULL, '', 'text', '', '', '', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(49, 3, 'url_path', NULL, '', 'varchar', '', '', '', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(50, 3, 'custom_design', NULL, '', 'varchar', '', '', 'select', 'Custom Design', '', 'core/design_source_design', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(52, 3, 'custom_design_from', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Active From', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(53, 3, 'custom_design_to', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Active To', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(54, 3, 'page_layout', NULL, '', 'varchar', '', '', 'select', 'Page Layout', '', 'catalog/category_attribute_source_layout', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(55, 3, 'custom_layout_update', NULL, 'catalog/attribute_backend_customlayoutupdate', 'text', '', '', 'textarea', 'Custom Layout Update', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(56, 3, 'level', NULL, '', 'static', '', '', '', 'Level', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(57, 3, 'children_count', NULL, '', 'static', '', '', '', 'Children Count', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(58, 3, 'available_sort_by', NULL, 'catalog/category_attribute_backend_sortby', 'text', '', '', 'multiselect', 'Available Product Listing Sort By', '', 'catalog/category_attribute_source_sortby', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(59, 3, 'default_sort_by', NULL, 'catalog/category_attribute_backend_sortby', 'varchar', '', '', 'select', 'Default Product Listing Sort By', '', 'catalog/category_attribute_source_sortby', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(60, 4, 'name', NULL, '', 'varchar', '', '', 'text', 'Name', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(61, 4, 'description', NULL, '', 'text', '', '', 'textarea', 'Description', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(62, 4, 'short_description', NULL, '', 'text', '', '', 'textarea', 'Short Description', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(63, 4, 'sku', NULL, 'catalog/product_attribute_backend_sku', 'static', '', '', 'text', 'SKU', '', '', 1, 0, '', 1, '');
INSERT INTO `eav_attribute` VALUES(64, 4, 'price', NULL, 'catalog/product_attribute_backend_price', 'decimal', '', '', 'price', 'Price', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(65, 4, 'special_price', NULL, 'catalog/product_attribute_backend_price', 'decimal', '', '', 'price', 'Special Price', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(66, 4, 'special_from_date', NULL, 'catalog/product_attribute_backend_startdate', 'datetime', '', '', 'date', 'Special Price From Date', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(67, 4, 'special_to_date', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Special Price To Date', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(68, 4, 'cost', NULL, 'catalog/product_attribute_backend_price', 'decimal', '', '', 'price', 'Cost', '', '', 0, 1, '', 0, '');
INSERT INTO `eav_attribute` VALUES(69, 4, 'weight', NULL, '', 'decimal', '', '', 'text', 'Weight', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(70, 4, 'manufacturer', NULL, '', 'int', '', '', 'select', 'Manufacturer', '', '', 0, 1, '', 0, '');
INSERT INTO `eav_attribute` VALUES(71, 4, 'meta_title', NULL, '', 'varchar', '', '', 'text', 'Meta Title', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(72, 4, 'meta_keyword', NULL, '', 'text', '', '', 'textarea', 'Meta Keywords', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(73, 4, 'meta_description', NULL, '', 'varchar', '', '', 'textarea', 'Meta Description', 'validate-length maximum-length-255', '', 0, 0, '', 0, 'Maximum 255 chars');
INSERT INTO `eav_attribute` VALUES(74, 4, 'image', NULL, '', 'varchar', '', 'catalog/product_attribute_frontend_image', 'media_image', 'Base Image', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(75, 4, 'small_image', NULL, '', 'varchar', '', 'catalog/product_attribute_frontend_image', 'media_image', 'Small Image', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(76, 4, 'thumbnail', NULL, '', 'varchar', '', 'catalog/product_attribute_frontend_image', 'media_image', 'Thumbnail', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(77, 4, 'media_gallery', NULL, 'catalog/product_attribute_backend_media', 'varchar', '', '', 'gallery', 'Media Gallery', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(78, 4, 'old_id', NULL, '', 'int', '', '', '', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(79, 4, 'tier_price', NULL, 'catalog/product_attribute_backend_tierprice', 'decimal', '', '', 'text', 'Tier Price', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(80, 4, 'color', NULL, '', 'int', '', '', 'select', 'Color', '', '', 0, 1, '', 0, '');
INSERT INTO `eav_attribute` VALUES(81, 4, 'news_from_date', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Set Product as New from Date', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(82, 4, 'news_to_date', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Set Product as New to Date', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(83, 4, 'gallery', NULL, '', 'varchar', '', '', 'gallery', 'Image Gallery', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(84, 4, 'status', NULL, '', 'int', '', '', 'select', 'Status', '', 'catalog/product_status', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(85, 4, 'tax_class_id', NULL, '', 'int', '', '', 'select', 'Tax Class', '', 'tax/class_source_product', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(86, 4, 'url_key', NULL, 'catalog/product_attribute_backend_urlkey', 'varchar', '', '', 'text', 'URL key', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(87, 4, 'url_path', NULL, '', 'varchar', '', '', '', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(88, 4, 'minimal_price', NULL, '', 'decimal', '', '', 'price', 'Minimal Price', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(89, 4, 'is_recurring', NULL, '', 'int', '', '', 'select', 'Enable Recurring Profile', '', 'eav/entity_attribute_source_boolean', 0, 0, '', 0, 'Products with recurring profile participate in catalog as nominal items.');
INSERT INTO `eav_attribute` VALUES(90, 4, 'recurring_profile', NULL, 'catalog/product_attribute_backend_recurring', 'text', '', '', 'text', 'Recurring Payment Profile', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(91, 4, 'visibility', NULL, '', 'int', '', '', 'select', 'Visibility', '', 'catalog/product_visibility', 1, 0, '4', 0, '');
INSERT INTO `eav_attribute` VALUES(92, 4, 'custom_design', NULL, '', 'varchar', '', '', 'select', 'Custom Design', '', 'core/design_source_design', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(93, 4, 'custom_design_from', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Active From', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(94, 4, 'custom_design_to', NULL, 'eav/entity_attribute_backend_datetime', 'datetime', '', '', 'date', 'Active To', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(95, 4, 'custom_layout_update', NULL, 'catalog/attribute_backend_customlayoutupdate', 'text', '', '', 'textarea', 'Custom Layout Update', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(96, 4, 'page_layout', NULL, '', 'varchar', '', '', 'select', 'Page Layout', '', 'catalog/product_attribute_source_layout', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(97, 4, 'options_container', NULL, '', 'varchar', '', '', 'select', 'Display product options in', '', 'catalog/entity_product_attribute_design_options_container', 0, 0, 'container2', 0, '');
INSERT INTO `eav_attribute` VALUES(98, 4, 'required_options', NULL, '', 'static', '', '', 'text', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(99, 4, 'has_options', NULL, '', 'static', '', '', 'text', '', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(100, 4, 'image_label', NULL, '', 'varchar', '', '', 'text', 'Image Label', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(101, 4, 'small_image_label', NULL, '', 'varchar', '', '', 'text', 'Small Image Label', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(102, 4, 'thumbnail_label', NULL, '', 'varchar', '', '', 'text', 'Thumbnail Label', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(103, 4, 'created_at', NULL, 'eav/entity_attribute_backend_time_created', 'static', '', '', 'text', '', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(104, 4, 'updated_at', NULL, 'eav/entity_attribute_backend_time_updated', 'static', '', '', 'text', '', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(105, 3, 'include_in_menu', NULL, '', 'int', '', '', 'select', 'Include in Navigation Menu', '', 'eav/entity_attribute_source_boolean', 1, 0, '1', 0, '');
INSERT INTO `eav_attribute` VALUES(106, 3, 'custom_use_parent_settings', NULL, '', 'int', '', '', 'select', 'Use Parent Category Settings', '', 'eav/entity_attribute_source_boolean', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(107, 3, 'custom_apply_to_products', NULL, '', 'int', '', '', 'select', 'Apply To Products', '', 'eav/entity_attribute_source_boolean', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(108, 3, 'filter_price_range', NULL, '', 'int', '', '', 'text', 'Layered Navigation Price Step', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(109, 4, 'enable_googlecheckout', NULL, '', 'int', '', '', 'select', 'Is product available for purchase with Google Checkout', '', 'eav/entity_attribute_source_boolean', 0, 0, '1', 0, '');
INSERT INTO `eav_attribute` VALUES(110, 4, 'gift_message_available', NULL, 'catalog/product_attribute_backend_boolean', 'varchar', '', '', 'select', 'Allow Gift Message', '', 'eav/entity_attribute_source_boolean', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(111, 4, 'price_type', NULL, '', 'int', '', '', '', '', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(112, 4, 'sku_type', NULL, '', 'int', '', '', '', '', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(113, 4, 'weight_type', NULL, '', 'int', '', '', '', '', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(114, 4, 'price_view', NULL, '', 'int', '', '', 'select', 'Price View', '', 'bundle/product_attribute_source_price_view', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(115, 4, 'shipment_type', NULL, '', 'int', '', '', '', 'Shipment', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(116, 4, 'links_purchased_separately', NULL, '', 'int', '', '', '', 'Links can be purchased separately', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(117, 4, 'samples_title', NULL, '', 'varchar', '', '', '', 'Samples title', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(118, 4, 'links_title', NULL, '', 'varchar', '', '', '', 'Links title', '', '', 1, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(119, 4, 'links_exist', NULL, '', 'int', '', '', '', '', '', '', 0, 0, '0', 0, '');
INSERT INTO `eav_attribute` VALUES(120, 3, 'thumbnail', NULL, 'catalog/category_attribute_backend_image', 'varchar', '', '', 'image', 'Thumbnail Image', '', '', 0, 0, '', 0, '');
INSERT INTO `eav_attribute` VALUES(121, 4, 'is_imported', NULL, '', 'int', '', '', 'select', 'In feed', '', 'eav/entity_attribute_source_boolean', 0, 0, '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_group`
--

CREATE TABLE `eav_attribute_group` (
  `attribute_group_id` smallint(5) unsigned NOT NULL auto_increment,
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_group_name` varchar(255) NOT NULL default '',
  `sort_order` smallint(6) NOT NULL default '0',
  `default_id` smallint(5) unsigned default '0',
  PRIMARY KEY  (`attribute_group_id`),
  UNIQUE KEY `attribute_set_id` (`attribute_set_id`,`attribute_group_name`),
  KEY `attribute_set_id_2` (`attribute_set_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `eav_attribute_group`
--

INSERT INTO `eav_attribute_group` VALUES(1, 1, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(2, 2, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(3, 3, 'General Information', 10, 1);
INSERT INTO `eav_attribute_group` VALUES(4, 4, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(5, 4, 'Prices', 2, 0);
INSERT INTO `eav_attribute_group` VALUES(6, 4, 'Meta Information', 3, 0);
INSERT INTO `eav_attribute_group` VALUES(7, 4, 'Images', 4, 0);
INSERT INTO `eav_attribute_group` VALUES(8, 4, 'Recurring Profile', 5, 0);
INSERT INTO `eav_attribute_group` VALUES(9, 4, 'Design', 6, 0);
INSERT INTO `eav_attribute_group` VALUES(10, 3, 'Display Settings', 20, 0);
INSERT INTO `eav_attribute_group` VALUES(11, 3, 'Custom Design', 30, 0);
INSERT INTO `eav_attribute_group` VALUES(12, 5, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(13, 6, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(14, 7, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(15, 8, 'General', 1, 1);
INSERT INTO `eav_attribute_group` VALUES(16, 4, 'Gift Options', 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_label`
--

CREATE TABLE `eav_attribute_label` (
  `attribute_label_id` int(11) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`attribute_label_id`),
  KEY `IDX_ATTRIBUTE_LABEL_ATTRIBUTE` (`attribute_id`),
  KEY `IDX_ATTRIBUTE_LABEL_STORE` (`store_id`),
  KEY `IDX_ATTRIBUTE_LABEL_ATTRIBUTE_STORE` (`attribute_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_attribute_label`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_option`
--

CREATE TABLE `eav_attribute_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `sort_order` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`),
  KEY `FK_ATTRIBUTE_OPTION_ATTRIBUTE` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Attributes option (for source model)' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `eav_attribute_option`
--

INSERT INTO `eav_attribute_option` VALUES(1, 32, 0);
INSERT INTO `eav_attribute_option` VALUES(2, 32, 1);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_option_value`
--

CREATE TABLE `eav_attribute_option_value` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `FK_ATTRIBUTE_OPTION_VALUE_OPTION` (`option_id`),
  KEY `FK_ATTRIBUTE_OPTION_VALUE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Attribute option values per store' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `eav_attribute_option_value`
--

INSERT INTO `eav_attribute_option_value` VALUES(1, 1, 0, 'Male');
INSERT INTO `eav_attribute_option_value` VALUES(2, 2, 0, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_set`
--

CREATE TABLE `eav_attribute_set` (
  `attribute_set_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_set_name` varchar(255) character set utf8 collate utf8_swedish_ci NOT NULL default '',
  `sort_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`attribute_set_id`),
  UNIQUE KEY `entity_type_id` (`entity_type_id`,`attribute_set_name`),
  KEY `entity_type_id_2` (`entity_type_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `eav_attribute_set`
--

INSERT INTO `eav_attribute_set` VALUES(1, 1, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(2, 2, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(3, 3, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(4, 4, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(5, 5, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(6, 6, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(7, 7, 'Default', 1);
INSERT INTO `eav_attribute_set` VALUES(8, 8, 'Default', 1);

-- --------------------------------------------------------

--
-- Table structure for table `eav_entity`
--

CREATE TABLE `eav_entity` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(8) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_id` varchar(50) NOT NULL default '',
  `parent_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`entity_id`),
  KEY `FK_ENTITY_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ENTITY_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Entityies' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_attribute`
--

CREATE TABLE `eav_entity_attribute` (
  `entity_attribute_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_group_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `sort_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`entity_attribute_id`),
  UNIQUE KEY `attribute_set_id_2` (`attribute_set_id`,`attribute_id`),
  UNIQUE KEY `attribute_group_id` (`attribute_group_id`,`attribute_id`),
  KEY `attribute_set_id_3` (`attribute_set_id`,`sort_order`),
  KEY `FK_EAV_ENTITY_ATTRIVUTE_ATTRIBUTE` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=120 ;

--
-- Dumping data for table `eav_entity_attribute`
--

INSERT INTO `eav_entity_attribute` VALUES(1, 1, 1, 1, 1, 10);
INSERT INTO `eav_entity_attribute` VALUES(2, 1, 1, 1, 2, 0);
INSERT INTO `eav_entity_attribute` VALUES(3, 1, 1, 1, 3, 20);
INSERT INTO `eav_entity_attribute` VALUES(4, 1, 1, 1, 4, 30);
INSERT INTO `eav_entity_attribute` VALUES(5, 1, 1, 1, 5, 40);
INSERT INTO `eav_entity_attribute` VALUES(6, 1, 1, 1, 6, 50);
INSERT INTO `eav_entity_attribute` VALUES(7, 1, 1, 1, 7, 60);
INSERT INTO `eav_entity_attribute` VALUES(8, 1, 1, 1, 8, 70);
INSERT INTO `eav_entity_attribute` VALUES(9, 1, 1, 1, 9, 80);
INSERT INTO `eav_entity_attribute` VALUES(10, 1, 1, 1, 10, 25);
INSERT INTO `eav_entity_attribute` VALUES(11, 1, 1, 1, 11, 90);
INSERT INTO `eav_entity_attribute` VALUES(12, 1, 1, 1, 12, 0);
INSERT INTO `eav_entity_attribute` VALUES(13, 1, 1, 1, 13, 0);
INSERT INTO `eav_entity_attribute` VALUES(14, 1, 1, 1, 14, 0);
INSERT INTO `eav_entity_attribute` VALUES(15, 1, 1, 1, 15, 100);
INSERT INTO `eav_entity_attribute` VALUES(16, 1, 1, 1, 16, 0);
INSERT INTO `eav_entity_attribute` VALUES(17, 1, 1, 1, 17, 86);
INSERT INTO `eav_entity_attribute` VALUES(18, 2, 2, 2, 18, 10);
INSERT INTO `eav_entity_attribute` VALUES(19, 2, 2, 2, 19, 20);
INSERT INTO `eav_entity_attribute` VALUES(20, 2, 2, 2, 20, 30);
INSERT INTO `eav_entity_attribute` VALUES(21, 2, 2, 2, 21, 40);
INSERT INTO `eav_entity_attribute` VALUES(22, 2, 2, 2, 22, 50);
INSERT INTO `eav_entity_attribute` VALUES(23, 2, 2, 2, 23, 60);
INSERT INTO `eav_entity_attribute` VALUES(24, 2, 2, 2, 24, 70);
INSERT INTO `eav_entity_attribute` VALUES(25, 2, 2, 2, 25, 80);
INSERT INTO `eav_entity_attribute` VALUES(26, 2, 2, 2, 26, 90);
INSERT INTO `eav_entity_attribute` VALUES(27, 2, 2, 2, 27, 100);
INSERT INTO `eav_entity_attribute` VALUES(28, 2, 2, 2, 28, 100);
INSERT INTO `eav_entity_attribute` VALUES(29, 2, 2, 2, 29, 110);
INSERT INTO `eav_entity_attribute` VALUES(30, 2, 2, 2, 30, 120);
INSERT INTO `eav_entity_attribute` VALUES(31, 2, 2, 2, 31, 130);
INSERT INTO `eav_entity_attribute` VALUES(32, 1, 1, 1, 32, 110);
INSERT INTO `eav_entity_attribute` VALUES(33, 3, 3, 3, 33, 1);
INSERT INTO `eav_entity_attribute` VALUES(34, 3, 3, 3, 34, 2);
INSERT INTO `eav_entity_attribute` VALUES(35, 3, 3, 3, 35, 3);
INSERT INTO `eav_entity_attribute` VALUES(36, 3, 3, 3, 36, 4);
INSERT INTO `eav_entity_attribute` VALUES(37, 3, 3, 3, 37, 5);
INSERT INTO `eav_entity_attribute` VALUES(38, 3, 3, 3, 38, 6);
INSERT INTO `eav_entity_attribute` VALUES(39, 3, 3, 3, 39, 7);
INSERT INTO `eav_entity_attribute` VALUES(40, 3, 3, 3, 40, 8);
INSERT INTO `eav_entity_attribute` VALUES(41, 3, 3, 10, 41, 10);
INSERT INTO `eav_entity_attribute` VALUES(42, 3, 3, 10, 42, 20);
INSERT INTO `eav_entity_attribute` VALUES(43, 3, 3, 10, 43, 30);
INSERT INTO `eav_entity_attribute` VALUES(44, 3, 3, 3, 44, 12);
INSERT INTO `eav_entity_attribute` VALUES(45, 3, 3, 3, 45, 13);
INSERT INTO `eav_entity_attribute` VALUES(46, 3, 3, 3, 46, 14);
INSERT INTO `eav_entity_attribute` VALUES(47, 3, 3, 3, 47, 15);
INSERT INTO `eav_entity_attribute` VALUES(48, 3, 3, 3, 48, 16);
INSERT INTO `eav_entity_attribute` VALUES(49, 3, 3, 3, 49, 17);
INSERT INTO `eav_entity_attribute` VALUES(50, 3, 3, 11, 50, 10);
INSERT INTO `eav_entity_attribute` VALUES(51, 3, 3, 11, 51, 20);
INSERT INTO `eav_entity_attribute` VALUES(52, 3, 3, 11, 52, 30);
INSERT INTO `eav_entity_attribute` VALUES(53, 3, 3, 11, 53, 40);
INSERT INTO `eav_entity_attribute` VALUES(54, 3, 3, 11, 54, 50);
INSERT INTO `eav_entity_attribute` VALUES(55, 3, 3, 11, 55, 60);
INSERT INTO `eav_entity_attribute` VALUES(56, 3, 3, 3, 56, 24);
INSERT INTO `eav_entity_attribute` VALUES(57, 3, 3, 3, 57, 25);
INSERT INTO `eav_entity_attribute` VALUES(58, 3, 3, 10, 58, 40);
INSERT INTO `eav_entity_attribute` VALUES(59, 3, 3, 10, 59, 50);
INSERT INTO `eav_entity_attribute` VALUES(60, 4, 4, 4, 60, 1);
INSERT INTO `eav_entity_attribute` VALUES(61, 4, 4, 4, 61, 2);
INSERT INTO `eav_entity_attribute` VALUES(62, 4, 4, 4, 62, 3);
INSERT INTO `eav_entity_attribute` VALUES(63, 4, 4, 4, 63, 4);
INSERT INTO `eav_entity_attribute` VALUES(64, 4, 4, 5, 64, 1);
INSERT INTO `eav_entity_attribute` VALUES(65, 4, 4, 5, 65, 2);
INSERT INTO `eav_entity_attribute` VALUES(66, 4, 4, 5, 66, 3);
INSERT INTO `eav_entity_attribute` VALUES(67, 4, 4, 5, 67, 4);
INSERT INTO `eav_entity_attribute` VALUES(68, 4, 4, 5, 68, 5);
INSERT INTO `eav_entity_attribute` VALUES(69, 4, 4, 4, 69, 5);
INSERT INTO `eav_entity_attribute` VALUES(70, 4, 4, 6, 71, 1);
INSERT INTO `eav_entity_attribute` VALUES(71, 4, 4, 6, 72, 2);
INSERT INTO `eav_entity_attribute` VALUES(72, 4, 4, 6, 73, 3);
INSERT INTO `eav_entity_attribute` VALUES(73, 4, 4, 7, 74, 1);
INSERT INTO `eav_entity_attribute` VALUES(74, 4, 4, 7, 75, 2);
INSERT INTO `eav_entity_attribute` VALUES(75, 4, 4, 7, 76, 3);
INSERT INTO `eav_entity_attribute` VALUES(76, 4, 4, 7, 77, 4);
INSERT INTO `eav_entity_attribute` VALUES(77, 4, 4, 4, 78, 6);
INSERT INTO `eav_entity_attribute` VALUES(78, 4, 4, 5, 79, 6);
INSERT INTO `eav_entity_attribute` VALUES(79, 4, 4, 4, 81, 7);
INSERT INTO `eav_entity_attribute` VALUES(80, 4, 4, 4, 82, 8);
INSERT INTO `eav_entity_attribute` VALUES(81, 4, 4, 7, 83, 5);
INSERT INTO `eav_entity_attribute` VALUES(82, 4, 4, 4, 84, 9);
INSERT INTO `eav_entity_attribute` VALUES(83, 4, 4, 5, 85, 7);
INSERT INTO `eav_entity_attribute` VALUES(84, 4, 4, 4, 86, 10);
INSERT INTO `eav_entity_attribute` VALUES(85, 4, 4, 4, 87, 11);
INSERT INTO `eav_entity_attribute` VALUES(86, 4, 4, 5, 88, 8);
INSERT INTO `eav_entity_attribute` VALUES(87, 4, 4, 8, 89, 1);
INSERT INTO `eav_entity_attribute` VALUES(88, 4, 4, 8, 90, 2);
INSERT INTO `eav_entity_attribute` VALUES(89, 4, 4, 4, 91, 12);
INSERT INTO `eav_entity_attribute` VALUES(90, 4, 4, 9, 92, 1);
INSERT INTO `eav_entity_attribute` VALUES(91, 4, 4, 9, 93, 2);
INSERT INTO `eav_entity_attribute` VALUES(92, 4, 4, 9, 94, 3);
INSERT INTO `eav_entity_attribute` VALUES(93, 4, 4, 9, 95, 4);
INSERT INTO `eav_entity_attribute` VALUES(94, 4, 4, 9, 96, 5);
INSERT INTO `eav_entity_attribute` VALUES(95, 4, 4, 9, 97, 6);
INSERT INTO `eav_entity_attribute` VALUES(96, 4, 4, 4, 98, 13);
INSERT INTO `eav_entity_attribute` VALUES(97, 4, 4, 4, 99, 14);
INSERT INTO `eav_entity_attribute` VALUES(98, 4, 4, 4, 100, 15);
INSERT INTO `eav_entity_attribute` VALUES(99, 4, 4, 4, 101, 16);
INSERT INTO `eav_entity_attribute` VALUES(100, 4, 4, 4, 102, 17);
INSERT INTO `eav_entity_attribute` VALUES(101, 4, 4, 4, 103, 18);
INSERT INTO `eav_entity_attribute` VALUES(102, 4, 4, 4, 104, 19);
INSERT INTO `eav_entity_attribute` VALUES(103, 3, 3, 3, 105, 10);
INSERT INTO `eav_entity_attribute` VALUES(104, 3, 3, 11, 106, 5);
INSERT INTO `eav_entity_attribute` VALUES(105, 3, 3, 11, 107, 6);
INSERT INTO `eav_entity_attribute` VALUES(106, 3, 3, 10, 108, 51);
INSERT INTO `eav_entity_attribute` VALUES(107, 4, 4, 5, 109, 20);
INSERT INTO `eav_entity_attribute` VALUES(108, 4, 4, 16, 110, 20);
INSERT INTO `eav_entity_attribute` VALUES(109, 4, 4, 4, 111, 20);
INSERT INTO `eav_entity_attribute` VALUES(110, 4, 4, 4, 112, 21);
INSERT INTO `eav_entity_attribute` VALUES(111, 4, 4, 4, 113, 22);
INSERT INTO `eav_entity_attribute` VALUES(112, 4, 4, 5, 114, 21);
INSERT INTO `eav_entity_attribute` VALUES(113, 4, 4, 4, 115, 23);
INSERT INTO `eav_entity_attribute` VALUES(114, 4, 4, 4, 116, 24);
INSERT INTO `eav_entity_attribute` VALUES(115, 4, 4, 4, 117, 25);
INSERT INTO `eav_entity_attribute` VALUES(116, 4, 4, 4, 118, 26);
INSERT INTO `eav_entity_attribute` VALUES(117, 4, 4, 4, 119, 27);
INSERT INTO `eav_entity_attribute` VALUES(118, 3, 3, 3, 120, 4);
INSERT INTO `eav_entity_attribute` VALUES(119, 4, 4, 4, 121, 28);

-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_datetime`
--

CREATE TABLE `eav_entity_datetime` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_DATETIME_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_DATETIME_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Datetime values of attributes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity_datetime`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_decimal`
--

CREATE TABLE `eav_entity_decimal` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_DECIMAL_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Decimal values of attributes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity_decimal`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_int`
--

CREATE TABLE `eav_entity_int` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` int(11) NOT NULL default '0',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_INT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_INT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_INT_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_INT_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Integer values of attributes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_store`
--

CREATE TABLE `eav_entity_store` (
  `entity_store_id` int(10) unsigned NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `increment_prefix` varchar(20) NOT NULL default '',
  `increment_last_id` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`entity_store_id`),
  KEY `FK_eav_entity_store_entity_type` (`entity_type_id`),
  KEY `FK_eav_entity_store_store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_text`
--

CREATE TABLE `eav_entity_text` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_TEXT_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_TEXT_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_TEXT_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_TEXT_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Text values of attributes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity_text`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_type`
--

CREATE TABLE `eav_entity_type` (
  `entity_type_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_type_code` varchar(50) NOT NULL default '',
  `entity_model` varchar(255) NOT NULL,
  `attribute_model` varchar(255) NOT NULL,
  `entity_table` varchar(255) NOT NULL default '',
  `value_table_prefix` varchar(255) NOT NULL default '',
  `entity_id_field` varchar(255) NOT NULL default '',
  `is_data_sharing` tinyint(4) unsigned NOT NULL default '1',
  `data_sharing_key` varchar(100) default 'default',
  `default_attribute_set_id` smallint(5) unsigned NOT NULL default '0',
  `increment_model` varchar(255) NOT NULL default '',
  `increment_per_store` tinyint(1) unsigned NOT NULL default '0',
  `increment_pad_length` tinyint(8) unsigned NOT NULL default '8',
  `increment_pad_char` char(1) NOT NULL default '0',
  `additional_attribute_table` varchar(255) NOT NULL default '',
  `entity_attribute_collection` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`entity_type_id`),
  KEY `entity_name` (`entity_type_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `eav_entity_type`
--

INSERT INTO `eav_entity_type` VALUES(1, 'customer', 'customer/customer', 'customer/attribute', 'customer/entity', '', '', 1, 'default', 1, 'eav/entity_increment_numeric', 0, 8, '0', 'customer/eav_attribute', 'customer/attribute_collection');
INSERT INTO `eav_entity_type` VALUES(2, 'customer_address', 'customer/address', 'customer/attribute', 'customer/address_entity', '', '', 1, 'default', 2, '', 0, 8, '0', 'customer/eav_attribute', 'customer/address_attribute_collection');
INSERT INTO `eav_entity_type` VALUES(3, 'catalog_category', 'catalog/category', 'catalog/resource_eav_attribute', 'catalog/category', '', '', 1, 'default', 3, '', 0, 8, '0', 'catalog/eav_attribute', 'catalog/category_attribute_collection');
INSERT INTO `eav_entity_type` VALUES(4, 'catalog_product', 'catalog/product', 'catalog/resource_eav_attribute', 'catalog/product', '', '', 1, 'default', 4, '', 0, 8, '0', 'catalog/eav_attribute', 'catalog/product_attribute_collection');
INSERT INTO `eav_entity_type` VALUES(5, 'order', 'sales/order', '', 'sales/order', '', '', 1, 'default', 0, 'eav/entity_increment_numeric', 1, 8, '0', '', '');
INSERT INTO `eav_entity_type` VALUES(6, 'invoice', 'sales/order_invoice', '', 'sales/invoice', '', '', 1, 'default', 0, 'eav/entity_increment_numeric', 1, 8, '0', '', '');
INSERT INTO `eav_entity_type` VALUES(7, 'creditmemo', 'sales/order_creditmemo', '', 'sales/creditmemo', '', '', 1, 'default', 0, 'eav/entity_increment_numeric', 1, 8, '0', '', '');
INSERT INTO `eav_entity_type` VALUES(8, 'shipment', 'sales/order_shipment', '', 'sales/shipment', '', '', 1, 'default', 0, 'eav/entity_increment_numeric', 1, 8, '0', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_varchar`
--

CREATE TABLE `eav_entity_varchar` (
  `value_id` int(11) NOT NULL auto_increment,
  `entity_type_id` smallint(5) unsigned NOT NULL default '0',
  `attribute_id` smallint(5) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  UNIQUE KEY `UNQ_ATTRIBUTE_VALUE` (`entity_id`,`attribute_id`,`store_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ENTITY_TYPE` (`entity_type_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ATTRIBUTE` (`attribute_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_STORE` (`store_id`),
  KEY `FK_ATTRIBUTE_VARCHAR_ENTITY` (`entity_id`),
  KEY `value_by_attribute` (`attribute_id`,`value`),
  KEY `value_by_entity_type` (`entity_type_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Varchar values of attributes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `eav_entity_varchar`
--


-- --------------------------------------------------------

--
-- Table structure for table `eav_form_element`
--

CREATE TABLE `eav_form_element` (
  `element_id` int(10) unsigned NOT NULL auto_increment,
  `type_id` smallint(5) unsigned NOT NULL,
  `fieldset_id` smallint(5) unsigned default NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL default '0',
  PRIMARY KEY  (`element_id`),
  UNIQUE KEY `UNQ_FORM_ATTRIBUTE` (`type_id`,`attribute_id`),
  KEY `IDX_FORM_TYPE` (`type_id`),
  KEY `IDX_FORM_FIELDSET` (`fieldset_id`),
  KEY `IDX_FORM_ATTRIBUTE` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `eav_form_element`
--

INSERT INTO `eav_form_element` VALUES(1, 1, 1, 5, 0);
INSERT INTO `eav_form_element` VALUES(2, 1, 1, 7, 1);
INSERT INTO `eav_form_element` VALUES(3, 1, 1, 9, 2);
INSERT INTO `eav_form_element` VALUES(4, 2, 2, 5, 0);
INSERT INTO `eav_form_element` VALUES(5, 2, 2, 7, 1);
INSERT INTO `eav_form_element` VALUES(6, 2, 2, 9, 2);
INSERT INTO `eav_form_element` VALUES(7, 3, 3, 19, 0);
INSERT INTO `eav_form_element` VALUES(8, 3, 3, 21, 1);
INSERT INTO `eav_form_element` VALUES(9, 3, 3, 23, 2);
INSERT INTO `eav_form_element` VALUES(10, 3, 3, 30, 3);
INSERT INTO `eav_form_element` VALUES(11, 3, 3, 31, 4);
INSERT INTO `eav_form_element` VALUES(12, 3, 4, 24, 0);
INSERT INTO `eav_form_element` VALUES(13, 3, 4, 25, 1);
INSERT INTO `eav_form_element` VALUES(14, 3, 4, 27, 2);
INSERT INTO `eav_form_element` VALUES(15, 3, 4, 29, 3);
INSERT INTO `eav_form_element` VALUES(16, 3, 4, 26, 4);
INSERT INTO `eav_form_element` VALUES(17, 4, NULL, 19, 0);
INSERT INTO `eav_form_element` VALUES(18, 4, NULL, 21, 1);
INSERT INTO `eav_form_element` VALUES(19, 4, NULL, 23, 2);
INSERT INTO `eav_form_element` VALUES(20, 4, NULL, 9, 3);
INSERT INTO `eav_form_element` VALUES(21, 4, NULL, 24, 4);
INSERT INTO `eav_form_element` VALUES(22, 4, NULL, 25, 5);
INSERT INTO `eav_form_element` VALUES(23, 4, NULL, 27, 6);
INSERT INTO `eav_form_element` VALUES(24, 4, NULL, 29, 7);
INSERT INTO `eav_form_element` VALUES(25, 4, NULL, 26, 8);
INSERT INTO `eav_form_element` VALUES(26, 4, NULL, 30, 9);
INSERT INTO `eav_form_element` VALUES(27, 4, NULL, 31, 10);
INSERT INTO `eav_form_element` VALUES(28, 5, NULL, 19, 0);
INSERT INTO `eav_form_element` VALUES(29, 5, NULL, 21, 1);
INSERT INTO `eav_form_element` VALUES(30, 5, NULL, 23, 2);
INSERT INTO `eav_form_element` VALUES(31, 5, NULL, 9, 3);
INSERT INTO `eav_form_element` VALUES(32, 5, NULL, 24, 4);
INSERT INTO `eav_form_element` VALUES(33, 5, NULL, 25, 5);
INSERT INTO `eav_form_element` VALUES(34, 5, NULL, 27, 6);
INSERT INTO `eav_form_element` VALUES(35, 5, NULL, 29, 7);
INSERT INTO `eav_form_element` VALUES(36, 5, NULL, 26, 8);
INSERT INTO `eav_form_element` VALUES(37, 5, NULL, 30, 9);
INSERT INTO `eav_form_element` VALUES(38, 5, NULL, 31, 10);
INSERT INTO `eav_form_element` VALUES(39, 6, NULL, 19, 0);
INSERT INTO `eav_form_element` VALUES(40, 6, NULL, 21, 1);
INSERT INTO `eav_form_element` VALUES(41, 6, NULL, 23, 2);
INSERT INTO `eav_form_element` VALUES(42, 6, NULL, 24, 3);
INSERT INTO `eav_form_element` VALUES(43, 6, NULL, 25, 4);
INSERT INTO `eav_form_element` VALUES(44, 6, NULL, 27, 5);
INSERT INTO `eav_form_element` VALUES(45, 6, NULL, 29, 6);
INSERT INTO `eav_form_element` VALUES(46, 6, NULL, 26, 7);
INSERT INTO `eav_form_element` VALUES(47, 6, NULL, 30, 8);
INSERT INTO `eav_form_element` VALUES(48, 6, NULL, 31, 9);
INSERT INTO `eav_form_element` VALUES(49, 7, NULL, 19, 0);
INSERT INTO `eav_form_element` VALUES(50, 7, NULL, 21, 1);
INSERT INTO `eav_form_element` VALUES(51, 7, NULL, 23, 2);
INSERT INTO `eav_form_element` VALUES(52, 7, NULL, 24, 3);
INSERT INTO `eav_form_element` VALUES(53, 7, NULL, 25, 4);
INSERT INTO `eav_form_element` VALUES(54, 7, NULL, 27, 5);
INSERT INTO `eav_form_element` VALUES(55, 7, NULL, 29, 6);
INSERT INTO `eav_form_element` VALUES(56, 7, NULL, 26, 7);
INSERT INTO `eav_form_element` VALUES(57, 7, NULL, 30, 8);
INSERT INTO `eav_form_element` VALUES(58, 7, NULL, 31, 9);
INSERT INTO `eav_form_element` VALUES(59, 8, 5, 5, 0);
INSERT INTO `eav_form_element` VALUES(60, 8, 5, 7, 1);
INSERT INTO `eav_form_element` VALUES(61, 8, 5, 9, 2);
INSERT INTO `eav_form_element` VALUES(62, 8, 6, 23, 0);
INSERT INTO `eav_form_element` VALUES(63, 8, 6, 30, 1);
INSERT INTO `eav_form_element` VALUES(64, 8, 6, 24, 2);
INSERT INTO `eav_form_element` VALUES(65, 8, 6, 25, 3);
INSERT INTO `eav_form_element` VALUES(66, 8, 6, 27, 4);
INSERT INTO `eav_form_element` VALUES(67, 8, 6, 29, 5);
INSERT INTO `eav_form_element` VALUES(68, 8, 6, 26, 6);

-- --------------------------------------------------------

--
-- Table structure for table `eav_form_fieldset`
--

CREATE TABLE `eav_form_fieldset` (
  `fieldset_id` smallint(5) unsigned NOT NULL auto_increment,
  `type_id` smallint(5) unsigned NOT NULL,
  `code` char(64) NOT NULL,
  `sort_order` int(11) NOT NULL default '0',
  PRIMARY KEY  (`fieldset_id`),
  UNIQUE KEY `UNQ_FORM_FIELDSET_CODE` (`type_id`,`code`),
  KEY `IDX_FORM_TYPE` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `eav_form_fieldset`
--

INSERT INTO `eav_form_fieldset` VALUES(1, 1, 'general', 1);
INSERT INTO `eav_form_fieldset` VALUES(2, 2, 'general', 1);
INSERT INTO `eav_form_fieldset` VALUES(3, 3, 'contact', 1);
INSERT INTO `eav_form_fieldset` VALUES(4, 3, 'address', 2);
INSERT INTO `eav_form_fieldset` VALUES(5, 8, 'general', 1);
INSERT INTO `eav_form_fieldset` VALUES(6, 8, 'address', 2);

-- --------------------------------------------------------

--
-- Table structure for table `eav_form_fieldset_label`
--

CREATE TABLE `eav_form_fieldset_label` (
  `fieldset_id` smallint(5) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY  (`fieldset_id`,`store_id`),
  KEY `IDX_FORM_FIELDSET` (`fieldset_id`),
  KEY `IDX_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_form_fieldset_label`
--

INSERT INTO `eav_form_fieldset_label` VALUES(1, 0, 'Personal Information');
INSERT INTO `eav_form_fieldset_label` VALUES(2, 0, 'Account Information');
INSERT INTO `eav_form_fieldset_label` VALUES(3, 0, 'Contact Information');
INSERT INTO `eav_form_fieldset_label` VALUES(4, 0, 'Address');
INSERT INTO `eav_form_fieldset_label` VALUES(5, 0, 'Personal Information');
INSERT INTO `eav_form_fieldset_label` VALUES(6, 0, 'Address Information');

-- --------------------------------------------------------

--
-- Table structure for table `eav_form_type`
--

CREATE TABLE `eav_form_type` (
  `type_id` smallint(5) unsigned NOT NULL auto_increment,
  `code` char(64) NOT NULL,
  `label` varchar(255) NOT NULL,
  `is_system` tinyint(1) unsigned NOT NULL default '0',
  `theme` varchar(64) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`type_id`),
  UNIQUE KEY `UNQ_FORM_TYPE_CODE` (`code`,`theme`,`store_id`),
  KEY `IDX_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `eav_form_type`
--

INSERT INTO `eav_form_type` VALUES(1, 'customer_account_create', 'customer_account_create', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(2, 'customer_account_edit', 'customer_account_edit', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(3, 'customer_address_edit', 'customer_address_edit', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(4, 'checkout_onepage_register', 'checkout_onepage_register', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(5, 'checkout_onepage_register_guest', 'checkout_onepage_register_guest', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(6, 'checkout_onepage_billing_address', 'checkout_onepage_billing_address', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(7, 'checkout_onepage_shipping_address', 'checkout_onepage_shipping_address', 1, '', 0);
INSERT INTO `eav_form_type` VALUES(8, 'checkout_multishipping_register', 'checkout_multishipping_register', 1, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `eav_form_type_entity`
--

CREATE TABLE `eav_form_type_entity` (
  `type_id` smallint(5) unsigned NOT NULL,
  `entity_type_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`type_id`,`entity_type_id`),
  KEY `IDX_EAV_ENTITY_TYPE` (`entity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_form_type_entity`
--

INSERT INTO `eav_form_type_entity` VALUES(1, 1);
INSERT INTO `eav_form_type_entity` VALUES(2, 1);
INSERT INTO `eav_form_type_entity` VALUES(4, 1);
INSERT INTO `eav_form_type_entity` VALUES(5, 1);
INSERT INTO `eav_form_type_entity` VALUES(8, 1);
INSERT INTO `eav_form_type_entity` VALUES(3, 2);
INSERT INTO `eav_form_type_entity` VALUES(4, 2);
INSERT INTO `eav_form_type_entity` VALUES(5, 2);
INSERT INTO `eav_form_type_entity` VALUES(6, 2);
INSERT INTO `eav_form_type_entity` VALUES(7, 2);
INSERT INTO `eav_form_type_entity` VALUES(8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `find_feed_import_codes`
--

CREATE TABLE `find_feed_import_codes` (
  `code_id` int(10) unsigned NOT NULL auto_increment,
  `import_code` varchar(255) NOT NULL,
  `eav_code` varchar(255) NOT NULL,
  `is_imported` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `find_feed_import_codes`
--


-- --------------------------------------------------------

--
-- Table structure for table `gift_message`
--

CREATE TABLE `gift_message` (
  `gift_message_id` int(7) unsigned NOT NULL auto_increment,
  `customer_id` int(7) unsigned NOT NULL default '0',
  `sender` varchar(255) NOT NULL default '',
  `recipient` varchar(255) NOT NULL default '',
  `message` text NOT NULL,
  PRIMARY KEY  (`gift_message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `gift_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `googlebase_attributes`
--

CREATE TABLE `googlebase_attributes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `attribute_id` smallint(5) unsigned NOT NULL,
  `gbase_attribute` varchar(255) NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `GOOGLEBASE_ATTRIBUTES_ATTRIBUTE_ID` (`attribute_id`),
  KEY `GOOGLEBASE_ATTRIBUTES_TYPE_ID` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Google Base Attributes link Product Attributes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `googlebase_attributes`
--


-- --------------------------------------------------------

--
-- Table structure for table `googlebase_items`
--

CREATE TABLE `googlebase_items` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `type_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL,
  `gbase_item_id` varchar(255) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `published` datetime NOT NULL default '0000-00-00 00:00:00',
  `expires` datetime NOT NULL default '0000-00-00 00:00:00',
  `impr` smallint(5) unsigned NOT NULL default '0',
  `clicks` smallint(5) unsigned NOT NULL default '0',
  `views` smallint(5) unsigned NOT NULL default '0',
  `is_hidden` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`item_id`),
  KEY `GOOGLEBASE_ITEMS_PRODUCT_ID` (`product_id`),
  KEY `GOOGLEBASE_ITEMS_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Google Base Items Products' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `googlebase_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `googlebase_types`
--

CREATE TABLE `googlebase_types` (
  `type_id` int(10) unsigned NOT NULL auto_increment,
  `attribute_set_id` smallint(5) unsigned NOT NULL,
  `gbase_itemtype` varchar(255) NOT NULL,
  `target_country` varchar(2) NOT NULL default 'US',
  PRIMARY KEY  (`type_id`),
  KEY `GOOGLEBASE_TYPES_ATTRIBUTE_SET_ID` (`attribute_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Google Base Item Types link Attribute Sets' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `googlebase_types`
--


-- --------------------------------------------------------

--
-- Table structure for table `googlecheckout_api_debug`
--

CREATE TABLE `googlecheckout_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `dir` enum('in','out') default NULL,
  `url` varchar(255) default NULL,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `googlecheckout_api_debug`
--


-- --------------------------------------------------------

--
-- Table structure for table `googlecheckout_notification`
--

CREATE TABLE `googlecheckout_notification` (
  `serial_number` varchar(30) NOT NULL,
  `started_at` datetime default NULL,
  `status` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`serial_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `googlecheckout_notification`
--


-- --------------------------------------------------------

--
-- Table structure for table `googleoptimizer_code`
--

CREATE TABLE `googleoptimizer_code` (
  `code_id` int(10) unsigned NOT NULL auto_increment,
  `entity_id` int(10) unsigned NOT NULL,
  `entity_type` varchar(50) NOT NULL default '',
  `store_id` smallint(5) unsigned NOT NULL,
  `control_script` text,
  `tracking_script` text,
  `conversion_script` text,
  `conversion_page` varchar(255) NOT NULL default '',
  `additional_data` text,
  PRIMARY KEY  (`code_id`),
  KEY `GOOGLEOPTIMIZER_CODE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `googleoptimizer_code`
--


-- --------------------------------------------------------

--
-- Table structure for table `importexport_importdata`
--

CREATE TABLE `importexport_importdata` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `entity` varchar(50) NOT NULL,
  `behavior` set('append','replace','delete') NOT NULL default 'append',
  `data` mediumtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `importexport_importdata`
--


-- --------------------------------------------------------

--
-- Table structure for table `index_event`
--

CREATE TABLE `index_event` (
  `event_id` bigint(20) unsigned NOT NULL auto_increment,
  `type` varchar(64) NOT NULL,
  `entity` varchar(64) NOT NULL,
  `entity_pk` bigint(20) default NULL,
  `created_at` datetime NOT NULL,
  `old_data` mediumtext,
  `new_data` mediumtext,
  PRIMARY KEY  (`event_id`),
  UNIQUE KEY `IDX_UNIQUE_EVENT` (`type`,`entity`,`entity_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `index_event`
--

INSERT INTO `index_event` VALUES(1, 'save', 'catalog_category', 1, '2011-04-27 19:39:12', 'a:3:{s:30:"Mage_Catalog_Model_Indexer_Url";N;s:43:"Mage_Catalog_Model_Category_Indexer_Product";N;s:41:"Mage_CatalogSearch_Model_Indexer_Fulltext";N;}', 'a:8:{s:35:"cataloginventory_stock_match_result";b:0;s:34:"catalog_product_price_match_result";b:0;s:24:"catalog_url_match_result";b:1;s:30:"Mage_Catalog_Model_Indexer_Url";N;s:37:"catalog_category_product_match_result";b:1;s:43:"Mage_Catalog_Model_Category_Indexer_Product";N;s:35:"catalogsearch_fulltext_match_result";b:1;s:41:"Mage_CatalogSearch_Model_Indexer_Fulltext";N;}');
INSERT INTO `index_event` VALUES(2, 'save', 'catalog_category', 2, '2011-04-27 19:39:12', 'a:3:{s:30:"Mage_Catalog_Model_Indexer_Url";N;s:43:"Mage_Catalog_Model_Category_Indexer_Product";N;s:41:"Mage_CatalogSearch_Model_Indexer_Fulltext";N;}', 'a:8:{s:35:"cataloginventory_stock_match_result";b:0;s:34:"catalog_product_price_match_result";b:0;s:24:"catalog_url_match_result";b:1;s:30:"Mage_Catalog_Model_Indexer_Url";N;s:37:"catalog_category_product_match_result";b:1;s:43:"Mage_Catalog_Model_Category_Indexer_Product";N;s:35:"catalogsearch_fulltext_match_result";b:1;s:41:"Mage_CatalogSearch_Model_Indexer_Fulltext";N;}');

-- --------------------------------------------------------

--
-- Table structure for table `index_process`
--

CREATE TABLE `index_process` (
  `process_id` int(10) unsigned NOT NULL auto_increment,
  `indexer_code` varchar(32) NOT NULL,
  `status` enum('pending','working','require_reindex') NOT NULL default 'pending',
  `started_at` datetime default NULL,
  `ended_at` datetime default NULL,
  `mode` enum('real_time','manual') NOT NULL default 'real_time',
  PRIMARY KEY  (`process_id`),
  UNIQUE KEY `IDX_CODE` (`indexer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `index_process`
--

INSERT INTO `index_process` VALUES(1, 'catalog_product_attribute', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:54', 'real_time');
INSERT INTO `index_process` VALUES(2, 'catalog_product_price', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:54', 'real_time');
INSERT INTO `index_process` VALUES(3, 'catalog_url', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:54', 'real_time');
INSERT INTO `index_process` VALUES(4, 'catalog_product_flat', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:54', 'real_time');
INSERT INTO `index_process` VALUES(5, 'catalog_category_flat', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:54', 'real_time');
INSERT INTO `index_process` VALUES(6, 'catalog_category_product', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:55', 'real_time');
INSERT INTO `index_process` VALUES(7, 'catalogsearch_fulltext', 'pending', '2011-04-27 19:40:55', '2011-04-27 19:40:55', 'real_time');
INSERT INTO `index_process` VALUES(8, 'cataloginventory_stock', 'pending', '2011-04-27 19:40:54', '2011-04-27 19:40:54', 'real_time');
INSERT INTO `index_process` VALUES(9, 'tag_summary', 'pending', '2011-04-27 19:40:55', '2011-04-27 19:40:55', 'real_time');

-- --------------------------------------------------------

--
-- Table structure for table `index_process_event`
--

CREATE TABLE `index_process_event` (
  `process_id` int(10) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `status` enum('new','working','done','error') NOT NULL default 'new',
  PRIMARY KEY  (`process_id`,`event_id`),
  KEY `FK_INDEX_EVNT_PROCESS` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `index_process_event`
--

INSERT INTO `index_process_event` VALUES(3, 1, 'done');
INSERT INTO `index_process_event` VALUES(3, 2, 'done');
INSERT INTO `index_process_event` VALUES(6, 1, 'done');
INSERT INTO `index_process_event` VALUES(6, 2, 'done');
INSERT INTO `index_process_event` VALUES(7, 1, 'done');
INSERT INTO `index_process_event` VALUES(7, 2, 'done');

-- --------------------------------------------------------

--
-- Table structure for table `log_customer`
--

CREATE TABLE `log_customer` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `visitor_id` bigint(20) unsigned default NULL,
  `customer_id` int(11) NOT NULL default '0',
  `login_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `logout_at` datetime default NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `IDX_VISITOR` (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customers log information' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `log_customer`
--

INSERT INTO `log_customer` VALUES(1, 9, 1, '2011-05-18 20:40:26', '2011-05-18 23:05:22', 1);
INSERT INTO `log_customer` VALUES(2, 99, 1, '2011-05-18 23:07:01', '2011-05-18 23:07:10', 1);
INSERT INTO `log_customer` VALUES(3, 101, 1, '2011-05-18 23:07:42', '2011-05-18 23:08:09', 1);
INSERT INTO `log_customer` VALUES(4, 103, 1, '2011-05-18 23:08:19', '2011-05-18 23:09:23', 1);
INSERT INTO `log_customer` VALUES(5, 104, 1, '2011-05-18 23:09:41', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `log_quote`
--

CREATE TABLE `log_quote` (
  `quote_id` int(10) unsigned NOT NULL default '0',
  `visitor_id` bigint(20) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `deleted_at` datetime default NULL,
  PRIMARY KEY  (`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Quote log data';

--
-- Dumping data for table `log_quote`
--


-- --------------------------------------------------------

--
-- Table structure for table `log_summary`
--

CREATE TABLE `log_summary` (
  `summary_id` bigint(20) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL,
  `type_id` smallint(5) unsigned default NULL,
  `visitor_count` int(11) NOT NULL default '0',
  `customer_count` int(11) NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`summary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Summary log information' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `log_summary`
--


-- --------------------------------------------------------

--
-- Table structure for table `log_summary_type`
--

CREATE TABLE `log_summary_type` (
  `type_id` smallint(5) unsigned NOT NULL auto_increment,
  `type_code` varchar(64) NOT NULL default '',
  `period` smallint(5) unsigned NOT NULL default '0',
  `period_type` enum('MINUTE','HOUR','DAY','WEEK','MONTH') NOT NULL default 'MINUTE',
  PRIMARY KEY  (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Type of summary information' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `log_summary_type`
--

INSERT INTO `log_summary_type` VALUES(1, 'hour', 1, 'HOUR');
INSERT INTO `log_summary_type` VALUES(2, 'day', 1, 'DAY');

-- --------------------------------------------------------

--
-- Table structure for table `log_url`
--

CREATE TABLE `log_url` (
  `url_id` bigint(20) unsigned NOT NULL default '0',
  `visitor_id` bigint(20) unsigned default NULL,
  `visit_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`url_id`),
  KEY `IDX_VISITOR` (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='URL visiting history';

--
-- Dumping data for table `log_url`
--

INSERT INTO `log_url` VALUES(1, 1, '2011-04-27 19:40:26');
INSERT INTO `log_url` VALUES(2, 1, '2011-04-27 19:40:58');
INSERT INTO `log_url` VALUES(3, 1, '2011-04-27 20:01:08');
INSERT INTO `log_url` VALUES(4, 1, '2011-04-27 20:13:29');
INSERT INTO `log_url` VALUES(5, 1, '2011-04-27 20:18:24');
INSERT INTO `log_url` VALUES(6, 1, '2011-04-27 20:18:26');
INSERT INTO `log_url` VALUES(7, 1, '2011-04-27 20:18:27');
INSERT INTO `log_url` VALUES(8, 1, '2011-04-27 20:18:29');
INSERT INTO `log_url` VALUES(9, 1, '2011-04-27 20:18:30');
INSERT INTO `log_url` VALUES(10, 1, '2011-04-27 20:19:20');
INSERT INTO `log_url` VALUES(11, 1, '2011-04-27 20:19:22');
INSERT INTO `log_url` VALUES(12, 1, '2011-04-27 20:19:24');
INSERT INTO `log_url` VALUES(13, 1, '2011-04-27 20:19:27');
INSERT INTO `log_url` VALUES(14, 1, '2011-04-27 20:20:36');
INSERT INTO `log_url` VALUES(15, 1, '2011-04-27 20:20:43');
INSERT INTO `log_url` VALUES(16, 1, '2011-04-27 20:20:45');
INSERT INTO `log_url` VALUES(17, 1, '2011-04-27 20:20:47');
INSERT INTO `log_url` VALUES(18, 1, '2011-04-27 20:20:54');
INSERT INTO `log_url` VALUES(19, 1, '2011-04-27 20:21:00');
INSERT INTO `log_url` VALUES(20, 1, '2011-04-27 20:24:36');
INSERT INTO `log_url` VALUES(21, 1, '2011-04-27 20:24:37');
INSERT INTO `log_url` VALUES(22, 1, '2011-04-27 20:27:29');
INSERT INTO `log_url` VALUES(23, 1, '2011-04-27 20:27:47');
INSERT INTO `log_url` VALUES(24, 1, '2011-04-27 20:27:49');
INSERT INTO `log_url` VALUES(25, 1, '2011-04-27 20:28:03');
INSERT INTO `log_url` VALUES(26, 1, '2011-04-27 20:28:05');
INSERT INTO `log_url` VALUES(27, 1, '2011-04-27 20:28:33');
INSERT INTO `log_url` VALUES(28, 1, '2011-04-27 20:28:42');
INSERT INTO `log_url` VALUES(29, 1, '2011-04-27 20:28:49');
INSERT INTO `log_url` VALUES(30, 1, '2011-04-27 20:29:02');
INSERT INTO `log_url` VALUES(31, 1, '2011-04-27 20:29:06');
INSERT INTO `log_url` VALUES(32, 1, '2011-04-27 20:31:10');
INSERT INTO `log_url` VALUES(33, 1, '2011-04-27 20:31:52');
INSERT INTO `log_url` VALUES(34, 1, '2011-04-27 20:32:25');
INSERT INTO `log_url` VALUES(35, 1, '2011-04-27 20:32:40');
INSERT INTO `log_url` VALUES(36, 1, '2011-04-27 20:32:41');
INSERT INTO `log_url` VALUES(37, 1, '2011-04-27 20:44:49');
INSERT INTO `log_url` VALUES(38, 3, '2011-05-12 17:23:23');
INSERT INTO `log_url` VALUES(39, 3, '2011-05-12 17:29:16');
INSERT INTO `log_url` VALUES(40, 3, '2011-05-12 17:29:59');
INSERT INTO `log_url` VALUES(41, 3, '2011-05-12 17:30:01');
INSERT INTO `log_url` VALUES(42, 3, '2011-05-12 17:30:02');
INSERT INTO `log_url` VALUES(43, 3, '2011-05-12 17:30:04');
INSERT INTO `log_url` VALUES(44, 3, '2011-05-12 17:30:23');
INSERT INTO `log_url` VALUES(45, 3, '2011-05-12 17:30:25');
INSERT INTO `log_url` VALUES(46, 5, '2011-05-13 21:29:46');
INSERT INTO `log_url` VALUES(47, 5, '2011-05-13 21:29:55');
INSERT INTO `log_url` VALUES(48, 5, '2011-05-13 21:31:19');
INSERT INTO `log_url` VALUES(49, 7, '2011-05-17 20:44:40');
INSERT INTO `log_url` VALUES(50, 7, '2011-05-17 20:58:29');
INSERT INTO `log_url` VALUES(51, 7, '2011-05-17 20:59:43');
INSERT INTO `log_url` VALUES(52, 7, '2011-05-17 21:00:03');
INSERT INTO `log_url` VALUES(53, 7, '2011-05-17 21:00:04');
INSERT INTO `log_url` VALUES(54, 7, '2011-05-17 21:03:13');
INSERT INTO `log_url` VALUES(55, 7, '2011-05-17 21:03:14');
INSERT INTO `log_url` VALUES(56, 9, '2011-05-18 20:34:42');
INSERT INTO `log_url` VALUES(57, 9, '2011-05-18 20:38:31');
INSERT INTO `log_url` VALUES(58, 9, '2011-05-18 20:39:46');
INSERT INTO `log_url` VALUES(59, 9, '2011-05-18 20:39:58');
INSERT INTO `log_url` VALUES(60, 9, '2011-05-18 20:40:26');
INSERT INTO `log_url` VALUES(61, 9, '2011-05-18 20:40:31');
INSERT INTO `log_url` VALUES(62, 9, '2011-05-18 21:02:42');
INSERT INTO `log_url` VALUES(63, 9, '2011-05-18 21:14:40');
INSERT INTO `log_url` VALUES(64, 9, '2011-05-18 21:18:13');
INSERT INTO `log_url` VALUES(65, 9, '2011-05-18 21:21:12');
INSERT INTO `log_url` VALUES(66, 9, '2011-05-18 21:21:17');
INSERT INTO `log_url` VALUES(67, 9, '2011-05-18 21:22:14');
INSERT INTO `log_url` VALUES(68, 9, '2011-05-18 21:23:11');
INSERT INTO `log_url` VALUES(69, 9, '2011-05-18 21:32:28');
INSERT INTO `log_url` VALUES(70, 9, '2011-05-18 21:33:04');
INSERT INTO `log_url` VALUES(71, 9, '2011-05-18 21:54:45');
INSERT INTO `log_url` VALUES(72, 9, '2011-05-18 21:56:38');
INSERT INTO `log_url` VALUES(73, 9, '2011-05-18 21:58:58');
INSERT INTO `log_url` VALUES(74, 9, '2011-05-18 22:01:48');
INSERT INTO `log_url` VALUES(75, 9, '2011-05-18 22:02:00');
INSERT INTO `log_url` VALUES(76, 9, '2011-05-18 22:02:02');
INSERT INTO `log_url` VALUES(77, 9, '2011-05-18 22:02:53');
INSERT INTO `log_url` VALUES(78, 9, '2011-05-18 22:14:45');
INSERT INTO `log_url` VALUES(79, 9, '2011-05-18 22:15:24');
INSERT INTO `log_url` VALUES(80, 9, '2011-05-18 22:16:20');
INSERT INTO `log_url` VALUES(81, 9, '2011-05-18 22:16:23');
INSERT INTO `log_url` VALUES(82, 9, '2011-05-18 22:16:50');
INSERT INTO `log_url` VALUES(83, 9, '2011-05-18 22:17:14');
INSERT INTO `log_url` VALUES(84, 9, '2011-05-18 22:21:48');
INSERT INTO `log_url` VALUES(85, 9, '2011-05-18 22:22:41');
INSERT INTO `log_url` VALUES(86, 9, '2011-05-18 22:25:12');
INSERT INTO `log_url` VALUES(87, 9, '2011-05-18 22:25:15');
INSERT INTO `log_url` VALUES(88, 9, '2011-05-18 22:25:16');
INSERT INTO `log_url` VALUES(89, 9, '2011-05-18 22:25:17');
INSERT INTO `log_url` VALUES(90, 9, '2011-05-18 22:25:18');
INSERT INTO `log_url` VALUES(91, 9, '2011-05-18 22:25:18');
INSERT INTO `log_url` VALUES(92, 9, '2011-05-18 22:25:19');
INSERT INTO `log_url` VALUES(93, 9, '2011-05-18 22:25:19');
INSERT INTO `log_url` VALUES(94, 9, '2011-05-18 22:25:19');
INSERT INTO `log_url` VALUES(95, 9, '2011-05-18 22:25:20');
INSERT INTO `log_url` VALUES(96, 9, '2011-05-18 22:30:09');
INSERT INTO `log_url` VALUES(97, 9, '2011-05-18 22:31:07');
INSERT INTO `log_url` VALUES(98, 9, '2011-05-18 22:32:47');
INSERT INTO `log_url` VALUES(99, 9, '2011-05-18 22:33:58');
INSERT INTO `log_url` VALUES(100, 9, '2011-05-18 22:34:31');
INSERT INTO `log_url` VALUES(101, 9, '2011-05-18 22:35:16');
INSERT INTO `log_url` VALUES(102, 9, '2011-05-18 22:36:39');
INSERT INTO `log_url` VALUES(103, 9, '2011-05-18 22:38:00');
INSERT INTO `log_url` VALUES(104, 9, '2011-05-18 22:38:02');
INSERT INTO `log_url` VALUES(105, 9, '2011-05-18 22:39:07');
INSERT INTO `log_url` VALUES(106, 9, '2011-05-18 22:40:38');
INSERT INTO `log_url` VALUES(107, 9, '2011-05-18 22:46:06');
INSERT INTO `log_url` VALUES(108, 9, '2011-05-18 22:52:08');
INSERT INTO `log_url` VALUES(109, 9, '2011-05-18 22:54:24');
INSERT INTO `log_url` VALUES(110, 9, '2011-05-18 22:54:26');
INSERT INTO `log_url` VALUES(111, 9, '2011-05-18 22:55:40');
INSERT INTO `log_url` VALUES(112, 9, '2011-05-18 22:55:42');
INSERT INTO `log_url` VALUES(113, 9, '2011-05-18 22:55:42');
INSERT INTO `log_url` VALUES(114, 9, '2011-05-18 22:56:21');
INSERT INTO `log_url` VALUES(115, 9, '2011-05-18 22:56:25');
INSERT INTO `log_url` VALUES(116, 9, '2011-05-18 22:56:25');
INSERT INTO `log_url` VALUES(117, 9, '2011-05-18 22:56:26');
INSERT INTO `log_url` VALUES(118, 9, '2011-05-18 22:56:26');
INSERT INTO `log_url` VALUES(119, 9, '2011-05-18 22:56:27');
INSERT INTO `log_url` VALUES(120, 9, '2011-05-18 22:56:27');
INSERT INTO `log_url` VALUES(121, 9, '2011-05-18 22:57:15');
INSERT INTO `log_url` VALUES(122, 9, '2011-05-18 22:57:17');
INSERT INTO `log_url` VALUES(123, 9, '2011-05-18 22:57:17');
INSERT INTO `log_url` VALUES(124, 9, '2011-05-18 22:57:18');
INSERT INTO `log_url` VALUES(125, 9, '2011-05-18 22:57:20');
INSERT INTO `log_url` VALUES(126, 9, '2011-05-18 22:57:20');
INSERT INTO `log_url` VALUES(127, 9, '2011-05-18 22:57:37');
INSERT INTO `log_url` VALUES(128, 9, '2011-05-18 22:57:38');
INSERT INTO `log_url` VALUES(129, 9, '2011-05-18 22:57:39');
INSERT INTO `log_url` VALUES(130, 9, '2011-05-18 22:58:33');
INSERT INTO `log_url` VALUES(131, 9, '2011-05-18 23:05:09');
INSERT INTO `log_url` VALUES(132, 9, '2011-05-18 23:05:22');
INSERT INTO `log_url` VALUES(133, 99, '2011-05-18 23:06:48');
INSERT INTO `log_url` VALUES(134, 99, '2011-05-18 23:06:54');
INSERT INTO `log_url` VALUES(135, 99, '2011-05-18 23:07:01');
INSERT INTO `log_url` VALUES(136, 99, '2011-05-18 23:07:02');
INSERT INTO `log_url` VALUES(137, 99, '2011-05-18 23:07:10');
INSERT INTO `log_url` VALUES(138, 101, '2011-05-18 23:07:12');
INSERT INTO `log_url` VALUES(139, 101, '2011-05-18 23:07:16');
INSERT INTO `log_url` VALUES(140, 101, '2011-05-18 23:07:19');
INSERT INTO `log_url` VALUES(141, 101, '2011-05-18 23:07:42');
INSERT INTO `log_url` VALUES(142, 101, '2011-05-18 23:07:43');
INSERT INTO `log_url` VALUES(143, 101, '2011-05-18 23:07:48');
INSERT INTO `log_url` VALUES(144, 101, '2011-05-18 23:07:54');
INSERT INTO `log_url` VALUES(145, 101, '2011-05-18 23:07:55');
INSERT INTO `log_url` VALUES(146, 101, '2011-05-18 23:08:09');
INSERT INTO `log_url` VALUES(147, 103, '2011-05-18 23:08:11');
INSERT INTO `log_url` VALUES(148, 103, '2011-05-18 23:08:19');
INSERT INTO `log_url` VALUES(149, 103, '2011-05-18 23:08:20');
INSERT INTO `log_url` VALUES(150, 103, '2011-05-18 23:08:27');
INSERT INTO `log_url` VALUES(151, 103, '2011-05-18 23:09:23');
INSERT INTO `log_url` VALUES(152, 104, '2011-05-18 23:09:25');
INSERT INTO `log_url` VALUES(153, 104, '2011-05-18 23:09:32');
INSERT INTO `log_url` VALUES(154, 104, '2011-05-18 23:09:38');
INSERT INTO `log_url` VALUES(155, 104, '2011-05-18 23:09:41');
INSERT INTO `log_url` VALUES(156, 104, '2011-05-18 23:09:43');

-- --------------------------------------------------------

--
-- Table structure for table `log_url_info`
--

CREATE TABLE `log_url_info` (
  `url_id` bigint(20) unsigned NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `referer` varchar(255) default NULL,
  PRIMARY KEY  (`url_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Detale information about url visit' AUTO_INCREMENT=157 ;

--
-- Dumping data for table `log_url_info`
--

INSERT INTO `log_url_info` VALUES(1, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/install/wizard/end/');
INSERT INTO `log_url_info` VALUES(2, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/install/wizard/end/');
INSERT INTO `log_url_info` VALUES(3, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(4, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(5, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(6, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(7, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(8, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(9, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(10, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(11, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(12, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(13, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(14, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(15, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(16, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(17, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(18, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(19, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(20, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(21, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(22, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(23, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(24, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(25, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(26, 'http://local.rooja/index.php/customer/account/login/?___SID=U', 'http://local.rooja/index.php/customer/account/login/?___SID=U');
INSERT INTO `log_url_info` VALUES(27, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(28, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(29, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(30, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(31, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(32, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(33, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(34, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(35, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(36, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(37, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(38, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(39, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(40, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(41, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(42, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(43, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(44, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(45, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(46, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(47, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(48, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_FRONTEND/invite.php');
INSERT INTO `log_url_info` VALUES(49, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(50, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_frontend/invite.php');
INSERT INTO `log_url_info` VALUES(51, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_frontend/invite.php');
INSERT INTO `log_url_info` VALUES(52, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_frontend/product-details.php');
INSERT INTO `log_url_info` VALUES(53, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_frontend/product-details.php');
INSERT INTO `log_url_info` VALUES(54, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_frontend/product-details.php');
INSERT INTO `log_url_info` VALUES(55, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/_frontend/product-details.php');
INSERT INTO `log_url_info` VALUES(56, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(57, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(58, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(59, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(60, 'http://local.rooja/index.php/customer/account/createpost/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(61, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(62, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(63, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(64, 'http://local.rooja/_frontent', '');
INSERT INTO `log_url_info` VALUES(65, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(66, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(67, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(68, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(69, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(70, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(71, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(72, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(73, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(74, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(75, 'http://local.rooja/index.php/_frontent', '');
INSERT INTO `log_url_info` VALUES(76, 'http://local.rooja/index.php/_frontend', '');
INSERT INTO `log_url_info` VALUES(77, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(78, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(79, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(80, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(81, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(82, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(83, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/create/');
INSERT INTO `log_url_info` VALUES(84, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(85, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(86, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(87, 'http://local.rooja/index.php/_images/photos/home/7.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(88, 'http://local.rooja/index.php/_images/photos/home/6.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(89, 'http://local.rooja/index.php/_images/photos/home/5.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(90, 'http://local.rooja/index.php/_images/photos/home/3.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(91, 'http://local.rooja/index.php/_images/photos/home/1.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(92, 'http://local.rooja/index.php/_images/photos/home/9.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(93, 'http://local.rooja/index.php/_images/photos/home/8.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(94, 'http://local.rooja/index.php/_images/photos/home/2.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(95, 'http://local.rooja/index.php/_images/photos/home/4.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(96, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(97, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(98, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(99, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(100, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(101, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(102, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(103, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(104, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(105, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(106, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(107, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(108, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(109, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(110, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(111, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(112, 'http://local.rooja/index.php/_images/icons/twitter-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(113, 'http://local.rooja/index.php/_images/icons/facebook-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(114, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(115, 'http://local.rooja/index.php/_images/photos/home/ending-soon-4.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(116, 'http://local.rooja/index.php/_images/icons/twitter-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(117, 'http://local.rooja/index.php/_images/icons/facebook-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(118, 'http://local.rooja/index.php/_images/photos/home/ending-soon-3.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(119, 'http://local.rooja/index.php/_images/photos/home/ending-soon-1.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(120, 'http://local.rooja/index.php/_images/photos/home/ending-soon-2.jpg', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(121, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(122, 'http://local.rooja/index.php/_images/icons/twitter-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(123, 'http://local.rooja/index.php/_images/icons/facebook-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(124, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(125, 'http://local.rooja/index.php/_images/icons/facebook-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(126, 'http://local.rooja/index.php/_images/icons/twitter-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(127, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(128, 'http://local.rooja/index.php/_images/icons/facebook-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(129, 'http://local.rooja/index.php/_images/icons/twitter-brown.png', 'http://local.rooja/index.php/');
INSERT INTO `log_url_info` VALUES(130, 'http://local.rooja/index.php/', '');
INSERT INTO `log_url_info` VALUES(131, 'http://local.rooja/index.php/customer/logout/', '');
INSERT INTO `log_url_info` VALUES(132, 'http://local.rooja/index.php/customer/account/logout/', '');
INSERT INTO `log_url_info` VALUES(133, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(134, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(135, 'http://local.rooja/index.php/customer/account/loginPost/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(136, 'http://local.rooja/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(137, 'http://local.rooja/customer/account/logout', '');
INSERT INTO `log_url_info` VALUES(138, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(139, 'http://local.rooja/index.php/customer/account/create/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(140, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(141, 'http://local.rooja/index.php/customer/account/loginPost/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(142, 'http://local.rooja/index.php/customer/account/logoutSuccess/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(143, 'http://local.rooja/index.php/customer/account/logoutSuccess/index.php', 'http://local.rooja/index.php/customer/account/logoutSuccess/');
INSERT INTO `log_url_info` VALUES(144, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/logoutSuccess/index.php');
INSERT INTO `log_url_info` VALUES(145, 'http://local.rooja/', '');
INSERT INTO `log_url_info` VALUES(146, 'http://local.rooja/customer/account/logout', '');
INSERT INTO `log_url_info` VALUES(147, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(148, 'http://local.rooja/index.php/customer/account/loginPost/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(149, 'http://local.rooja/index.php/customer/account/logoutSuccess/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(150, 'http://local.rooja/index.php/', 'http://local.rooja/index.php/customer/account/logoutSuccess/');
INSERT INTO `log_url_info` VALUES(151, 'http://local.rooja/index.php/customer/account/logout/', '');
INSERT INTO `log_url_info` VALUES(152, 'http://local.rooja/index.php/customer/account/logoutSuccess/', '');
INSERT INTO `log_url_info` VALUES(153, 'http://local.rooja/index.php/customer/account/login/', 'http://local.rooja/index.php/customer/account/logoutSuccess/');
INSERT INTO `log_url_info` VALUES(154, 'http://local.rooja/index.php/customer/account/login/', '');
INSERT INTO `log_url_info` VALUES(155, 'http://local.rooja/index.php/customer/account/loginPost/', 'http://local.rooja/index.php/customer/account/login/');
INSERT INTO `log_url_info` VALUES(156, 'http://local.rooja/', 'http://local.rooja/index.php/customer/account/login/');

-- --------------------------------------------------------

--
-- Table structure for table `log_visitor`
--

CREATE TABLE `log_visitor` (
  `visitor_id` bigint(20) unsigned NOT NULL auto_increment,
  `session_id` char(64) NOT NULL default '',
  `first_visit_at` datetime default NULL,
  `last_visit_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_url_id` bigint(20) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='System visitors log' AUTO_INCREMENT=105 ;

--
-- Dumping data for table `log_visitor`
--

INSERT INTO `log_visitor` VALUES(1, '0280c0bfc11de8802e5ea0c38d02f8d3', '2011-04-27 19:40:25', '2011-04-27 20:44:49', 37, 1);
INSERT INTO `log_visitor` VALUES(2, 'ad6c61cf6065bd87b2bb71a75e304093', '2011-05-12 17:23:21', '2011-05-12 17:23:21', 0, 1);
INSERT INTO `log_visitor` VALUES(3, 'ad6c61cf6065bd87b2bb71a75e304093', '2011-05-12 17:23:23', '2011-05-12 17:30:25', 45, 1);
INSERT INTO `log_visitor` VALUES(4, 'dcbfb99ee962241648b97eac83de3d2e', '2011-05-13 21:29:43', '2011-05-13 21:29:43', 0, 1);
INSERT INTO `log_visitor` VALUES(5, 'dcbfb99ee962241648b97eac83de3d2e', '2011-05-13 21:29:45', '2011-05-13 21:31:19', 48, 1);
INSERT INTO `log_visitor` VALUES(6, '3b8501bbc501a396d4e9b6d6d67f536f', '2011-05-17 20:44:38', '2011-05-17 20:44:38', 0, 1);
INSERT INTO `log_visitor` VALUES(7, '3b8501bbc501a396d4e9b6d6d67f536f', '2011-05-17 20:44:40', '2011-05-17 21:03:14', 55, 1);
INSERT INTO `log_visitor` VALUES(8, '28849058cc38be39f2ce2576211c82f9', '2011-05-18 20:34:39', '2011-05-18 20:34:39', 0, 1);
INSERT INTO `log_visitor` VALUES(9, '28849058cc38be39f2ce2576211c82f9', '2011-05-18 20:34:41', '2011-05-18 23:05:22', 132, 1);
INSERT INTO `log_visitor` VALUES(10, 'dda5dff68ac70e60489ea0aa0739efd9', '2011-05-18 23:04:24', '2011-05-18 23:04:24', 0, 1);
INSERT INTO `log_visitor` VALUES(11, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:26', '2011-05-18 23:04:26', 0, 1);
INSERT INTO `log_visitor` VALUES(12, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:27', '2011-05-18 23:04:27', 0, 1);
INSERT INTO `log_visitor` VALUES(13, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:27', '2011-05-18 23:04:27', 0, 1);
INSERT INTO `log_visitor` VALUES(14, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:29', '2011-05-18 23:04:29', 0, 1);
INSERT INTO `log_visitor` VALUES(15, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:30', '2011-05-18 23:04:30', 0, 1);
INSERT INTO `log_visitor` VALUES(16, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:31', '2011-05-18 23:04:31', 0, 1);
INSERT INTO `log_visitor` VALUES(17, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:32', '2011-05-18 23:04:32', 0, 1);
INSERT INTO `log_visitor` VALUES(18, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:33', '2011-05-18 23:04:33', 0, 1);
INSERT INTO `log_visitor` VALUES(19, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:35', '2011-05-18 23:04:35', 0, 1);
INSERT INTO `log_visitor` VALUES(20, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:36', '2011-05-18 23:04:36', 0, 1);
INSERT INTO `log_visitor` VALUES(21, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:36', '2011-05-18 23:04:36', 0, 1);
INSERT INTO `log_visitor` VALUES(22, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:37', '2011-05-18 23:04:37', 0, 1);
INSERT INTO `log_visitor` VALUES(23, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:39', '2011-05-18 23:04:39', 0, 1);
INSERT INTO `log_visitor` VALUES(24, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:40', '2011-05-18 23:04:40', 0, 1);
INSERT INTO `log_visitor` VALUES(25, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:41', '2011-05-18 23:04:41', 0, 1);
INSERT INTO `log_visitor` VALUES(26, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:42', '2011-05-18 23:04:42', 0, 1);
INSERT INTO `log_visitor` VALUES(27, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:44', '2011-05-18 23:04:44', 0, 1);
INSERT INTO `log_visitor` VALUES(28, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:45', '2011-05-18 23:04:45', 0, 1);
INSERT INTO `log_visitor` VALUES(29, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:46', '2011-05-18 23:04:46', 0, 1);
INSERT INTO `log_visitor` VALUES(30, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:49', '2011-05-18 23:04:49', 0, 1);
INSERT INTO `log_visitor` VALUES(31, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:50', '2011-05-18 23:04:50', 0, 1);
INSERT INTO `log_visitor` VALUES(32, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:52', '2011-05-18 23:04:52', 0, 1);
INSERT INTO `log_visitor` VALUES(33, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:53', '2011-05-18 23:04:53', 0, 1);
INSERT INTO `log_visitor` VALUES(34, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:54', '2011-05-18 23:04:54', 0, 1);
INSERT INTO `log_visitor` VALUES(35, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:55', '2011-05-18 23:04:55', 0, 1);
INSERT INTO `log_visitor` VALUES(36, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:56', '2011-05-18 23:04:56', 0, 1);
INSERT INTO `log_visitor` VALUES(37, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:57', '2011-05-18 23:04:57', 0, 1);
INSERT INTO `log_visitor` VALUES(38, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:04:59', '2011-05-18 23:04:59', 0, 1);
INSERT INTO `log_visitor` VALUES(39, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:05:00', '2011-05-18 23:05:00', 0, 1);
INSERT INTO `log_visitor` VALUES(40, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:05:01', '2011-05-18 23:05:01', 0, 1);
INSERT INTO `log_visitor` VALUES(41, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:05:02', '2011-05-18 23:05:02', 0, 1);
INSERT INTO `log_visitor` VALUES(42, '947ae9d95a2d7cadbfea7ea7a0747edf', '2011-05-18 23:05:03', '2011-05-18 23:05:03', 0, 1);
INSERT INTO `log_visitor` VALUES(43, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:23', '2011-05-18 23:05:23', 0, 1);
INSERT INTO `log_visitor` VALUES(44, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:24', '2011-05-18 23:05:24', 0, 1);
INSERT INTO `log_visitor` VALUES(45, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:25', '2011-05-18 23:05:25', 0, 1);
INSERT INTO `log_visitor` VALUES(46, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:26', '2011-05-18 23:05:26', 0, 1);
INSERT INTO `log_visitor` VALUES(47, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:28', '2011-05-18 23:05:28', 0, 1);
INSERT INTO `log_visitor` VALUES(48, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:29', '2011-05-18 23:05:29', 0, 1);
INSERT INTO `log_visitor` VALUES(49, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:30', '2011-05-18 23:05:30', 0, 1);
INSERT INTO `log_visitor` VALUES(50, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:31', '2011-05-18 23:05:31', 0, 1);
INSERT INTO `log_visitor` VALUES(51, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:32', '2011-05-18 23:05:32', 0, 1);
INSERT INTO `log_visitor` VALUES(52, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:34', '2011-05-18 23:05:34', 0, 1);
INSERT INTO `log_visitor` VALUES(53, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:35', '2011-05-18 23:05:35', 0, 1);
INSERT INTO `log_visitor` VALUES(54, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:36', '2011-05-18 23:05:36', 0, 1);
INSERT INTO `log_visitor` VALUES(55, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:37', '2011-05-18 23:05:37', 0, 1);
INSERT INTO `log_visitor` VALUES(56, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:38', '2011-05-18 23:05:38', 0, 1);
INSERT INTO `log_visitor` VALUES(57, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:40', '2011-05-18 23:05:40', 0, 1);
INSERT INTO `log_visitor` VALUES(58, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:41', '2011-05-18 23:05:41', 0, 1);
INSERT INTO `log_visitor` VALUES(59, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:42', '2011-05-18 23:05:42', 0, 1);
INSERT INTO `log_visitor` VALUES(60, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:43', '2011-05-18 23:05:43', 0, 1);
INSERT INTO `log_visitor` VALUES(61, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:44', '2011-05-18 23:05:44', 0, 1);
INSERT INTO `log_visitor` VALUES(62, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:46', '2011-05-18 23:05:46', 0, 1);
INSERT INTO `log_visitor` VALUES(63, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:51', '2011-05-18 23:05:51', 0, 1);
INSERT INTO `log_visitor` VALUES(64, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:52', '2011-05-18 23:05:52', 0, 1);
INSERT INTO `log_visitor` VALUES(65, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:53', '2011-05-18 23:05:53', 0, 1);
INSERT INTO `log_visitor` VALUES(66, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:54', '2011-05-18 23:05:54', 0, 1);
INSERT INTO `log_visitor` VALUES(67, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:56', '2011-05-18 23:05:56', 0, 1);
INSERT INTO `log_visitor` VALUES(68, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:57', '2011-05-18 23:05:57', 0, 1);
INSERT INTO `log_visitor` VALUES(69, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:58', '2011-05-18 23:05:58', 0, 1);
INSERT INTO `log_visitor` VALUES(70, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:05:59', '2011-05-18 23:05:59', 0, 1);
INSERT INTO `log_visitor` VALUES(71, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:00', '2011-05-18 23:06:00', 0, 1);
INSERT INTO `log_visitor` VALUES(72, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:02', '2011-05-18 23:06:02', 0, 1);
INSERT INTO `log_visitor` VALUES(73, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:03', '2011-05-18 23:06:03', 0, 1);
INSERT INTO `log_visitor` VALUES(74, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:04', '2011-05-18 23:06:04', 0, 1);
INSERT INTO `log_visitor` VALUES(75, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:05', '2011-05-18 23:06:05', 0, 1);
INSERT INTO `log_visitor` VALUES(76, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:06', '2011-05-18 23:06:06', 0, 1);
INSERT INTO `log_visitor` VALUES(77, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:07', '2011-05-18 23:06:07', 0, 1);
INSERT INTO `log_visitor` VALUES(78, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:09', '2011-05-18 23:06:09', 0, 1);
INSERT INTO `log_visitor` VALUES(79, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:10', '2011-05-18 23:06:10', 0, 1);
INSERT INTO `log_visitor` VALUES(80, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:11', '2011-05-18 23:06:11', 0, 1);
INSERT INTO `log_visitor` VALUES(81, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:12', '2011-05-18 23:06:12', 0, 1);
INSERT INTO `log_visitor` VALUES(82, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:14', '2011-05-18 23:06:14', 0, 1);
INSERT INTO `log_visitor` VALUES(83, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:15', '2011-05-18 23:06:15', 0, 1);
INSERT INTO `log_visitor` VALUES(84, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:16', '2011-05-18 23:06:16', 0, 1);
INSERT INTO `log_visitor` VALUES(85, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:17', '2011-05-18 23:06:17', 0, 1);
INSERT INTO `log_visitor` VALUES(86, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:18', '2011-05-18 23:06:18', 0, 1);
INSERT INTO `log_visitor` VALUES(87, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:33', '2011-05-18 23:06:33', 0, 1);
INSERT INTO `log_visitor` VALUES(88, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:34', '2011-05-18 23:06:34', 0, 1);
INSERT INTO `log_visitor` VALUES(89, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:35', '2011-05-18 23:06:35', 0, 1);
INSERT INTO `log_visitor` VALUES(90, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:37', '2011-05-18 23:06:37', 0, 1);
INSERT INTO `log_visitor` VALUES(91, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:38', '2011-05-18 23:06:38', 0, 1);
INSERT INTO `log_visitor` VALUES(92, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:39', '2011-05-18 23:06:39', 0, 1);
INSERT INTO `log_visitor` VALUES(93, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:40', '2011-05-18 23:06:40', 0, 1);
INSERT INTO `log_visitor` VALUES(94, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:41', '2011-05-18 23:06:41', 0, 1);
INSERT INTO `log_visitor` VALUES(95, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:43', '2011-05-18 23:06:43', 0, 1);
INSERT INTO `log_visitor` VALUES(96, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:44', '2011-05-18 23:06:44', 0, 1);
INSERT INTO `log_visitor` VALUES(97, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:45', '2011-05-18 23:06:45', 0, 1);
INSERT INTO `log_visitor` VALUES(98, '459cef35cb4434becdd0510c31870a55', '2011-05-18 23:06:46', '2011-05-18 23:06:46', 0, 1);
INSERT INTO `log_visitor` VALUES(99, 'df94de79513e0d7f1eabf6a9a6811b8c', '2011-05-18 23:06:47', '2011-05-18 23:07:10', 137, 1);
INSERT INTO `log_visitor` VALUES(100, '0ee50941657836743697b155cdeaebc2', '2011-05-18 23:07:10', '2011-05-18 23:07:10', 0, 1);
INSERT INTO `log_visitor` VALUES(101, '766322ad2271be3cd4edacf9c5e466dc', '2011-05-18 23:07:12', '2011-05-18 23:08:09', 146, 1);
INSERT INTO `log_visitor` VALUES(102, 'f4086de1793bb99fbeeea14364c9ee20', '2011-05-18 23:08:10', '2011-05-18 23:08:10', 0, 1);
INSERT INTO `log_visitor` VALUES(103, 'f7724c0e06d2a5819bf32c1770c06bd6', '2011-05-18 23:08:11', '2011-05-18 23:09:23', 151, 1);
INSERT INTO `log_visitor` VALUES(104, 'ad4acd8559b2ed96acd75dd4bfc7460b', '2011-05-18 23:09:24', '2011-05-18 23:09:43', 156, 1);

-- --------------------------------------------------------

--
-- Table structure for table `log_visitor_info`
--

CREATE TABLE `log_visitor_info` (
  `visitor_id` bigint(20) unsigned NOT NULL default '0',
  `http_referer` varchar(255) default NULL,
  `http_user_agent` varchar(255) default NULL,
  `http_accept_charset` varchar(255) default NULL,
  `http_accept_language` varchar(255) default NULL,
  `server_addr` bigint(20) default NULL,
  `remote_addr` bigint(20) default NULL,
  PRIMARY KEY  (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Additional information by visitor';

--
-- Dumping data for table `log_visitor_info`
--

INSERT INTO `log_visitor_info` VALUES(1, 'http://local.rooja/index.php/install/wizard/end/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0) Gecko/20100101 Firefox/4.0', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(2, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(3, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(4, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(5, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(6, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(7, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(8, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(9, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(10, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(11, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(12, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(13, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(14, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(15, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(16, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(17, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(18, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(19, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(20, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(21, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(22, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(23, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(24, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(25, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(26, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(27, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(28, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(29, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(30, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(31, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(32, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(33, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(34, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(35, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(36, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(37, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(38, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(39, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(40, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(41, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(42, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24', 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 'en-US,en;q=0.8', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(43, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(44, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(45, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(46, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(47, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(48, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(49, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(50, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(51, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(52, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(53, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(54, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(55, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(56, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(57, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(58, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(59, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(60, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(61, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(62, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(63, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(64, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(65, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(66, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(67, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(68, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(69, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(70, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(71, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(72, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(73, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(74, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(75, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(76, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(77, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(78, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(79, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(80, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(81, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(82, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(83, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(84, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(85, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(86, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(87, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(88, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(89, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(90, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(91, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(92, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(93, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(94, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(95, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(96, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(97, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(98, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(99, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(100, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(101, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(102, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(103, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);
INSERT INTO `log_visitor_info` VALUES(104, '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'en-us,en;q=0.5', 2130706433, 2130706433);

-- --------------------------------------------------------

--
-- Table structure for table `log_visitor_online`
--

CREATE TABLE `log_visitor_online` (
  `visitor_id` bigint(20) unsigned NOT NULL auto_increment,
  `visitor_type` char(1) NOT NULL,
  `remote_addr` bigint(20) NOT NULL,
  `first_visit_at` datetime default NULL,
  `last_visit_at` datetime default NULL,
  `customer_id` int(10) unsigned default NULL,
  `last_url` varchar(255) default NULL,
  PRIMARY KEY  (`visitor_id`),
  KEY `IDX_VISITOR_TYPE` (`visitor_type`),
  KEY `IDX_VISIT_TIME` (`first_visit_at`,`last_visit_at`),
  KEY `IDX_CUSTOMER` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `log_visitor_online`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_problem`
--

CREATE TABLE `newsletter_problem` (
  `problem_id` int(7) unsigned NOT NULL auto_increment,
  `subscriber_id` int(7) unsigned default NULL,
  `queue_id` int(7) unsigned NOT NULL default '0',
  `problem_error_code` int(3) unsigned default '0',
  `problem_error_text` varchar(200) default NULL,
  PRIMARY KEY  (`problem_id`),
  KEY `FK_PROBLEM_SUBSCRIBER` (`subscriber_id`),
  KEY `FK_PROBLEM_QUEUE` (`queue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter problems' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `newsletter_problem`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_queue`
--

CREATE TABLE `newsletter_queue` (
  `queue_id` int(7) unsigned NOT NULL auto_increment,
  `template_id` int(7) unsigned NOT NULL default '0',
  `newsletter_type` int(3) default NULL,
  `newsletter_text` text,
  `newsletter_styles` text,
  `newsletter_subject` varchar(200) default NULL,
  `newsletter_sender_name` varchar(200) default NULL,
  `newsletter_sender_email` varchar(200) character set latin1 collate latin1_general_ci default NULL,
  `queue_status` int(3) unsigned NOT NULL default '0',
  `queue_start_at` datetime default NULL,
  `queue_finish_at` datetime default NULL,
  PRIMARY KEY  (`queue_id`),
  KEY `FK_QUEUE_TEMPLATE` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter queue' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `newsletter_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_queue_link`
--

CREATE TABLE `newsletter_queue_link` (
  `queue_link_id` int(9) unsigned NOT NULL auto_increment,
  `queue_id` int(7) unsigned NOT NULL default '0',
  `subscriber_id` int(7) unsigned NOT NULL default '0',
  `letter_sent_at` datetime default NULL,
  PRIMARY KEY  (`queue_link_id`),
  KEY `FK_QUEUE_LINK_SUBSCRIBER` (`subscriber_id`),
  KEY `FK_QUEUE_LINK_QUEUE` (`queue_id`),
  KEY `IDX_NEWSLETTER_QUEUE_LINK_SEND_AT` (`queue_id`,`letter_sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter queue to subscriber link' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `newsletter_queue_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_queue_store_link`
--

CREATE TABLE `newsletter_queue_store_link` (
  `queue_id` int(7) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`queue_id`,`store_id`),
  KEY `FK_NEWSLETTER_QUEUE_STORE_LINK_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletter_queue_store_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_subscriber`
--

CREATE TABLE `newsletter_subscriber` (
  `subscriber_id` int(7) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default '0',
  `change_status_at` datetime default NULL,
  `customer_id` int(11) unsigned NOT NULL default '0',
  `subscriber_email` varchar(150) character set latin1 collate latin1_general_ci NOT NULL default '',
  `subscriber_status` int(3) NOT NULL default '0',
  `subscriber_confirm_code` varchar(32) default 'NULL',
  PRIMARY KEY  (`subscriber_id`),
  KEY `FK_SUBSCRIBER_CUSTOMER` (`customer_id`),
  KEY `FK_NEWSLETTER_SUBSCRIBER_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter subscribers' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `newsletter_subscriber`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_template`
--

CREATE TABLE `newsletter_template` (
  `template_id` int(7) unsigned NOT NULL auto_increment,
  `template_code` varchar(150) default NULL,
  `template_text` text,
  `template_text_preprocessed` text COMMENT 'deprecated since 1.4.0.1',
  `template_styles` text,
  `template_type` int(3) unsigned default NULL,
  `template_subject` varchar(200) default NULL,
  `template_sender_name` varchar(200) default NULL,
  `template_sender_email` varchar(200) character set latin1 collate latin1_general_ci default NULL,
  `template_actual` tinyint(1) unsigned default '1',
  `added_at` datetime default NULL,
  `modified_at` datetime default NULL,
  PRIMARY KEY  (`template_id`),
  KEY `template_actual` (`template_actual`),
  KEY `added_at` (`added_at`),
  KEY `modified_at` (`modified_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter templates' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `newsletter_template`
--


-- --------------------------------------------------------

--
-- Table structure for table `paygate_authorizenet_debug`
--

CREATE TABLE `paygate_authorizenet_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `request_body` text,
  `response_body` text,
  `request_serialized` text,
  `result_serialized` text,
  `request_dump` text,
  `result_dump` text,
  PRIMARY KEY  (`debug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paygate_authorizenet_debug`
--


-- --------------------------------------------------------

--
-- Table structure for table `paypaluk_api_debug`
--

CREATE TABLE `paypaluk_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `debug_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`),
  KEY `debug_at` (`debug_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paypaluk_api_debug`
--


-- --------------------------------------------------------

--
-- Table structure for table `paypal_api_debug`
--

CREATE TABLE `paypal_api_debug` (
  `debug_id` int(10) unsigned NOT NULL auto_increment,
  `debug_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `request_body` text,
  `response_body` text,
  PRIMARY KEY  (`debug_id`),
  KEY `debug_at` (`debug_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paypal_api_debug`
--


-- --------------------------------------------------------

--
-- Table structure for table `paypal_cert`
--

CREATE TABLE `paypal_cert` (
  `cert_id` smallint(5) unsigned NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `content` mediumblob NOT NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`cert_id`),
  KEY `IDX_PAYPAL_CERT_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paypal_cert`
--


-- --------------------------------------------------------

--
-- Table structure for table `paypal_settlement_report`
--

CREATE TABLE `paypal_settlement_report` (
  `report_id` int(10) unsigned NOT NULL auto_increment,
  `report_date` date NOT NULL,
  `account_id` varchar(64) NOT NULL,
  `filename` varchar(24) NOT NULL,
  `last_modified` datetime NOT NULL,
  PRIMARY KEY  (`report_id`),
  UNIQUE KEY `UNQ_REPORT_DATE_ACCOUNT` (`report_date`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paypal_settlement_report`
--


-- --------------------------------------------------------

--
-- Table structure for table `paypal_settlement_report_row`
--

CREATE TABLE `paypal_settlement_report_row` (
  `row_id` int(10) unsigned NOT NULL auto_increment,
  `report_id` int(10) unsigned NOT NULL,
  `transaction_id` varchar(19) NOT NULL,
  `invoice_id` varchar(127) default NULL,
  `paypal_reference_id` varchar(19) NOT NULL,
  `paypal_reference_id_type` enum('ODR','TXN','SUB','PAP','') NOT NULL,
  `transaction_event_code` char(5) NOT NULL default '',
  `transaction_initiation_date` datetime default NULL,
  `transaction_completion_date` datetime default NULL,
  `transaction_debit_or_credit` enum('CR','DR') NOT NULL default 'CR',
  `gross_transaction_amount` decimal(20,6) NOT NULL default '0.000000',
  `gross_transaction_currency` char(3) NOT NULL default '',
  `fee_debit_or_credit` enum('CR','DR') NOT NULL,
  `fee_amount` decimal(20,6) NOT NULL default '0.000000',
  `fee_currency` char(3) NOT NULL,
  `custom_field` varchar(255) default NULL,
  `consumer_id` varchar(127) NOT NULL default '',
  PRIMARY KEY  (`row_id`),
  KEY `IDX_REPORT_ID` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paypal_settlement_report_row`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll`
--

CREATE TABLE `poll` (
  `poll_id` int(10) unsigned NOT NULL auto_increment,
  `poll_title` varchar(255) NOT NULL default '',
  `votes_count` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default '0',
  `date_posted` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_closed` datetime default NULL,
  `active` smallint(6) NOT NULL default '1',
  `closed` tinyint(1) NOT NULL default '0',
  `answers_display` smallint(6) default NULL,
  PRIMARY KEY  (`poll_id`),
  KEY `FK_POLL_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `poll`
--

INSERT INTO `poll` VALUES(1, 'What is your favorite color', 5, 1, '2011-04-27 14:39:22', NULL, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `poll_answer`
--

CREATE TABLE `poll_answer` (
  `answer_id` int(10) unsigned NOT NULL auto_increment,
  `poll_id` int(10) unsigned NOT NULL default '0',
  `answer_title` varchar(255) NOT NULL default '',
  `votes_count` int(10) unsigned NOT NULL default '0',
  `answer_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`answer_id`),
  KEY `FK_POLL_PARENT` (`poll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `poll_answer`
--

INSERT INTO `poll_answer` VALUES(1, 1, 'Green', 4, 0);
INSERT INTO `poll_answer` VALUES(2, 1, 'Red', 1, 0);
INSERT INTO `poll_answer` VALUES(3, 1, 'Black', 0, 0);
INSERT INTO `poll_answer` VALUES(4, 1, 'Magenta', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `poll_store`
--

CREATE TABLE `poll_store` (
  `poll_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`poll_id`,`store_id`),
  KEY `FK_POLL_STORE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `poll_store`
--

INSERT INTO `poll_store` VALUES(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `poll_vote`
--

CREATE TABLE `poll_vote` (
  `vote_id` int(10) unsigned NOT NULL auto_increment,
  `poll_id` int(10) unsigned NOT NULL default '0',
  `poll_answer_id` int(10) unsigned NOT NULL default '0',
  `ip_address` bigint(20) default NULL,
  `customer_id` int(11) default NULL,
  `vote_time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`vote_id`),
  KEY `FK_POLL_ANSWER` (`poll_answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `poll_vote`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_alert_price`
--

CREATE TABLE `product_alert_price` (
  `alert_price_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_send_date` datetime default NULL,
  `send_count` smallint(5) unsigned NOT NULL default '0',
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`alert_price_id`),
  KEY `FK_PRODUCT_ALERT_PRICE_CUSTOMER` (`customer_id`),
  KEY `FK_PRODUCT_ALERT_PRICE_PRODUCT` (`product_id`),
  KEY `FK_PRODUCT_ALERT_PRICE_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_alert_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_alert_stock`
--

CREATE TABLE `product_alert_stock` (
  `alert_stock_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `send_date` datetime default NULL,
  `send_count` smallint(5) unsigned NOT NULL default '0',
  `status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`alert_stock_id`),
  KEY `FK_PRODUCT_ALERT_STOCK_CUSTOMER` (`customer_id`),
  KEY `FK_PRODUCT_ALERT_STOCK_PRODUCT` (`product_id`),
  KEY `FK_PRODUCT_ALERT_STOCK_WEBSITE` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_alert_stock`
--


-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `rating_id` smallint(6) unsigned NOT NULL auto_increment,
  `entity_id` smallint(6) unsigned NOT NULL default '0',
  `rating_code` varchar(64) NOT NULL default '',
  `position` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rating_id`),
  UNIQUE KEY `IDX_CODE` (`rating_code`),
  KEY `FK_RATING_ENTITY` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ratings' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` VALUES(1, 1, 'Quality', 0);
INSERT INTO `rating` VALUES(2, 1, 'Value', 0);
INSERT INTO `rating` VALUES(3, 1, 'Price', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rating_entity`
--

CREATE TABLE `rating_entity` (
  `entity_id` smallint(6) unsigned NOT NULL auto_increment,
  `entity_code` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `IDX_CODE` (`entity_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating entities' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `rating_entity`
--

INSERT INTO `rating_entity` VALUES(1, 'product');
INSERT INTO `rating_entity` VALUES(2, 'product_review');
INSERT INTO `rating_entity` VALUES(3, 'review');

-- --------------------------------------------------------

--
-- Table structure for table `rating_option`
--

CREATE TABLE `rating_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `code` varchar(32) NOT NULL default '',
  `value` tinyint(3) unsigned NOT NULL default '0',
  `position` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`),
  KEY `FK_RATING_OPTION_RATING` (`rating_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating options' AUTO_INCREMENT=16 ;

--
-- Dumping data for table `rating_option`
--

INSERT INTO `rating_option` VALUES(1, 1, '1', 1, 1);
INSERT INTO `rating_option` VALUES(2, 1, '2', 2, 2);
INSERT INTO `rating_option` VALUES(3, 1, '3', 3, 3);
INSERT INTO `rating_option` VALUES(4, 1, '4', 4, 4);
INSERT INTO `rating_option` VALUES(5, 1, '5', 5, 5);
INSERT INTO `rating_option` VALUES(6, 2, '1', 1, 1);
INSERT INTO `rating_option` VALUES(7, 2, '2', 2, 2);
INSERT INTO `rating_option` VALUES(8, 2, '3', 3, 3);
INSERT INTO `rating_option` VALUES(9, 2, '4', 4, 4);
INSERT INTO `rating_option` VALUES(10, 2, '5', 5, 5);
INSERT INTO `rating_option` VALUES(11, 3, '1', 1, 1);
INSERT INTO `rating_option` VALUES(12, 3, '2', 2, 2);
INSERT INTO `rating_option` VALUES(13, 3, '3', 3, 3);
INSERT INTO `rating_option` VALUES(14, 3, '4', 4, 4);
INSERT INTO `rating_option` VALUES(15, 3, '5', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `rating_option_vote`
--

CREATE TABLE `rating_option_vote` (
  `vote_id` bigint(20) unsigned NOT NULL auto_increment,
  `option_id` int(10) unsigned NOT NULL default '0',
  `remote_ip` varchar(16) NOT NULL default '',
  `remote_ip_long` int(11) NOT NULL default '0',
  `customer_id` int(11) unsigned default '0',
  `entity_pk_value` bigint(20) unsigned NOT NULL default '0',
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `review_id` bigint(20) unsigned default NULL,
  `percent` tinyint(3) NOT NULL default '0',
  `value` tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (`vote_id`),
  KEY `FK_RATING_OPTION_VALUE_OPTION` (`option_id`),
  KEY `FK_RATING_OPTION_REVIEW_ID` (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating option values' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rating_option_vote`
--


-- --------------------------------------------------------

--
-- Table structure for table `rating_option_vote_aggregated`
--

CREATE TABLE `rating_option_vote_aggregated` (
  `primary_id` int(11) NOT NULL auto_increment,
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `entity_pk_value` bigint(20) unsigned NOT NULL default '0',
  `vote_count` int(10) unsigned NOT NULL default '0',
  `vote_value_sum` int(10) unsigned NOT NULL default '0',
  `percent` tinyint(3) NOT NULL default '0',
  `percent_approved` tinyint(3) default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`primary_id`),
  KEY `FK_RATING_OPTION_VALUE_AGGREGATE` (`rating_id`),
  KEY `FK_RATING_OPTION_VOTE_AGGREGATED_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rating_option_vote_aggregated`
--


-- --------------------------------------------------------

--
-- Table structure for table `rating_store`
--

CREATE TABLE `rating_store` (
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rating_id`,`store_id`),
  KEY `FK_RATING_STORE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rating_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `rating_title`
--

CREATE TABLE `rating_title` (
  `rating_id` smallint(6) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`rating_id`,`store_id`),
  KEY `FK_RATING_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rating_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `report_compared_product_index`
--

CREATE TABLE `report_compared_product_index` (
  `index_id` bigint(20) unsigned NOT NULL auto_increment,
  `visitor_id` int(10) unsigned default NULL,
  `customer_id` int(10) unsigned default NULL,
  `product_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned default NULL,
  `added_at` datetime NOT NULL,
  PRIMARY KEY  (`index_id`),
  UNIQUE KEY `UNQ_BY_VISITOR` (`visitor_id`,`product_id`),
  UNIQUE KEY `UNQ_BY_CUSTOMER` (`customer_id`,`product_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_SORT_ADDED_AT` (`added_at`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report_compared_product_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `report_event`
--

CREATE TABLE `report_event` (
  `event_id` bigint(20) unsigned NOT NULL auto_increment,
  `logged_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `event_type_id` smallint(6) unsigned NOT NULL default '0',
  `object_id` int(10) unsigned NOT NULL default '0',
  `subject_id` int(10) unsigned NOT NULL default '0',
  `subtype` tinyint(3) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`event_id`),
  KEY `IDX_EVENT_TYPE` (`event_type_id`),
  KEY `IDX_SUBJECT` (`subject_id`),
  KEY `IDX_OBJECT` (`object_id`),
  KEY `IDX_SUBTYPE` (`subtype`),
  KEY `FK_REPORT_EVENT_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report_event`
--


-- --------------------------------------------------------

--
-- Table structure for table `report_event_types`
--

CREATE TABLE `report_event_types` (
  `event_type_id` smallint(6) unsigned NOT NULL auto_increment,
  `event_name` varchar(64) NOT NULL,
  `customer_login` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`event_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `report_event_types`
--

INSERT INTO `report_event_types` VALUES(1, 'catalog_product_view', 1);
INSERT INTO `report_event_types` VALUES(2, 'sendfriend_product', 1);
INSERT INTO `report_event_types` VALUES(3, 'catalog_product_compare_add_product', 1);
INSERT INTO `report_event_types` VALUES(4, 'checkout_cart_add_product', 1);
INSERT INTO `report_event_types` VALUES(5, 'wishlist_add_product', 1);
INSERT INTO `report_event_types` VALUES(6, 'wishlist_share', 1);

-- --------------------------------------------------------

--
-- Table structure for table `report_viewed_product_index`
--

CREATE TABLE `report_viewed_product_index` (
  `index_id` bigint(20) unsigned NOT NULL auto_increment,
  `visitor_id` int(10) unsigned default NULL,
  `customer_id` int(10) unsigned default NULL,
  `product_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned default NULL,
  `added_at` datetime NOT NULL,
  PRIMARY KEY  (`index_id`),
  UNIQUE KEY `UNQ_BY_VISITOR` (`visitor_id`,`product_id`),
  UNIQUE KEY `UNQ_BY_CUSTOMER` (`customer_id`,`product_id`),
  KEY `IDX_STORE` (`store_id`),
  KEY `IDX_SORT_ADDED_AT` (`added_at`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report_viewed_product_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` bigint(20) unsigned NOT NULL auto_increment,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `entity_id` smallint(5) unsigned NOT NULL default '0',
  `entity_pk_value` int(10) unsigned NOT NULL default '0',
  `status_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`review_id`),
  KEY `FK_REVIEW_ENTITY` (`entity_id`),
  KEY `FK_REVIEW_STATUS` (`status_id`),
  KEY `FK_REVIEW_PARENT_PRODUCT` (`entity_pk_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review base information' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `review`
--


-- --------------------------------------------------------

--
-- Table structure for table `review_detail`
--

CREATE TABLE `review_detail` (
  `detail_id` bigint(20) unsigned NOT NULL auto_increment,
  `review_id` bigint(20) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default '0',
  `title` varchar(255) NOT NULL default '',
  `detail` text NOT NULL,
  `nickname` varchar(128) NOT NULL default '',
  `customer_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`detail_id`),
  KEY `FK_REVIEW_DETAIL_REVIEW` (`review_id`),
  KEY `FK_REVIEW_DETAIL_STORE` (`store_id`),
  KEY `FK_REVIEW_DETAIL_CUSTOMER` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review detail information' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `review_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `review_entity`
--

CREATE TABLE `review_entity` (
  `entity_id` smallint(5) unsigned NOT NULL auto_increment,
  `entity_code` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review entities' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `review_entity`
--

INSERT INTO `review_entity` VALUES(1, 'product');
INSERT INTO `review_entity` VALUES(2, 'customer');
INSERT INTO `review_entity` VALUES(3, 'category');

-- --------------------------------------------------------

--
-- Table structure for table `review_entity_summary`
--

CREATE TABLE `review_entity_summary` (
  `primary_id` bigint(20) NOT NULL auto_increment,
  `entity_pk_value` bigint(20) NOT NULL default '0',
  `entity_type` tinyint(4) NOT NULL default '0',
  `reviews_count` smallint(6) NOT NULL default '0',
  `rating_summary` tinyint(4) NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`primary_id`),
  KEY `FK_REVIEW_ENTITY_SUMMARY_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `review_entity_summary`
--


-- --------------------------------------------------------

--
-- Table structure for table `review_status`
--

CREATE TABLE `review_status` (
  `status_id` tinyint(3) unsigned NOT NULL auto_increment,
  `status_code` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review statuses' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `review_status`
--

INSERT INTO `review_status` VALUES(1, 'Approved');
INSERT INTO `review_status` VALUES(2, 'Pending');
INSERT INTO `review_status` VALUES(3, 'Not Approved');

-- --------------------------------------------------------

--
-- Table structure for table `review_store`
--

CREATE TABLE `review_store` (
  `review_id` bigint(20) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`review_id`,`store_id`),
  KEY `FK_REVIEW_STORE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `review_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesrule`
--

CREATE TABLE `salesrule` (
  `rule_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `from_date` date default '0000-00-00',
  `to_date` date default '0000-00-00',
  `uses_per_customer` int(11) NOT NULL default '0',
  `customer_group_ids` text,
  `is_active` tinyint(1) NOT NULL default '0',
  `conditions_serialized` mediumtext NOT NULL,
  `actions_serialized` mediumtext NOT NULL,
  `stop_rules_processing` tinyint(1) NOT NULL default '1',
  `is_advanced` tinyint(3) unsigned NOT NULL default '1',
  `product_ids` text,
  `sort_order` int(10) unsigned NOT NULL default '0',
  `simple_action` varchar(32) NOT NULL default '',
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `discount_qty` decimal(12,4) unsigned default NULL,
  `discount_step` int(10) unsigned NOT NULL,
  `simple_free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `apply_to_shipping` tinyint(1) unsigned NOT NULL default '0',
  `times_used` int(11) unsigned NOT NULL default '0',
  `is_rss` tinyint(4) NOT NULL default '0',
  `website_ids` text,
  `coupon_type` smallint(5) unsigned NOT NULL default '1',
  PRIMARY KEY  (`rule_id`),
  KEY `sort_order` (`is_active`,`sort_order`,`to_date`,`from_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesrule`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesrule_coupon`
--

CREATE TABLE `salesrule_coupon` (
  `coupon_id` int(10) unsigned NOT NULL auto_increment,
  `rule_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `usage_limit` int(10) unsigned default NULL,
  `usage_per_customer` int(10) unsigned default NULL,
  `times_used` int(10) unsigned NOT NULL default '0',
  `expiration_date` datetime default NULL,
  `is_primary` tinyint(1) unsigned default NULL,
  PRIMARY KEY  (`coupon_id`),
  UNIQUE KEY `UNQ_COUPON_CODE` (`code`),
  UNIQUE KEY `UNQ_RULE_MAIN_COUPON` (`rule_id`,`is_primary`),
  KEY `FK_SALESRULE_COUPON_RULE_ID_SALESRULE` (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesrule_coupon`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesrule_coupon_usage`
--

CREATE TABLE `salesrule_coupon_usage` (
  `coupon_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `times_used` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`coupon_id`,`customer_id`),
  KEY `FK_SALESRULE_COUPON_CUSTOMER_COUPON_ID_CUSTOMER_ENTITY` (`coupon_id`),
  KEY `FK_SALESRULE_COUPON_CUSTOMER_CUSTOMER_ID_CUSTOMER_ENTITY` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `salesrule_coupon_usage`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesrule_customer`
--

CREATE TABLE `salesrule_customer` (
  `rule_customer_id` int(10) unsigned NOT NULL auto_increment,
  `rule_id` int(10) unsigned NOT NULL default '0',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `times_used` smallint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rule_customer_id`),
  KEY `rule_id` (`rule_id`,`customer_id`),
  KEY `customer_id` (`customer_id`,`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesrule_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesrule_label`
--

CREATE TABLE `salesrule_label` (
  `label_id` int(10) unsigned NOT NULL auto_increment,
  `rule_id` int(10) unsigned NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `label` varchar(255) default NULL,
  PRIMARY KEY  (`label_id`),
  UNIQUE KEY `IDX_RULE_STORE` (`rule_id`,`store_id`),
  KEY `FK_SALESRULE_LABEL_STORE` (`store_id`),
  KEY `FK_SALESRULE_LABEL_RULE` (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesrule_label`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesrule_product_attribute`
--

CREATE TABLE `salesrule_product_attribute` (
  `rule_id` int(10) unsigned NOT NULL,
  `website_id` smallint(5) unsigned NOT NULL,
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `attribute_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`rule_id`,`website_id`,`customer_group_id`,`attribute_id`),
  KEY `IDX_WEBSITE` (`website_id`),
  KEY `IDX_CUSTOMER_GROUP` (`customer_group_id`),
  KEY `IDX_ATTRIBUTE` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `salesrule_product_attribute`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_bestsellers_aggregated_daily`
--

CREATE TABLE `sales_bestsellers_aggregated_daily` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `product_id` int(10) unsigned default NULL,
  `product_name` varchar(255) NOT NULL default '',
  `product_price` decimal(12,4) NOT NULL default '0.0000',
  `qty_ordered` decimal(12,4) NOT NULL default '0.0000',
  `rating_pos` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_PRODUCT` (`period`,`store_id`,`product_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_PRODUCT_ID` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_bestsellers_aggregated_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_bestsellers_aggregated_monthly`
--

CREATE TABLE `sales_bestsellers_aggregated_monthly` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `product_id` int(10) unsigned default NULL,
  `product_name` varchar(255) NOT NULL default '',
  `product_price` decimal(12,4) NOT NULL default '0.0000',
  `qty_ordered` decimal(12,4) NOT NULL default '0.0000',
  `rating_pos` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_PRODUCT` (`period`,`store_id`,`product_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_PRODUCT_ID` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_bestsellers_aggregated_monthly`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_bestsellers_aggregated_yearly`
--

CREATE TABLE `sales_bestsellers_aggregated_yearly` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `product_id` int(10) unsigned default NULL,
  `product_name` varchar(255) NOT NULL default '',
  `product_price` decimal(12,4) NOT NULL default '0.0000',
  `qty_ordered` decimal(12,4) NOT NULL default '0.0000',
  `rating_pos` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_PRODUCT` (`period`,`store_id`,`product_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_PRODUCT_ID` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_bestsellers_aggregated_yearly`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_billing_agreement`
--

CREATE TABLE `sales_billing_agreement` (
  `agreement_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL,
  `method_code` varchar(32) NOT NULL,
  `reference_id` varchar(32) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime default NULL,
  `store_id` smallint(5) unsigned default NULL,
  `agreement_label` varchar(255) default NULL,
  PRIMARY KEY  (`agreement_id`),
  KEY `IDX_CUSTOMER` (`customer_id`),
  KEY `FK_BILLING_AGREEMENT_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_billing_agreement`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_billing_agreement_order`
--

CREATE TABLE `sales_billing_agreement_order` (
  `agreement_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `UNQ_BILLING_AGREEMENT_ORDER` (`agreement_id`,`order_id`),
  KEY `FK_BILLING_AGREEMENT_ORDER_ORDER` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sales_billing_agreement_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_creditmemo`
--

CREATE TABLE `sales_flat_creditmemo` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default NULL,
  `adjustment_positive` decimal(12,4) default NULL,
  `base_shipping_tax_amount` decimal(12,4) default NULL,
  `store_to_order_rate` decimal(12,4) default NULL,
  `base_discount_amount` decimal(12,4) default NULL,
  `base_to_order_rate` decimal(12,4) default NULL,
  `grand_total` decimal(12,4) default NULL,
  `base_adjustment_negative` decimal(12,4) default NULL,
  `base_subtotal_incl_tax` decimal(12,4) default NULL,
  `shipping_amount` decimal(12,4) default NULL,
  `subtotal_incl_tax` decimal(12,4) default NULL,
  `adjustment_negative` decimal(12,4) default NULL,
  `base_shipping_amount` decimal(12,4) default NULL,
  `store_to_base_rate` decimal(12,4) default NULL,
  `base_to_global_rate` decimal(12,4) default NULL,
  `base_adjustment` decimal(12,4) default NULL,
  `base_subtotal` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) default NULL,
  `subtotal` decimal(12,4) default NULL,
  `adjustment` decimal(12,4) default NULL,
  `base_grand_total` decimal(12,4) default NULL,
  `base_adjustment_positive` decimal(12,4) default NULL,
  `base_tax_amount` decimal(12,4) default NULL,
  `shipping_tax_amount` decimal(12,4) default NULL,
  `tax_amount` decimal(12,4) default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `email_sent` tinyint(1) unsigned default NULL,
  `creditmemo_status` int(10) default NULL,
  `state` int(10) default NULL,
  `shipping_address_id` int(10) default NULL,
  `billing_address_id` int(10) default NULL,
  `invoice_id` int(10) default NULL,
  `cybersource_token` varchar(255) default NULL,
  `store_currency_code` char(3) default NULL,
  `order_currency_code` char(3) default NULL,
  `base_currency_code` char(3) default NULL,
  `global_currency_code` char(3) default NULL,
  `transaction_id` varchar(255) default NULL,
  `increment_id` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `base_shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_incl_tax` decimal(12,4) default NULL,
  `base_shipping_incl_tax` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_CREDITMEMO_STATUS` (`creditmemo_status`),
  KEY `IDX_STATE` (`state`),
  KEY `IDX_CREATED_AT` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_creditmemo`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_creditmemo_comment`
--

CREATE TABLE `sales_flat_creditmemo_comment` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `is_customer_notified` int(10) default NULL,
  `is_visible_on_front` tinyint(1) unsigned NOT NULL default '0',
  `comment` text,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_creditmemo_comment`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_creditmemo_grid`
--

CREATE TABLE `sales_flat_creditmemo_grid` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default NULL,
  `store_to_order_rate` decimal(12,4) default NULL,
  `base_to_order_rate` decimal(12,4) default NULL,
  `grand_total` decimal(12,4) default NULL,
  `store_to_base_rate` decimal(12,4) default NULL,
  `base_to_global_rate` decimal(12,4) default NULL,
  `base_grand_total` decimal(12,4) default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `creditmemo_status` int(10) default NULL,
  `state` int(10) default NULL,
  `invoice_id` int(10) default NULL,
  `store_currency_code` char(3) default NULL,
  `order_currency_code` char(3) default NULL,
  `base_currency_code` char(3) default NULL,
  `global_currency_code` char(3) default NULL,
  `increment_id` varchar(50) default NULL,
  `order_increment_id` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `order_created_at` datetime default NULL,
  `billing_name` varchar(255) default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_GRAND_TOTAL` (`grand_total`),
  KEY `IDX_BASE_GRAND_TOTAL` (`base_grand_total`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_CREDITMEMO_STATUS` (`creditmemo_status`),
  KEY `IDX_STATE` (`state`),
  KEY `IDX_ORDER_INCREMENT_ID` (`order_increment_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_ORDER_CREATED_AT` (`order_created_at`),
  KEY `IDX_BILLING_NAME` (`billing_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_creditmemo_grid`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_creditmemo_item`
--

CREATE TABLE `sales_flat_creditmemo_item` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `base_price` decimal(12,4) default NULL,
  `base_weee_tax_row_disposition` decimal(12,4) default NULL,
  `tax_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_amount` decimal(12,4) default NULL,
  `weee_tax_row_disposition` decimal(12,4) default NULL,
  `base_row_total` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) default NULL,
  `row_total` decimal(12,4) default NULL,
  `weee_tax_applied_amount` decimal(12,4) default NULL,
  `base_discount_amount` decimal(12,4) default NULL,
  `base_weee_tax_disposition` decimal(12,4) default NULL,
  `price_incl_tax` decimal(12,4) default NULL,
  `base_tax_amount` decimal(12,4) default NULL,
  `weee_tax_disposition` decimal(12,4) default NULL,
  `base_price_incl_tax` decimal(12,4) default NULL,
  `qty` decimal(12,4) default NULL,
  `base_cost` decimal(12,4) default NULL,
  `base_weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `base_row_total_incl_tax` decimal(12,4) default NULL,
  `row_total_incl_tax` decimal(12,4) default NULL,
  `product_id` int(10) default NULL,
  `order_item_id` int(10) default NULL,
  `additional_data` text,
  `description` text,
  `weee_tax_applied` text,
  `sku` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_creditmemo_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_invoice`
--

CREATE TABLE `sales_flat_invoice` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default NULL,
  `base_grand_total` decimal(12,4) default NULL,
  `shipping_tax_amount` decimal(12,4) default NULL,
  `tax_amount` decimal(12,4) default NULL,
  `base_tax_amount` decimal(12,4) default NULL,
  `store_to_order_rate` decimal(12,4) default NULL,
  `base_shipping_tax_amount` decimal(12,4) default NULL,
  `base_discount_amount` decimal(12,4) default NULL,
  `base_to_order_rate` decimal(12,4) default NULL,
  `grand_total` decimal(12,4) default NULL,
  `shipping_amount` decimal(12,4) default NULL,
  `subtotal_incl_tax` decimal(12,4) default NULL,
  `base_subtotal_incl_tax` decimal(12,4) default NULL,
  `store_to_base_rate` decimal(12,4) default NULL,
  `base_shipping_amount` decimal(12,4) default NULL,
  `total_qty` decimal(12,4) default NULL,
  `base_to_global_rate` decimal(12,4) default NULL,
  `subtotal` decimal(12,4) default NULL,
  `base_subtotal` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) default NULL,
  `billing_address_id` int(10) default NULL,
  `is_used_for_refund` tinyint(1) unsigned default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `email_sent` tinyint(1) unsigned default NULL,
  `can_void_flag` tinyint(1) unsigned default NULL,
  `state` int(10) default NULL,
  `shipping_address_id` int(10) default NULL,
  `cybersource_token` varchar(255) default NULL,
  `store_currency_code` char(3) default NULL,
  `transaction_id` varchar(255) default NULL,
  `order_currency_code` char(3) default NULL,
  `base_currency_code` char(3) default NULL,
  `global_currency_code` char(3) default NULL,
  `increment_id` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `base_shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_incl_tax` decimal(12,4) default NULL,
  `base_shipping_incl_tax` decimal(12,4) default NULL,
  `base_total_refunded` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_GRAND_TOTAL` (`grand_total`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_STATE` (`state`),
  KEY `IDX_CREATED_AT` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_invoice`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_invoice_comment`
--

CREATE TABLE `sales_flat_invoice_comment` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `is_customer_notified` tinyint(1) unsigned default NULL,
  `is_visible_on_front` tinyint(1) unsigned NOT NULL default '0',
  `comment` text,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_invoice_comment`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_invoice_grid`
--

CREATE TABLE `sales_flat_invoice_grid` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default NULL,
  `base_grand_total` decimal(12,4) default NULL,
  `grand_total` decimal(12,4) default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `state` int(10) default NULL,
  `store_currency_code` char(3) default NULL,
  `order_currency_code` char(3) default NULL,
  `base_currency_code` char(3) default NULL,
  `global_currency_code` char(3) default NULL,
  `increment_id` varchar(50) default NULL,
  `order_increment_id` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `order_created_at` datetime default NULL,
  `billing_name` varchar(255) default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_GRAND_TOTAL` (`grand_total`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_STATE` (`state`),
  KEY `IDX_ORDER_INCREMENT_ID` (`order_increment_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_ORDER_CREATED_AT` (`order_created_at`),
  KEY `IDX_BILLING_NAME` (`billing_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_invoice_grid`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_invoice_item`
--

CREATE TABLE `sales_flat_invoice_item` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `base_price` decimal(12,4) default NULL,
  `base_weee_tax_row_disposition` decimal(12,4) default NULL,
  `weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_amount` decimal(12,4) default NULL,
  `tax_amount` decimal(12,4) default NULL,
  `base_row_total` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) default NULL,
  `row_total` decimal(12,4) default NULL,
  `weee_tax_row_disposition` decimal(12,4) default NULL,
  `base_discount_amount` decimal(12,4) default NULL,
  `base_weee_tax_disposition` decimal(12,4) default NULL,
  `price_incl_tax` decimal(12,4) default NULL,
  `weee_tax_applied_amount` decimal(12,4) default NULL,
  `base_tax_amount` decimal(12,4) default NULL,
  `base_price_incl_tax` decimal(12,4) default NULL,
  `qty` decimal(12,4) default NULL,
  `weee_tax_disposition` decimal(12,4) default NULL,
  `base_cost` decimal(12,4) default NULL,
  `base_weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `base_row_total_incl_tax` decimal(12,4) default NULL,
  `row_total_incl_tax` decimal(12,4) default NULL,
  `product_id` int(10) default NULL,
  `order_item_id` int(10) default NULL,
  `additional_data` text,
  `description` text,
  `weee_tax_applied` text,
  `sku` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_invoice_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_order`
--

CREATE TABLE `sales_flat_order` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `state` varchar(32) default NULL,
  `status` varchar(32) default NULL,
  `coupon_code` varchar(255) default NULL,
  `protect_code` varchar(255) default NULL,
  `shipping_description` varchar(255) default NULL,
  `is_virtual` tinyint(1) unsigned default NULL,
  `store_id` smallint(5) unsigned default NULL,
  `customer_id` int(10) unsigned default NULL,
  `base_discount_amount` decimal(12,4) default NULL,
  `base_discount_canceled` decimal(12,4) default NULL,
  `base_discount_invoiced` decimal(12,4) default NULL,
  `base_discount_refunded` decimal(12,4) default NULL,
  `base_grand_total` decimal(12,4) default NULL,
  `base_shipping_amount` decimal(12,4) default NULL,
  `base_shipping_canceled` decimal(12,4) default NULL,
  `base_shipping_invoiced` decimal(12,4) default NULL,
  `base_shipping_refunded` decimal(12,4) default NULL,
  `base_shipping_tax_amount` decimal(12,4) default NULL,
  `base_shipping_tax_refunded` decimal(12,4) default NULL,
  `base_subtotal` decimal(12,4) default NULL,
  `base_subtotal_canceled` decimal(12,4) default NULL,
  `base_subtotal_invoiced` decimal(12,4) default NULL,
  `base_subtotal_refunded` decimal(12,4) default NULL,
  `base_tax_amount` decimal(12,4) default NULL,
  `base_tax_canceled` decimal(12,4) default NULL,
  `base_tax_invoiced` decimal(12,4) default NULL,
  `base_tax_refunded` decimal(12,4) default NULL,
  `base_to_global_rate` decimal(12,4) default NULL,
  `base_to_order_rate` decimal(12,4) default NULL,
  `base_total_canceled` decimal(12,4) default NULL,
  `base_total_invoiced` decimal(12,4) default NULL,
  `base_total_invoiced_cost` decimal(12,4) default NULL,
  `base_total_offline_refunded` decimal(12,4) default NULL,
  `base_total_online_refunded` decimal(12,4) default NULL,
  `base_total_paid` decimal(12,4) default NULL,
  `base_total_qty_ordered` decimal(12,4) default NULL,
  `base_total_refunded` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) default NULL,
  `discount_canceled` decimal(12,4) default NULL,
  `discount_invoiced` decimal(12,4) default NULL,
  `discount_refunded` decimal(12,4) default NULL,
  `grand_total` decimal(12,4) default NULL,
  `shipping_amount` decimal(12,4) default NULL,
  `shipping_canceled` decimal(12,4) default NULL,
  `shipping_invoiced` decimal(12,4) default NULL,
  `shipping_refunded` decimal(12,4) default NULL,
  `shipping_tax_amount` decimal(12,4) default NULL,
  `shipping_tax_refunded` decimal(12,4) default NULL,
  `store_to_base_rate` decimal(12,4) default NULL,
  `store_to_order_rate` decimal(12,4) default NULL,
  `subtotal` decimal(12,4) default NULL,
  `subtotal_canceled` decimal(12,4) default NULL,
  `subtotal_invoiced` decimal(12,4) default NULL,
  `subtotal_refunded` decimal(12,4) default NULL,
  `tax_amount` decimal(12,4) default NULL,
  `tax_canceled` decimal(12,4) default NULL,
  `tax_invoiced` decimal(12,4) default NULL,
  `tax_refunded` decimal(12,4) default NULL,
  `total_canceled` decimal(12,4) default NULL,
  `total_invoiced` decimal(12,4) default NULL,
  `total_offline_refunded` decimal(12,4) default NULL,
  `total_online_refunded` decimal(12,4) default NULL,
  `total_paid` decimal(12,4) default NULL,
  `total_qty_ordered` decimal(12,4) default NULL,
  `total_refunded` decimal(12,4) default NULL,
  `can_ship_partially` tinyint(1) unsigned default NULL,
  `can_ship_partially_item` tinyint(1) unsigned default NULL,
  `customer_is_guest` tinyint(1) unsigned default NULL,
  `customer_note_notify` tinyint(1) unsigned default NULL,
  `billing_address_id` int(10) default NULL,
  `customer_group_id` smallint(5) default NULL,
  `edit_increment` int(10) default NULL,
  `email_sent` tinyint(1) unsigned default NULL,
  `forced_do_shipment_with_invoice` tinyint(1) unsigned default NULL,
  `gift_message_id` int(10) default NULL,
  `payment_authorization_expiration` int(10) default NULL,
  `paypal_ipn_customer_notified` int(10) default NULL,
  `quote_address_id` int(10) default NULL,
  `quote_id` int(10) default NULL,
  `shipping_address_id` int(10) default NULL,
  `adjustment_negative` decimal(12,4) default NULL,
  `adjustment_positive` decimal(12,4) default NULL,
  `base_adjustment_negative` decimal(12,4) default NULL,
  `base_adjustment_positive` decimal(12,4) default NULL,
  `base_shipping_discount_amount` decimal(12,4) default NULL,
  `base_subtotal_incl_tax` decimal(12,4) default NULL,
  `base_total_due` decimal(12,4) default NULL,
  `payment_authorization_amount` decimal(12,4) default NULL,
  `shipping_discount_amount` decimal(12,4) default NULL,
  `subtotal_incl_tax` decimal(12,4) default NULL,
  `total_due` decimal(12,4) default NULL,
  `weight` decimal(12,4) default NULL,
  `customer_dob` datetime default NULL,
  `increment_id` varchar(50) default NULL,
  `applied_rule_ids` varchar(255) default NULL,
  `base_currency_code` char(3) default NULL,
  `customer_email` varchar(255) default NULL,
  `customer_firstname` varchar(255) default NULL,
  `customer_lastname` varchar(255) default NULL,
  `customer_middlename` varchar(255) default NULL,
  `customer_prefix` varchar(255) default NULL,
  `customer_suffix` varchar(255) default NULL,
  `customer_taxvat` varchar(255) default NULL,
  `discount_description` varchar(255) default NULL,
  `ext_customer_id` varchar(255) default NULL,
  `ext_order_id` varchar(255) default NULL,
  `global_currency_code` char(3) default NULL,
  `hold_before_state` varchar(255) default NULL,
  `hold_before_status` varchar(255) default NULL,
  `order_currency_code` varchar(255) default NULL,
  `original_increment_id` varchar(50) default NULL,
  `relation_child_id` varchar(32) default NULL,
  `relation_child_real_id` varchar(32) default NULL,
  `relation_parent_id` varchar(32) default NULL,
  `relation_parent_real_id` varchar(32) default NULL,
  `remote_ip` varchar(255) default NULL,
  `shipping_method` varchar(255) default NULL,
  `store_currency_code` char(3) default NULL,
  `store_name` varchar(255) default NULL,
  `x_forwarded_for` varchar(255) default NULL,
  `customer_note` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `total_item_count` smallint(5) unsigned default '0',
  `customer_gender` int(11) default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `base_shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `hidden_tax_invoiced` decimal(12,4) default NULL,
  `base_hidden_tax_invoiced` decimal(12,4) default NULL,
  `hidden_tax_refunded` decimal(12,4) default NULL,
  `base_hidden_tax_refunded` decimal(12,4) default NULL,
  `shipping_incl_tax` decimal(12,4) default NULL,
  `base_shipping_incl_tax` decimal(12,4) default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STATUS` (`status`),
  KEY `IDX_STATE` (`state`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CUSTOMER_ID` (`customer_id`),
  KEY `IDX_EXT_ORDER_ID` (`ext_order_id`),
  KEY `IDX_UPDATED_AT` (`updated_at`),
  KEY `IDX_QUOTE_ID` (`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_order_address`
--

CREATE TABLE `sales_flat_order_address` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned default NULL,
  `customer_address_id` int(10) default NULL,
  `quote_address_id` int(10) default NULL,
  `region_id` int(10) default NULL,
  `customer_id` int(10) default NULL,
  `fax` varchar(255) default NULL,
  `region` varchar(255) default NULL,
  `postcode` varchar(255) default NULL,
  `lastname` varchar(255) default NULL,
  `street` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `telephone` varchar(255) default NULL,
  `country_id` char(2) default NULL,
  `firstname` varchar(255) default NULL,
  `address_type` varchar(255) default NULL,
  `prefix` varchar(255) default NULL,
  `middlename` varchar(255) default NULL,
  `suffix` varchar(255) default NULL,
  `company` varchar(255) default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_order_address`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_order_grid`
--

CREATE TABLE `sales_flat_order_grid` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `status` varchar(32) default NULL,
  `store_id` smallint(5) unsigned default NULL,
  `store_name` varchar(255) default NULL,
  `customer_id` int(10) unsigned default NULL,
  `base_grand_total` decimal(12,4) default NULL,
  `base_total_paid` decimal(12,4) default NULL,
  `grand_total` decimal(12,4) default NULL,
  `total_paid` decimal(12,4) default NULL,
  `increment_id` varchar(50) default NULL,
  `base_currency_code` char(3) default NULL,
  `order_currency_code` varchar(255) default NULL,
  `shipping_name` varchar(255) default NULL,
  `billing_name` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STATUS` (`status`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_BASE_GRAND_TOTAL` (`base_grand_total`),
  KEY `IDX_BASE_TOTAL_PAID` (`base_total_paid`),
  KEY `IDX_GRAND_TOTAL` (`grand_total`),
  KEY `IDX_TOTAL_PAID` (`total_paid`),
  KEY `IDX_SHIPPING_NAME` (`shipping_name`),
  KEY `IDX_BILLING_NAME` (`billing_name`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CUSTOMER_ID` (`customer_id`),
  KEY `IDX_UPDATED_AT` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_order_grid`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_order_item`
--

CREATE TABLE `sales_flat_order_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) unsigned NOT NULL default '0',
  `parent_item_id` int(10) unsigned default NULL,
  `quote_item_id` int(10) unsigned default NULL,
  `store_id` smallint(5) unsigned default NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `product_id` int(10) unsigned default NULL,
  `product_type` varchar(255) default NULL,
  `product_options` text,
  `weight` decimal(12,4) default '0.0000',
  `is_virtual` tinyint(1) unsigned default NULL,
  `sku` varchar(255) NOT NULL default '',
  `name` varchar(255) default NULL,
  `description` text,
  `applied_rule_ids` text,
  `additional_data` text,
  `free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `is_qty_decimal` tinyint(1) unsigned default NULL,
  `no_discount` tinyint(1) unsigned default '0',
  `qty_backordered` decimal(12,4) default '0.0000',
  `qty_canceled` decimal(12,4) default '0.0000',
  `qty_invoiced` decimal(12,4) default '0.0000',
  `qty_ordered` decimal(12,4) default '0.0000',
  `qty_refunded` decimal(12,4) default '0.0000',
  `qty_shipped` decimal(12,4) default '0.0000',
  `base_cost` decimal(12,4) default '0.0000',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `base_price` decimal(12,4) NOT NULL default '0.0000',
  `original_price` decimal(12,4) default NULL,
  `base_original_price` decimal(12,4) default NULL,
  `tax_percent` decimal(12,4) default '0.0000',
  `tax_amount` decimal(12,4) default '0.0000',
  `base_tax_amount` decimal(12,4) default '0.0000',
  `tax_invoiced` decimal(12,4) default '0.0000',
  `base_tax_invoiced` decimal(12,4) default '0.0000',
  `discount_percent` decimal(12,4) default '0.0000',
  `discount_amount` decimal(12,4) default '0.0000',
  `base_discount_amount` decimal(12,4) default '0.0000',
  `discount_invoiced` decimal(12,4) default '0.0000',
  `base_discount_invoiced` decimal(12,4) default '0.0000',
  `amount_refunded` decimal(12,4) default '0.0000',
  `base_amount_refunded` decimal(12,4) default '0.0000',
  `row_total` decimal(12,4) NOT NULL default '0.0000',
  `base_row_total` decimal(12,4) NOT NULL default '0.0000',
  `row_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `base_row_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `row_weight` decimal(12,4) default '0.0000',
  `gift_message_id` int(10) default NULL,
  `gift_message_available` int(10) default NULL,
  `base_tax_before_discount` decimal(12,4) default NULL,
  `tax_before_discount` decimal(12,4) default NULL,
  `ext_order_item_id` varchar(255) default NULL,
  `weee_tax_applied` text,
  `weee_tax_applied_amount` decimal(12,4) default NULL,
  `weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `weee_tax_disposition` decimal(12,4) default NULL,
  `weee_tax_row_disposition` decimal(12,4) default NULL,
  `base_weee_tax_disposition` decimal(12,4) default NULL,
  `base_weee_tax_row_disposition` decimal(12,4) default NULL,
  `locked_do_invoice` tinyint(1) unsigned default NULL,
  `locked_do_ship` tinyint(1) unsigned default NULL,
  `price_incl_tax` decimal(12,4) default NULL,
  `base_price_incl_tax` decimal(12,4) default NULL,
  `row_total_incl_tax` decimal(12,4) default NULL,
  `base_row_total_incl_tax` decimal(12,4) default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  `hidden_tax_invoiced` decimal(12,4) default NULL,
  `base_hidden_tax_invoiced` decimal(12,4) default NULL,
  `hidden_tax_refunded` decimal(12,4) default NULL,
  `base_hidden_tax_refunded` decimal(12,4) default NULL,
  `is_nominal` int(11) NOT NULL default '0',
  `tax_canceled` decimal(12,4) default NULL,
  `hidden_tax_canceled` decimal(12,4) default NULL,
  `tax_refunded` decimal(12,4) default NULL,
  PRIMARY KEY  (`item_id`),
  KEY `IDX_ORDER` (`order_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_PRODUCT_ID` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_order_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_order_payment`
--

CREATE TABLE `sales_flat_order_payment` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `base_shipping_captured` decimal(12,4) default NULL,
  `shipping_captured` decimal(12,4) default NULL,
  `amount_refunded` decimal(12,4) default NULL,
  `base_amount_paid` decimal(12,4) default NULL,
  `amount_canceled` decimal(12,4) default NULL,
  `base_amount_authorized` decimal(12,4) default NULL,
  `base_amount_paid_online` decimal(12,4) default NULL,
  `base_amount_refunded_online` decimal(12,4) default NULL,
  `base_shipping_amount` decimal(12,4) default NULL,
  `shipping_amount` decimal(12,4) default NULL,
  `amount_paid` decimal(12,4) default NULL,
  `amount_authorized` decimal(12,4) default NULL,
  `base_amount_ordered` decimal(12,4) default NULL,
  `base_shipping_refunded` decimal(12,4) default NULL,
  `shipping_refunded` decimal(12,4) default NULL,
  `base_amount_refunded` decimal(12,4) default NULL,
  `amount_ordered` decimal(12,4) default NULL,
  `base_amount_canceled` decimal(12,4) default NULL,
  `ideal_transaction_checked` tinyint(1) unsigned default NULL,
  `quote_payment_id` int(10) default NULL,
  `additional_data` text,
  `cc_exp_month` varchar(255) default NULL,
  `cc_ss_start_year` varchar(255) default NULL,
  `echeck_bank_name` varchar(255) default NULL,
  `method` varchar(255) default NULL,
  `cc_debug_request_body` varchar(255) default NULL,
  `cc_secure_verify` varchar(255) default NULL,
  `cybersource_token` varchar(255) default NULL,
  `ideal_issuer_title` varchar(255) default NULL,
  `protection_eligibility` varchar(255) default NULL,
  `cc_approval` varchar(255) default NULL,
  `cc_last4` varchar(255) default NULL,
  `cc_status_description` varchar(255) default NULL,
  `echeck_type` varchar(255) default NULL,
  `paybox_question_number` varchar(255) default NULL,
  `cc_debug_response_serialized` varchar(255) default NULL,
  `cc_ss_start_month` varchar(255) default NULL,
  `echeck_account_type` varchar(255) default NULL,
  `last_trans_id` varchar(255) default NULL,
  `cc_cid_status` varchar(255) default NULL,
  `cc_owner` varchar(255) default NULL,
  `cc_type` varchar(255) default NULL,
  `ideal_issuer_id` varchar(255) default NULL,
  `po_number` varchar(255) default NULL,
  `cc_exp_year` varchar(255) default NULL,
  `cc_status` varchar(255) default NULL,
  `echeck_routing_number` varchar(255) default NULL,
  `account_status` varchar(255) default NULL,
  `anet_trans_method` varchar(255) default NULL,
  `cc_debug_response_body` varchar(255) default NULL,
  `cc_ss_issue` varchar(255) default NULL,
  `echeck_account_name` varchar(255) default NULL,
  `cc_avs_status` varchar(255) default NULL,
  `cc_number_enc` varchar(255) default NULL,
  `cc_trans_id` varchar(255) default NULL,
  `flo2cash_account_id` varchar(255) default NULL,
  `paybox_request_number` varchar(255) default NULL,
  `address_status` varchar(255) default NULL,
  `additional_information` text,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_order_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_order_status_history`
--

CREATE TABLE `sales_flat_order_status_history` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `is_customer_notified` int(10) default NULL,
  `is_visible_on_front` tinyint(1) unsigned NOT NULL default '0',
  `comment` text,
  `status` varchar(32) default NULL,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`),
  KEY `IDX_CREATED_AT` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_order_status_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote`
--

CREATE TABLE `sales_flat_quote` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `converted_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `is_active` tinyint(1) unsigned default '1',
  `is_virtual` tinyint(1) unsigned default '0',
  `is_multi_shipping` tinyint(1) unsigned default '0',
  `items_count` int(10) unsigned default '0',
  `items_qty` decimal(12,4) default '0.0000',
  `orig_order_id` int(10) unsigned default '0',
  `store_to_base_rate` decimal(12,4) default '0.0000',
  `store_to_quote_rate` decimal(12,4) default '0.0000',
  `base_currency_code` varchar(255) default NULL,
  `store_currency_code` varchar(255) default NULL,
  `quote_currency_code` varchar(255) default NULL,
  `grand_total` decimal(12,4) default '0.0000',
  `base_grand_total` decimal(12,4) default '0.0000',
  `checkout_method` varchar(255) default NULL,
  `customer_id` int(10) unsigned default '0',
  `customer_tax_class_id` int(10) unsigned default '0',
  `customer_group_id` int(10) unsigned default '0',
  `customer_email` varchar(255) default NULL,
  `customer_prefix` varchar(40) default NULL,
  `customer_firstname` varchar(255) default NULL,
  `customer_middlename` varchar(40) default NULL,
  `customer_lastname` varchar(255) default NULL,
  `customer_suffix` varchar(40) default NULL,
  `customer_dob` datetime default NULL,
  `customer_note` varchar(255) default NULL,
  `customer_note_notify` tinyint(1) unsigned default '1',
  `customer_is_guest` tinyint(1) unsigned default '0',
  `remote_ip` varchar(32) default NULL,
  `applied_rule_ids` varchar(255) default NULL,
  `reserved_order_id` varchar(64) default '',
  `password_hash` varchar(255) default NULL,
  `coupon_code` varchar(255) default NULL,
  `global_currency_code` varchar(255) default NULL,
  `base_to_global_rate` decimal(12,4) default NULL,
  `base_to_quote_rate` decimal(12,4) default NULL,
  `customer_taxvat` varchar(255) default NULL,
  `customer_gender` varchar(255) default NULL,
  `subtotal` decimal(12,4) default NULL,
  `base_subtotal` decimal(12,4) default NULL,
  `subtotal_with_discount` decimal(12,4) default NULL,
  `base_subtotal_with_discount` decimal(12,4) default NULL,
  `is_changed` int(10) unsigned default NULL,
  `trigger_recollect` tinyint(1) NOT NULL default '0',
  `ext_shipping_info` text,
  `gift_message_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_CUSTOMER` (`customer_id`,`store_id`,`is_active`),
  KEY `FK_SALES_QUOTE_STORE` (`store_id`),
  KEY `IDX_IS_ACTIVE` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sales_flat_quote`
--

INSERT INTO `sales_flat_quote` VALUES(1, 1, '2011-05-18 20:40:25', '2011-05-18 20:40:25', '0000-00-00 00:00:00', 1, 0, 0, 0, 0.0000, 0, 1.0000, 1.0000, 'USD', 'USD', 'USD', 0.0000, 0.0000, NULL, 1, 3, 1, 'adamjmccombs@gmail.com', NULL, 'Adam', NULL, 'McCombs', NULL, NULL, NULL, 1, 0, '127.0.0.1', NULL, '', NULL, NULL, 'USD', 1.0000, 1.0000, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote_address`
--

CREATE TABLE `sales_flat_quote_address` (
  `address_id` int(10) unsigned NOT NULL auto_increment,
  `quote_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `customer_id` int(10) unsigned default NULL,
  `save_in_address_book` tinyint(1) default '0',
  `customer_address_id` int(10) unsigned default NULL,
  `address_type` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `prefix` varchar(40) default NULL,
  `firstname` varchar(255) default NULL,
  `middlename` varchar(40) default NULL,
  `lastname` varchar(255) default NULL,
  `suffix` varchar(40) default NULL,
  `company` varchar(255) default NULL,
  `street` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `region` varchar(255) default NULL,
  `region_id` int(10) unsigned default NULL,
  `postcode` varchar(255) default NULL,
  `country_id` varchar(255) default NULL,
  `telephone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `same_as_billing` tinyint(1) unsigned NOT NULL default '0',
  `free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `collect_shipping_rates` tinyint(1) unsigned NOT NULL default '0',
  `shipping_method` varchar(255) NOT NULL default '',
  `shipping_description` varchar(255) NOT NULL default '',
  `weight` decimal(12,4) NOT NULL default '0.0000',
  `subtotal` decimal(12,4) NOT NULL default '0.0000',
  `base_subtotal` decimal(12,4) NOT NULL default '0.0000',
  `subtotal_with_discount` decimal(12,4) NOT NULL default '0.0000',
  `base_subtotal_with_discount` decimal(12,4) NOT NULL default '0.0000',
  `tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `shipping_tax_amount` decimal(12,4) default NULL,
  `base_shipping_tax_amount` decimal(12,4) default NULL,
  `discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `base_discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `grand_total` decimal(12,4) NOT NULL default '0.0000',
  `base_grand_total` decimal(12,4) NOT NULL default '0.0000',
  `customer_notes` text,
  `applied_taxes` text,
  `discount_description` varchar(255) default NULL,
  `shipping_discount_amount` decimal(12,4) default NULL,
  `base_shipping_discount_amount` decimal(12,4) default NULL,
  `subtotal_incl_tax` decimal(12,4) default NULL,
  `base_subtotal_total_incl_tax` decimal(12,4) default NULL,
  `gift_message_id` int(10) unsigned default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `base_shipping_hidden_tax_amount` decimal(12,4) default NULL,
  `shipping_incl_tax` decimal(12,4) default NULL,
  `base_shipping_incl_tax` decimal(12,4) default NULL,
  PRIMARY KEY  (`address_id`),
  KEY `FK_SALES_QUOTE_ADDRESS_SALES_QUOTE` (`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_quote_address`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote_address_item`
--

CREATE TABLE `sales_flat_quote_address_item` (
  `address_item_id` int(10) unsigned NOT NULL auto_increment,
  `parent_item_id` int(10) unsigned default NULL,
  `quote_address_id` int(10) unsigned NOT NULL default '0',
  `quote_item_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `applied_rule_ids` text,
  `additional_data` text,
  `weight` decimal(12,4) default '0.0000',
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `discount_amount` decimal(12,4) default '0.0000',
  `tax_amount` decimal(12,4) default '0.0000',
  `row_total` decimal(12,4) NOT NULL default '0.0000',
  `base_row_total` decimal(12,4) NOT NULL default '0.0000',
  `row_total_with_discount` decimal(12,4) default '0.0000',
  `base_discount_amount` decimal(12,4) default '0.0000',
  `base_tax_amount` decimal(12,4) default '0.0000',
  `row_weight` decimal(12,4) default '0.0000',
  `product_id` int(10) unsigned default NULL,
  `super_product_id` int(10) unsigned default NULL,
  `parent_product_id` int(10) unsigned default NULL,
  `sku` varchar(255) default NULL,
  `image` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `description` text,
  `free_shipping` int(10) unsigned default NULL,
  `is_qty_decimal` int(10) unsigned default NULL,
  `price` decimal(12,4) default NULL,
  `discount_percent` decimal(12,4) default NULL,
  `no_discount` int(10) unsigned default NULL,
  `tax_percent` decimal(12,4) default NULL,
  `base_price` decimal(12,4) default NULL,
  `base_cost` decimal(12,4) default NULL,
  `price_incl_tax` decimal(12,4) default NULL,
  `base_price_incl_tax` decimal(12,4) default NULL,
  `row_total_incl_tax` decimal(12,4) default NULL,
  `base_row_total_incl_tax` decimal(12,4) default NULL,
  `gift_message_id` int(10) unsigned default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  PRIMARY KEY  (`address_item_id`),
  KEY `FK_QUOTE_ADDRESS_ITEM_QUOTE_ADDRESS` (`quote_address_id`),
  KEY `FK_SALES_FLAT_QUOTE_ADDRESS_ITEM_PARENT` (`parent_item_id`),
  KEY `FK_SALES_QUOTE_ADDRESS_ITEM_QUOTE_ITEM` (`quote_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_quote_address_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote_item`
--

CREATE TABLE `sales_flat_quote_item` (
  `item_id` int(10) unsigned NOT NULL auto_increment,
  `quote_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `product_id` int(10) unsigned default NULL,
  `store_id` smallint(5) unsigned default NULL,
  `parent_item_id` int(10) unsigned default NULL,
  `is_virtual` tinyint(1) unsigned default NULL,
  `sku` varchar(255) NOT NULL default '',
  `name` varchar(255) default NULL,
  `description` text,
  `applied_rule_ids` text,
  `additional_data` text,
  `free_shipping` tinyint(1) unsigned NOT NULL default '0',
  `is_qty_decimal` tinyint(1) unsigned default NULL,
  `no_discount` tinyint(1) unsigned default '0',
  `weight` decimal(12,4) default '0.0000',
  `qty` decimal(12,4) NOT NULL default '0.0000',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `base_price` decimal(12,4) NOT NULL default '0.0000',
  `custom_price` decimal(12,4) default NULL,
  `discount_percent` decimal(12,4) default '0.0000',
  `discount_amount` decimal(12,4) default '0.0000',
  `base_discount_amount` decimal(12,4) default '0.0000',
  `tax_percent` decimal(12,4) default '0.0000',
  `tax_amount` decimal(12,4) default '0.0000',
  `base_tax_amount` decimal(12,4) default '0.0000',
  `row_total` decimal(12,4) NOT NULL default '0.0000',
  `base_row_total` decimal(12,4) NOT NULL default '0.0000',
  `row_total_with_discount` decimal(12,4) default '0.0000',
  `row_weight` decimal(12,4) default '0.0000',
  `product_type` varchar(255) default NULL,
  `base_tax_before_discount` decimal(12,4) default NULL,
  `tax_before_discount` decimal(12,4) default NULL,
  `original_custom_price` decimal(12,4) default NULL,
  `redirect_url` varchar(255) default NULL,
  `base_cost` decimal(12,4) default NULL,
  `price_incl_tax` decimal(12,4) default NULL,
  `base_price_incl_tax` decimal(12,4) default NULL,
  `row_total_incl_tax` decimal(12,4) default NULL,
  `base_row_total_incl_tax` decimal(12,4) default NULL,
  `gift_message_id` int(10) unsigned default NULL,
  `weee_tax_applied` text,
  `weee_tax_applied_amount` decimal(12,4) default NULL,
  `weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_amount` decimal(12,4) default NULL,
  `base_weee_tax_applied_row_amount` decimal(12,4) default NULL,
  `weee_tax_disposition` decimal(12,4) default NULL,
  `weee_tax_row_disposition` decimal(12,4) default NULL,
  `base_weee_tax_disposition` decimal(12,4) default NULL,
  `base_weee_tax_row_disposition` decimal(12,4) default NULL,
  `hidden_tax_amount` decimal(12,4) default NULL,
  `base_hidden_tax_amount` decimal(12,4) default NULL,
  PRIMARY KEY  (`item_id`),
  KEY `FK_SALES_FLAT_QUOTE_ITEM_PARENT_ITEM` (`parent_item_id`),
  KEY `FK_SALES_QUOTE_ITEM_CATALOG_PRODUCT_ENTITY` (`product_id`),
  KEY `FK_SALES_QUOTE_ITEM_SALES_QUOTE` (`quote_id`),
  KEY `FK_SALES_QUOTE_ITEM_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_quote_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote_item_option`
--

CREATE TABLE `sales_flat_quote_item_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`option_id`),
  KEY `FK_SALES_QUOTE_ITEM_OPTION_ITEM_ID` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Additional options for quote item' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_quote_item_option`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote_payment`
--

CREATE TABLE `sales_flat_quote_payment` (
  `payment_id` int(10) unsigned NOT NULL auto_increment,
  `quote_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `method` varchar(255) default '',
  `cc_type` varchar(255) default '',
  `cc_number_enc` varchar(255) default '',
  `cc_last4` varchar(255) default '',
  `cc_cid_enc` varchar(255) default '',
  `cc_owner` varchar(255) default '',
  `cc_exp_month` tinyint(2) unsigned default '0',
  `cc_exp_year` smallint(4) unsigned default '0',
  `cc_ss_owner` varchar(255) default '',
  `cc_ss_start_month` tinyint(2) unsigned default '0',
  `cc_ss_start_year` smallint(4) unsigned default '0',
  `cybersource_token` varchar(255) default '',
  `paypal_correlation_id` varchar(255) default '',
  `paypal_payer_id` varchar(255) default '',
  `paypal_payer_status` varchar(255) default '',
  `po_number` varchar(255) default '',
  `additional_data` text,
  `cc_ss_issue` varchar(255) default NULL,
  `additional_information` text,
  `ideal_issuer_id` varchar(255) default NULL,
  `ideal_issuer_list` text,
  PRIMARY KEY  (`payment_id`),
  KEY `FK_SALES_QUOTE_PAYMENT_SALES_QUOTE` (`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_quote_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_quote_shipping_rate`
--

CREATE TABLE `sales_flat_quote_shipping_rate` (
  `rate_id` int(10) unsigned NOT NULL auto_increment,
  `address_id` int(10) unsigned NOT NULL default '0',
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `carrier` varchar(255) default NULL,
  `carrier_title` varchar(255) default NULL,
  `code` varchar(255) default NULL,
  `method` varchar(255) default NULL,
  `method_description` text,
  `price` decimal(12,4) NOT NULL default '0.0000',
  `error_message` text,
  `method_title` text,
  PRIMARY KEY  (`rate_id`),
  KEY `FK_SALES_QUOTE_SHIPPING_RATE_ADDRESS` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_quote_shipping_rate`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_shipment`
--

CREATE TABLE `sales_flat_shipment` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default NULL,
  `total_weight` decimal(12,4) default NULL,
  `total_qty` decimal(12,4) default NULL,
  `email_sent` tinyint(1) unsigned default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) default NULL,
  `shipping_address_id` int(10) default NULL,
  `billing_address_id` int(10) default NULL,
  `shipment_status` int(10) default NULL,
  `increment_id` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_TOTAL_QTY` (`total_qty`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_UPDATED_AT` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_shipment`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_shipment_comment`
--

CREATE TABLE `sales_flat_shipment_comment` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `is_customer_notified` int(10) default NULL,
  `is_visible_on_front` tinyint(1) unsigned NOT NULL default '0',
  `comment` text,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_shipment_comment`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_shipment_grid`
--

CREATE TABLE `sales_flat_shipment_grid` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `store_id` smallint(5) unsigned default NULL,
  `total_qty` decimal(12,4) default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `shipment_status` int(10) default NULL,
  `increment_id` varchar(50) default NULL,
  `order_increment_id` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `order_created_at` datetime default NULL,
  `shipping_name` varchar(255) default NULL,
  PRIMARY KEY  (`entity_id`),
  UNIQUE KEY `UNQ_INCREMENT_ID` (`increment_id`),
  KEY `IDX_STORE_ID` (`store_id`),
  KEY `IDX_TOTAL_QTY` (`total_qty`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_SHIPMENT_STATUS` (`shipment_status`),
  KEY `IDX_ORDER_INCREMENT_ID` (`order_increment_id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_ORDER_CREATED_AT` (`order_created_at`),
  KEY `IDX_SHIPPING_NAME` (`shipping_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_shipment_grid`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_shipment_item`
--

CREATE TABLE `sales_flat_shipment_item` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `row_total` decimal(12,4) default NULL,
  `price` decimal(12,4) default NULL,
  `weight` decimal(12,4) default NULL,
  `qty` decimal(12,4) default NULL,
  `product_id` int(10) default NULL,
  `order_item_id` int(10) default NULL,
  `additional_data` text,
  `description` text,
  `name` varchar(255) default NULL,
  `sku` varchar(255) default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_shipment_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_flat_shipment_track`
--

CREATE TABLE `sales_flat_shipment_track` (
  `entity_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL,
  `weight` decimal(12,4) default NULL,
  `qty` decimal(12,4) default NULL,
  `order_id` int(10) unsigned NOT NULL,
  `number` text,
  `description` text,
  `title` varchar(255) default NULL,
  `carrier_code` varchar(32) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`entity_id`),
  KEY `IDX_PARENT_ID` (`parent_id`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_CREATED_AT` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_flat_shipment_track`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_invoiced_aggregated`
--

CREATE TABLE `sales_invoiced_aggregated` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `orders_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `invoiced` decimal(12,4) NOT NULL default '0.0000',
  `invoiced_captured` decimal(12,4) NOT NULL default '0.0000',
  `invoiced_not_captured` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_invoiced_aggregated`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_invoiced_aggregated_order`
--

CREATE TABLE `sales_invoiced_aggregated_order` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `orders_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `invoiced` decimal(12,4) NOT NULL default '0.0000',
  `invoiced_captured` decimal(12,4) NOT NULL default '0.0000',
  `invoiced_not_captured` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_invoiced_aggregated_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_order_aggregated_created`
--

CREATE TABLE `sales_order_aggregated_created` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `total_qty_ordered` decimal(12,4) NOT NULL default '0.0000',
  `total_qty_invoiced` decimal(12,4) NOT NULL default '0.0000',
  `total_income_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_revenue_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_profit_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_invoiced_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_canceled_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_paid_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_refunded_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_tax_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_tax_amount_actual` decimal(12,4) NOT NULL default '0.0000',
  `total_shipping_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_shipping_amount_actual` decimal(12,4) NOT NULL default '0.0000',
  `total_discount_amount` decimal(12,4) NOT NULL default '0.0000',
  `total_discount_amount_actual` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_order_aggregated_created`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_order_status`
--

CREATE TABLE `sales_order_status` (
  `status` varchar(32) NOT NULL,
  `label` varchar(128) NOT NULL,
  PRIMARY KEY  (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sales_order_status`
--

INSERT INTO `sales_order_status` VALUES('canceled', 'Canceled');
INSERT INTO `sales_order_status` VALUES('closed', 'Closed');
INSERT INTO `sales_order_status` VALUES('complete', 'Complete');
INSERT INTO `sales_order_status` VALUES('fraud', 'Suspected Fraud');
INSERT INTO `sales_order_status` VALUES('holded', 'On Hold');
INSERT INTO `sales_order_status` VALUES('payment_review', 'Payment Review');
INSERT INTO `sales_order_status` VALUES('pending', 'Pending');
INSERT INTO `sales_order_status` VALUES('pending_payment', 'Pending Payment');
INSERT INTO `sales_order_status` VALUES('pending_paypal', 'Pending PayPal');
INSERT INTO `sales_order_status` VALUES('processing', 'Processing');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order_status_label`
--

CREATE TABLE `sales_order_status_label` (
  `status` varchar(32) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `label` varchar(128) NOT NULL,
  PRIMARY KEY  (`status`,`store_id`),
  KEY `FK_SALES_ORDER_STATUS_LABEL_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sales_order_status_label`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_order_status_state`
--

CREATE TABLE `sales_order_status_state` (
  `status` varchar(32) NOT NULL,
  `state` varchar(32) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`status`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sales_order_status_state`
--

INSERT INTO `sales_order_status_state` VALUES('canceled', 'canceled', 1);
INSERT INTO `sales_order_status_state` VALUES('closed', 'closed', 1);
INSERT INTO `sales_order_status_state` VALUES('complete', 'complete', 1);
INSERT INTO `sales_order_status_state` VALUES('fraud', 'payment_review', 0);
INSERT INTO `sales_order_status_state` VALUES('holded', 'holded', 1);
INSERT INTO `sales_order_status_state` VALUES('payment_review', 'payment_review', 1);
INSERT INTO `sales_order_status_state` VALUES('pending', 'new', 1);
INSERT INTO `sales_order_status_state` VALUES('pending_payment', 'pending_payment', 1);
INSERT INTO `sales_order_status_state` VALUES('processing', 'processing', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sales_order_tax`
--

CREATE TABLE `sales_order_tax` (
  `tax_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `percent` decimal(12,4) NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `priority` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `base_amount` decimal(12,4) NOT NULL,
  `process` smallint(6) NOT NULL,
  `base_real_amount` decimal(12,4) NOT NULL,
  `hidden` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tax_id`),
  KEY `IDX_ORDER_TAX` (`order_id`,`priority`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_order_tax`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_payment_transaction`
--

CREATE TABLE `sales_payment_transaction` (
  `transaction_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned default NULL,
  `order_id` int(10) unsigned NOT NULL default '0',
  `payment_id` int(10) unsigned NOT NULL default '0',
  `txn_id` varchar(100) NOT NULL default '',
  `parent_txn_id` varchar(100) default NULL,
  `txn_type` varchar(15) NOT NULL default '',
  `is_closed` tinyint(1) unsigned NOT NULL default '1',
  `additional_information` blob,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`transaction_id`),
  UNIQUE KEY `UNQ_ORDER_PAYMENT_TXN` (`order_id`,`payment_id`,`txn_id`),
  KEY `IDX_ORDER_ID` (`order_id`),
  KEY `IDX_PARENT_ID` (`parent_id`),
  KEY `IDX_PAYMENT_ID` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_payment_transaction`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_recurring_profile`
--

CREATE TABLE `sales_recurring_profile` (
  `profile_id` int(10) unsigned NOT NULL auto_increment,
  `state` varchar(20) NOT NULL,
  `customer_id` int(10) unsigned default NULL,
  `store_id` smallint(5) unsigned default NULL,
  `method_code` varchar(32) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime default NULL,
  `reference_id` varchar(32) default NULL,
  `subscriber_name` varchar(150) default NULL,
  `start_datetime` datetime NOT NULL,
  `internal_reference_id` varchar(42) NOT NULL,
  `schedule_description` varchar(255) NOT NULL,
  `suspension_threshold` smallint(6) unsigned default NULL,
  `bill_failed_later` tinyint(1) unsigned NOT NULL default '0',
  `period_unit` varchar(20) NOT NULL,
  `period_frequency` tinyint(3) unsigned default NULL,
  `period_max_cycles` tinyint(3) unsigned default NULL,
  `billing_amount` double(12,4) unsigned NOT NULL default '0.0000',
  `trial_period_unit` varchar(20) default NULL,
  `trial_period_frequency` tinyint(3) unsigned default NULL,
  `trial_period_max_cycles` tinyint(3) unsigned default NULL,
  `trial_billing_amount` double(12,4) unsigned default NULL,
  `currency_code` char(3) NOT NULL,
  `shipping_amount` decimal(12,4) unsigned default NULL,
  `tax_amount` decimal(12,4) unsigned default NULL,
  `init_amount` decimal(12,4) unsigned default NULL,
  `init_may_fail` tinyint(1) unsigned NOT NULL default '0',
  `order_info` text NOT NULL,
  `order_item_info` text NOT NULL,
  `billing_address_info` text NOT NULL,
  `shipping_address_info` text,
  `profile_vendor_info` text,
  `additional_info` text,
  PRIMARY KEY  (`profile_id`),
  UNIQUE KEY `UNQ_INTERNAL_REF_ID` (`internal_reference_id`),
  KEY `IDX_RECURRING_PROFILE_CUSTOMER` (`customer_id`),
  KEY `IDX_RECURRING_PROFILE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_recurring_profile`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_recurring_profile_order`
--

CREATE TABLE `sales_recurring_profile_order` (
  `link_id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL default '0',
  `order_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`link_id`),
  UNIQUE KEY `UNQ_PROFILE_ORDER` (`profile_id`,`order_id`),
  KEY `IDX_ORDER` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_recurring_profile_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_refunded_aggregated`
--

CREATE TABLE `sales_refunded_aggregated` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `refunded` decimal(12,4) NOT NULL default '0.0000',
  `online_refunded` decimal(12,4) NOT NULL default '0.0000',
  `offline_refunded` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_refunded_aggregated`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_refunded_aggregated_order`
--

CREATE TABLE `sales_refunded_aggregated_order` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `refunded` decimal(12,4) NOT NULL default '0.0000',
  `online_refunded` decimal(12,4) NOT NULL default '0.0000',
  `offline_refunded` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_refunded_aggregated_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_shipping_aggregated`
--

CREATE TABLE `sales_shipping_aggregated` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `shipping_description` varchar(255) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `total_shipping` decimal(12,4) NOT NULL default '0.0000',
  `total_shipping_actual` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`,`shipping_description`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_shipping_aggregated`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_shipping_aggregated_order`
--

CREATE TABLE `sales_shipping_aggregated_order` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `order_status` varchar(50) NOT NULL default '',
  `shipping_description` varchar(255) NOT NULL default '',
  `orders_count` int(11) NOT NULL default '0',
  `total_shipping` decimal(12,4) NOT NULL default '0.0000',
  `total_shipping_actual` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_ORDER_STATUS` (`period`,`store_id`,`order_status`,`shipping_description`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sales_shipping_aggregated_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `sendfriend_log`
--

CREATE TABLE `sendfriend_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `ip` bigint(20) NOT NULL default '0',
  `time` int(10) unsigned NOT NULL,
  `website_id` smallint(5) NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `IDX_REMOTE_ADDR` (`ip`),
  KEY `IDX_LOG_TIME` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Send to friend function log storage table' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sendfriend_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `shipping_tablerate`
--

CREATE TABLE `shipping_tablerate` (
  `pk` int(10) unsigned NOT NULL auto_increment,
  `website_id` int(11) NOT NULL default '0',
  `dest_country_id` varchar(4) NOT NULL default '0',
  `dest_region_id` int(10) NOT NULL default '0',
  `dest_zip` varchar(10) NOT NULL default '',
  `condition_name` varchar(20) NOT NULL default '',
  `condition_value` decimal(12,4) NOT NULL default '0.0000',
  `price` decimal(12,4) NOT NULL default '0.0000',
  `cost` decimal(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`pk`),
  UNIQUE KEY `dest_country` (`website_id`,`dest_country_id`,`dest_region_id`,`dest_zip`,`condition_name`,`condition_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shipping_tablerate`
--


-- --------------------------------------------------------

--
-- Table structure for table `sitemap`
--

CREATE TABLE `sitemap` (
  `sitemap_id` int(11) NOT NULL auto_increment,
  `sitemap_type` varchar(32) default NULL,
  `sitemap_filename` varchar(32) default NULL,
  `sitemap_path` tinytext,
  `sitemap_time` timestamp NULL default NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`sitemap_id`),
  KEY `FK_SITEMAP_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sitemap`
--


-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE `tag` (
  `tag_id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `status` smallint(6) NOT NULL default '0',
  `first_customer_id` int(10) unsigned NOT NULL default '0',
  `first_store_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `tag_properties`
--

CREATE TABLE `tag_properties` (
  `tag_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `base_popularity` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tag_id`,`store_id`),
  KEY `FK_TAG_PROPERTIES_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tag_properties`
--


-- --------------------------------------------------------

--
-- Table structure for table `tag_relation`
--

CREATE TABLE `tag_relation` (
  `tag_relation_id` int(11) unsigned NOT NULL auto_increment,
  `tag_id` int(11) unsigned NOT NULL default '0',
  `customer_id` int(10) unsigned default NULL,
  `product_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(6) unsigned NOT NULL default '1',
  `active` tinyint(1) unsigned NOT NULL default '1',
  `created_at` datetime default NULL,
  PRIMARY KEY  (`tag_relation_id`),
  UNIQUE KEY `UNQ_TAG_CUSTOMER_PRODUCT_STORE` (`tag_id`,`customer_id`,`product_id`,`store_id`),
  KEY `IDX_PRODUCT` (`product_id`),
  KEY `IDX_TAG` (`tag_id`),
  KEY `IDX_CUSTOMER` (`customer_id`),
  KEY `IDX_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tag_relation`
--


-- --------------------------------------------------------

--
-- Table structure for table `tag_summary`
--

CREATE TABLE `tag_summary` (
  `tag_id` int(11) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned NOT NULL default '0',
  `customers` int(11) unsigned NOT NULL default '0',
  `products` int(11) unsigned NOT NULL default '0',
  `uses` int(11) unsigned NOT NULL default '0' COMMENT 'deprecated since 1.4.0.1',
  `historical_uses` int(11) unsigned NOT NULL default '0' COMMENT 'deprecated since 1.4.0.1',
  `popularity` int(11) unsigned NOT NULL default '0',
  `base_popularity` int(11) unsigned NOT NULL default '0' COMMENT 'deprecated since 1.4.0.1',
  PRIMARY KEY  (`tag_id`,`store_id`),
  KEY `FK_TAG_SUMMARY_STORE` (`store_id`),
  KEY `IDX_TAG` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tag_summary`
--


-- --------------------------------------------------------

--
-- Table structure for table `tax_calculation`
--

CREATE TABLE `tax_calculation` (
  `tax_calculation_rate_id` int(11) NOT NULL,
  `tax_calculation_rule_id` int(11) NOT NULL,
  `customer_tax_class_id` smallint(6) NOT NULL,
  `product_tax_class_id` smallint(6) NOT NULL,
  KEY `FK_TAX_CALCULATION_RULE` (`tax_calculation_rule_id`),
  KEY `FK_TAX_CALCULATION_RATE` (`tax_calculation_rate_id`),
  KEY `FK_TAX_CALCULATION_CTC` (`customer_tax_class_id`),
  KEY `FK_TAX_CALCULATION_PTC` (`product_tax_class_id`),
  KEY `IDX_TAX_CALCULATION` (`tax_calculation_rate_id`,`customer_tax_class_id`,`product_tax_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tax_calculation`
--

INSERT INTO `tax_calculation` VALUES(1, 1, 3, 2);
INSERT INTO `tax_calculation` VALUES(2, 1, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tax_calculation_rate`
--

CREATE TABLE `tax_calculation_rate` (
  `tax_calculation_rate_id` int(11) NOT NULL auto_increment,
  `tax_country_id` char(2) NOT NULL,
  `tax_region_id` mediumint(9) NOT NULL,
  `tax_postcode` varchar(21) NOT NULL,
  `code` varchar(255) NOT NULL,
  `rate` decimal(12,4) NOT NULL,
  `zip_is_range` tinyint(1) default NULL,
  `zip_from` int(11) unsigned default NULL,
  `zip_to` int(11) unsigned default NULL,
  PRIMARY KEY  (`tax_calculation_rate_id`),
  KEY `IDX_TAX_CALCULATION_RATE` (`tax_country_id`,`tax_region_id`,`tax_postcode`),
  KEY `IDX_TAX_CALCULATION_RATE_CODE` (`code`),
  KEY `IDX_TAX_CALCULATION_RATE_RANGE` (`tax_calculation_rate_id`,`tax_country_id`,`tax_region_id`,`zip_is_range`,`tax_postcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tax_calculation_rate`
--

INSERT INTO `tax_calculation_rate` VALUES(1, 'US', 12, '*', 'US-CA-*-Rate 1', 8.2500, NULL, NULL, NULL);
INSERT INTO `tax_calculation_rate` VALUES(2, 'US', 43, '*', 'US-NY-*-Rate 1', 8.3750, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tax_calculation_rate_title`
--

CREATE TABLE `tax_calculation_rate_title` (
  `tax_calculation_rate_title_id` int(11) NOT NULL auto_increment,
  `tax_calculation_rate_id` int(11) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY  (`tax_calculation_rate_title_id`),
  KEY `IDX_TAX_CALCULATION_RATE_TITLE` (`tax_calculation_rate_id`,`store_id`),
  KEY `FK_TAX_CALCULATION_RATE_TITLE_RATE` (`tax_calculation_rate_id`),
  KEY `FK_TAX_CALCULATION_RATE_TITLE_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tax_calculation_rate_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `tax_calculation_rule`
--

CREATE TABLE `tax_calculation_rule` (
  `tax_calculation_rule_id` int(11) NOT NULL auto_increment,
  `code` varchar(255) NOT NULL,
  `priority` mediumint(9) NOT NULL,
  `position` mediumint(9) NOT NULL,
  PRIMARY KEY  (`tax_calculation_rule_id`),
  KEY `IDX_TAX_CALCULATION_RULE` (`priority`,`position`,`tax_calculation_rule_id`),
  KEY `IDX_TAX_CALCULATION_RULE_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tax_calculation_rule`
--

INSERT INTO `tax_calculation_rule` VALUES(1, 'Retail Customer-Taxable Goods-Rate 1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tax_class`
--

CREATE TABLE `tax_class` (
  `class_id` smallint(6) NOT NULL auto_increment,
  `class_name` varchar(255) NOT NULL default '',
  `class_type` enum('CUSTOMER','PRODUCT') NOT NULL default 'CUSTOMER',
  PRIMARY KEY  (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tax_class`
--

INSERT INTO `tax_class` VALUES(2, 'Taxable Goods', 'PRODUCT');
INSERT INTO `tax_class` VALUES(3, 'Retail Customer', 'CUSTOMER');
INSERT INTO `tax_class` VALUES(4, 'Shipping', 'PRODUCT');

-- --------------------------------------------------------

--
-- Table structure for table `tax_order_aggregated_created`
--

CREATE TABLE `tax_order_aggregated_created` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `period` date NOT NULL default '0000-00-00',
  `store_id` smallint(5) unsigned default NULL,
  `code` varchar(255) NOT NULL default '',
  `order_status` varchar(50) NOT NULL default '',
  `percent` float(12,4) NOT NULL default '0.0000',
  `orders_count` int(11) unsigned NOT NULL default '0',
  `tax_base_amount_sum` float(12,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UNQ_PERIOD_STORE_CODE_ORDER_STATUS` (`period`,`store_id`,`code`,`percent`,`order_status`),
  KEY `IDX_STORE_ID` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tax_order_aggregated_created`
--


-- --------------------------------------------------------

--
-- Table structure for table `weee_discount`
--

CREATE TABLE `weee_discount` (
  `entity_id` int(10) unsigned NOT NULL default '0',
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `customer_group_id` smallint(5) unsigned NOT NULL,
  `value` decimal(12,4) NOT NULL default '0.0000',
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_WEBSITE` (`website_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_GROUP` (`customer_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `weee_discount`
--


-- --------------------------------------------------------

--
-- Table structure for table `weee_tax`
--

CREATE TABLE `weee_tax` (
  `value_id` int(11) NOT NULL auto_increment,
  `website_id` smallint(5) unsigned NOT NULL default '0',
  `entity_id` int(10) unsigned NOT NULL default '0',
  `country` varchar(2) NOT NULL default '',
  `value` decimal(12,4) NOT NULL default '0.0000',
  `state` varchar(255) NOT NULL default '*',
  `attribute_id` smallint(5) unsigned NOT NULL,
  `entity_type_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`value_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_WEBSITE` (`website_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_PRODUCT_ENTITY` (`entity_id`),
  KEY `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_COUNTRY` (`country`),
  KEY `FK_WEEE_TAX_ATTRIBUTE_ID` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `weee_tax`
--


-- --------------------------------------------------------

--
-- Table structure for table `widget`
--

CREATE TABLE `widget` (
  `widget_id` int(10) unsigned NOT NULL auto_increment,
  `code` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `parameters` text,
  PRIMARY KEY  (`widget_id`),
  KEY `IDX_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Preconfigured Widgets' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `widget`
--


-- --------------------------------------------------------

--
-- Table structure for table `widget_instance`
--

CREATE TABLE `widget_instance` (
  `instance_id` int(11) unsigned NOT NULL auto_increment,
  `type` varchar(255) NOT NULL default '',
  `package_theme` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `store_ids` varchar(255) NOT NULL default '0',
  `widget_parameters` text,
  `sort_order` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `widget_instance`
--


-- --------------------------------------------------------

--
-- Table structure for table `widget_instance_page`
--

CREATE TABLE `widget_instance_page` (
  `page_id` int(11) unsigned NOT NULL auto_increment,
  `instance_id` int(11) unsigned NOT NULL default '0',
  `group` varchar(25) NOT NULL default '',
  `layout_handle` varchar(255) NOT NULL default '',
  `block_reference` varchar(255) NOT NULL default '',
  `for` varchar(25) NOT NULL default '',
  `entities` text,
  `template` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`page_id`),
  KEY `IDX_WIDGET_WIDGET_INSTANCE_ID` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `widget_instance_page`
--


-- --------------------------------------------------------

--
-- Table structure for table `widget_instance_page_layout`
--

CREATE TABLE `widget_instance_page_layout` (
  `page_id` int(11) unsigned NOT NULL default '0',
  `layout_update_id` int(10) unsigned NOT NULL default '0',
  UNIQUE KEY `page_id` (`page_id`,`layout_update_id`),
  KEY `IDX_WIDGET_WIDGET_INSTANCE_PAGE_ID` (`page_id`),
  KEY `IDX_WIDGET_WIDGET_INSTANCE_LAYOUT_UPDATE_ID` (`layout_update_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `widget_instance_page_layout`
--


-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wishlist_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `shared` tinyint(1) unsigned default '0',
  `sharing_code` varchar(32) character set latin1 collate latin1_general_ci NOT NULL default '',
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`wishlist_id`),
  UNIQUE KEY `UNQ_CUSTOMER` (`customer_id`),
  KEY `IDX_IS_SHARED` (`shared`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Wishlist main' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wishlist`
--


-- --------------------------------------------------------

--
-- Table structure for table `wishlist_item`
--

CREATE TABLE `wishlist_item` (
  `wishlist_item_id` int(10) unsigned NOT NULL auto_increment,
  `wishlist_id` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `store_id` smallint(5) unsigned default NULL,
  `added_at` datetime default NULL,
  `description` text,
  `qty` decimal(12,4) NOT NULL,
  PRIMARY KEY  (`wishlist_item_id`),
  KEY `IDX_WISHLIST` (`wishlist_id`),
  KEY `IDX_PRODUCT` (`product_id`),
  KEY `IDX_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Wishlist items' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wishlist_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `wishlist_item_option`
--

CREATE TABLE `wishlist_item_option` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `wishlist_item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`option_id`),
  KEY `FK_WISHLIST_ITEM_OPTION_ITEM_ID` (`wishlist_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Additional options for wishlist item' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wishlist_item_option`
--


-- --------------------------------------------------------

--
-- Table structure for table `xmlconnect_application`
--

CREATE TABLE `xmlconnect_application` (
  `application_id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `code` varchar(32) NOT NULL,
  `type` varchar(32) NOT NULL,
  `store_id` smallint(5) unsigned default NULL,
  `active_from` date default NULL,
  `active_to` date default NULL,
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `configuration` blob,
  `status` tinyint(1) NOT NULL default '0',
  `browsing_mode` tinyint(1) default '0',
  PRIMARY KEY  (`application_id`),
  UNIQUE KEY `UNQ_XMLCONNECT_APPLICATION_CODE` (`code`),
  KEY `FK_XMLCONNECT_APPLICAION_STORE` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xmlconnect_application`
--


-- --------------------------------------------------------

--
-- Table structure for table `xmlconnect_history`
--

CREATE TABLE `xmlconnect_history` (
  `history_id` int(11) NOT NULL auto_increment,
  `application_id` smallint(5) unsigned NOT NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `store_id` smallint(5) unsigned default NULL,
  `params` blob,
  `title` varchar(200) NOT NULL,
  `activation_key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  PRIMARY KEY  (`history_id`),
  KEY `FK_XMLCONNECT_HISTORY_APPLICATION` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xmlconnect_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `xmlconnect_notification_template`
--

CREATE TABLE `xmlconnect_notification_template` (
  `id` int(11) NOT NULL auto_increment,
  `app_code` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL,
  `push_title` varchar(141) NOT NULL,
  `message_title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `FK_APP_CODE` (`app_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xmlconnect_notification_template`
--


-- --------------------------------------------------------

--
-- Table structure for table `xmlconnect_queue`
--

CREATE TABLE `xmlconnect_queue` (
  `id` int(11) NOT NULL auto_increment,
  `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `exec_time` timestamp NULL default NULL,
  `template_id` int(11) NOT NULL,
  `push_title` varchar(140) NOT NULL,
  `message_title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(4) NOT NULL default '0',
  `type` varchar(12) NOT NULL,
  `app_code` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_TEMPLATE_ID` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xmlconnect_queue`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_rule`
--
ALTER TABLE `admin_rule`
  ADD CONSTRAINT `FK_admin_rule` FOREIGN KEY (`role_id`) REFERENCES `admin_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `api_rule`
--
ALTER TABLE `api_rule`
  ADD CONSTRAINT `FK_api_rule` FOREIGN KEY (`role_id`) REFERENCES `api_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `api_session`
--
ALTER TABLE `api_session`
  ADD CONSTRAINT `FK_API_SESSION_USER` FOREIGN KEY (`user_id`) REFERENCES `api_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogindex_aggregation`
--
ALTER TABLE `catalogindex_aggregation`
  ADD CONSTRAINT `FK_CATALOGINDEX_AGGREGATION_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogindex_aggregation_to_tag`
--
ALTER TABLE `catalogindex_aggregation_to_tag`
  ADD CONSTRAINT `FK_CATALOGINDEX_AGGREGATION_TO_TAG_AGGREGATION` FOREIGN KEY (`aggregation_id`) REFERENCES `catalogindex_aggregation` (`aggregation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINDEX_AGGREGATION_TO_TAG_TAG` FOREIGN KEY (`tag_id`) REFERENCES `catalogindex_aggregation_tag` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogindex_eav`
--
ALTER TABLE `catalogindex_eav`
  ADD CONSTRAINT `FK_CATALOGINDEX_EAV_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINDEX_EAV_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINDEX_EAV_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogindex_minimal_price`
--
ALTER TABLE `catalogindex_minimal_price`
  ADD CONSTRAINT `FK_CATALOGINDEX_MINIMAL_PRICE_CUSTOMER_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINDEX_MINIMAL_PRICE_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CI_MINIMAL_PRICE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogindex_price`
--
ALTER TABLE `catalogindex_price`
  ADD CONSTRAINT `FK_CATALOGINDEX_PRICE_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINDEX_PRICE_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CI_PRICE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cataloginventory_stock_item`
--
ALTER TABLE `cataloginventory_stock_item`
  ADD CONSTRAINT `FK_CATALOGINVENTORY_STOCK_ITEM_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINVENTORY_STOCK_ITEM_STOCK` FOREIGN KEY (`stock_id`) REFERENCES `cataloginventory_stock` (`stock_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cataloginventory_stock_status`
--
ALTER TABLE `cataloginventory_stock_status`
  ADD CONSTRAINT `FK_CATALOGINVENTORY_STOCK_STATUS_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINVENTORY_STOCK_STATUS_STOCK` FOREIGN KEY (`stock_id`) REFERENCES `cataloginventory_stock` (`stock_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGINVENTORY_STOCK_STATUS_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogrule_group_website`
--
ALTER TABLE `catalogrule_group_website`
  ADD CONSTRAINT `FK_CATALOGRULE_GROUP_WEBSITE_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGRULE_GROUP_WEBSITE_RULE` FOREIGN KEY (`rule_id`) REFERENCES `catalogrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGRULE_GROUP_WEBSITE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogrule_product`
--
ALTER TABLE `catalogrule_product`
  ADD CONSTRAINT `FK_catalogrule_product_customergroup` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGRULE_PRODUCT_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_catalogrule_product_rule` FOREIGN KEY (`rule_id`) REFERENCES `catalogrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_catalogrule_product_website` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogrule_product_price`
--
ALTER TABLE `catalogrule_product_price`
  ADD CONSTRAINT `FK_catalogrule_product_price_customergroup` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGRULE_PRODUCT_PRICE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_catalogrule_product_price_website` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogsearch_query`
--
ALTER TABLE `catalogsearch_query`
  ADD CONSTRAINT `FK_CATALOGSEARCH_QUERY_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalogsearch_result`
--
ALTER TABLE `catalogsearch_result`
  ADD CONSTRAINT `FK_CATALOGSEARCH_RESULT_CATALOG_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOGSEARCH_RESULT_QUERY` FOREIGN KEY (`query_id`) REFERENCES `catalogsearch_query` (`query_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_entity_datetime`
--
ALTER TABLE `catalog_category_entity_datetime`
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DATETIME_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_entity_decimal`
--
ALTER TABLE `catalog_category_entity_decimal`
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_entity_int`
--
ALTER TABLE `catalog_category_entity_int`
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_EMTITY_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_EMTITY_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_EMTITY_INT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_entity_text`
--
ALTER TABLE `catalog_category_entity_text`
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_TEXT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_entity_varchar`
--
ALTER TABLE `catalog_category_entity_varchar`
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_ENTITY_VARCHAR_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_flat_store_1`
--
ALTER TABLE `catalog_category_flat_store_1`
  ADD CONSTRAINT `FK_CATEGORY_FLAT_CATEGORY_ID_STORE_1` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATEGORY_FLAT_STORE_ID_STORE_1` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_product`
--
ALTER TABLE `catalog_category_product`
  ADD CONSTRAINT `CATALOG_CATEGORY_PRODUCT_CATEGORY` FOREIGN KEY (`category_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `CATALOG_CATEGORY_PRODUCT_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_category_product_index`
--
ALTER TABLE `catalog_category_product_index`
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_PROD_IDX_CATEGORY_ENTITY` FOREIGN KEY (`category_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_CATEGORY_PROD_IDX_PROD_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATEGORY_PRODUCT_INDEX_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_compare_item`
--
ALTER TABLE `catalog_compare_item`
  ADD CONSTRAINT `FK_CATALOG_COMPARE_ITEM_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_COMPARE_ITEM_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_COMPARE_ITEM_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `catalog_eav_attribute`
--
ALTER TABLE `catalog_eav_attribute`
  ADD CONSTRAINT `FK_CATALOG_EAV_ATTRIBUTE_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_bundle_option`
--
ALTER TABLE `catalog_product_bundle_option`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_OPTION_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_bundle_option_value`
--
ALTER TABLE `catalog_product_bundle_option_value`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_OPTION_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `catalog_product_bundle_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_bundle_price_index`
--
ALTER TABLE `catalog_product_bundle_price_index`
  ADD CONSTRAINT `CATALOG_PRODUCT_BUNDLE_PRICE_INDEX_CUSTOMER_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `CATALOG_PRODUCT_BUNDLE_PRICE_INDEX_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `CATALOG_PRODUCT_BUNDLE_PRICE_INDEX_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_bundle_selection`
--
ALTER TABLE `catalog_product_bundle_selection`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_OPTION` FOREIGN KEY (`option_id`) REFERENCES `catalog_product_bundle_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_BUNDLE_SELECTION_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_bundle_selection_price`
--
ALTER TABLE `catalog_product_bundle_selection_price`
  ADD CONSTRAINT `FK_BUNDLE_PRICE_SELECTION_ID` FOREIGN KEY (`selection_id`) REFERENCES `catalog_product_bundle_selection` (`selection_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_BUNDLE_PRICE_SELECTION_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_enabled_index`
--
ALTER TABLE `catalog_product_enabled_index`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENABLED_INDEX_PRODUCT_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENABLED_INDEX_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity`
--
ALTER TABLE `catalog_product_entity`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_ATTRIBUTE_SET_ID` FOREIGN KEY (`attribute_set_id`) REFERENCES `eav_attribute_set` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_datetime`
--
ALTER TABLE `catalog_product_entity_datetime`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DATETIME_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PROD_ENTITY_DATETIME_PROD_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_decimal`
--
ALTER TABLE `catalog_product_entity_decimal`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PROD_ENTITY_DECIMAL_PROD_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_gallery`
--
ALTER TABLE `catalog_product_entity_gallery`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_GALLERY_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_GALLERY_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_GALLERY_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_int`
--
ALTER TABLE `catalog_product_entity_int`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_INT_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_INT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_media_gallery`
--
ALTER TABLE `catalog_product_entity_media_gallery`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE;

--
-- Constraints for table `catalog_product_entity_media_gallery_value`
--
ALTER TABLE `catalog_product_entity_media_gallery_value`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_VALUE_GALLERY` FOREIGN KEY (`value_id`) REFERENCES `catalog_product_entity_media_gallery` (`value_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_MEDIA_GALLERY_VALUE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE;

--
-- Constraints for table `catalog_product_entity_text`
--
ALTER TABLE `catalog_product_entity_text`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TEXT_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TEXT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_tier_price`
--
ALTER TABLE `catalog_product_entity_tier_price`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_TIER_PRICE_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_TIER_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PROD_ENTITY_TIER_PRICE_PROD_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_entity_varchar`
--
ALTER TABLE `catalog_product_entity_varchar`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_VARCHAR_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PROD_ENTITY_VARCHAR_PROD_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_flat_1`
--
ALTER TABLE `catalog_product_flat_1`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_FLAT_1_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_index_eav`
--
ALTER TABLE `catalog_product_index_eav`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_EAV_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_EAV_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_EAV_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_index_eav_decimal`
--
ALTER TABLE `catalog_product_index_eav_decimal`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_EAV_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_EAV_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_EAV_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_index_price`
--
ALTER TABLE `catalog_product_index_price`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_PRICE_CUSTOMER_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_PRICE_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_index_tier_price`
--
ALTER TABLE `catalog_product_index_tier_price`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_TIER_PRICE_CUSTOMER` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_TIER_PRICE_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_TIER_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_index_website`
--
ALTER TABLE `catalog_product_index_website`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_INDEX_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_link`
--
ALTER TABLE `catalog_product_link`
  ADD CONSTRAINT `FK_PRODUCT_LINK_LINKED_PRODUCT` FOREIGN KEY (`linked_product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_LINK_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_LINK_TYPE` FOREIGN KEY (`link_type_id`) REFERENCES `catalog_product_link_type` (`link_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_link_attribute`
--
ALTER TABLE `catalog_product_link_attribute`
  ADD CONSTRAINT `FK_ATTRIBUTE_PRODUCT_LINK_TYPE` FOREIGN KEY (`link_type_id`) REFERENCES `catalog_product_link_type` (`link_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_link_attribute_decimal`
--
ALTER TABLE `catalog_product_link_attribute_decimal`
  ADD CONSTRAINT `FK_DECIMAL_LINK` FOREIGN KEY (`link_id`) REFERENCES `catalog_product_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_DECIMAL_PRODUCT_LINK_ATTRIBUTE` FOREIGN KEY (`product_link_attribute_id`) REFERENCES `catalog_product_link_attribute` (`product_link_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_link_attribute_int`
--
ALTER TABLE `catalog_product_link_attribute_int`
  ADD CONSTRAINT `FK_INT_PRODUCT_LINK` FOREIGN KEY (`link_id`) REFERENCES `catalog_product_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_INT_PRODUCT_LINK_ATTRIBUTE` FOREIGN KEY (`product_link_attribute_id`) REFERENCES `catalog_product_link_attribute` (`product_link_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_link_attribute_varchar`
--
ALTER TABLE `catalog_product_link_attribute_varchar`
  ADD CONSTRAINT `FK_VARCHAR_LINK` FOREIGN KEY (`link_id`) REFERENCES `catalog_product_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_VARCHAR_PRODUCT_LINK_ATTRIBUTE` FOREIGN KEY (`product_link_attribute_id`) REFERENCES `catalog_product_link_attribute` (`product_link_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_option`
--
ALTER TABLE `catalog_product_option`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_option_price`
--
ALTER TABLE `catalog_product_option_price`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_PRICE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `catalog_product_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_PRICE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_option_title`
--
ALTER TABLE `catalog_product_option_title`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TITLE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `catalog_product_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_option_type_price`
--
ALTER TABLE `catalog_product_option_type_price`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_PRICE_OPTION` FOREIGN KEY (`option_type_id`) REFERENCES `catalog_product_option_type_value` (`option_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_PRICE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_option_type_title`
--
ALTER TABLE `catalog_product_option_type_title`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_TITLE_OPTION` FOREIGN KEY (`option_type_id`) REFERENCES `catalog_product_option_type_value` (`option_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_option_type_value`
--
ALTER TABLE `catalog_product_option_type_value`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_OPTION_TYPE_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `catalog_product_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_relation`
--
ALTER TABLE `catalog_product_relation`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_RELATION_CHILD` FOREIGN KEY (`child_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_RELATION_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_super_attribute`
--
ALTER TABLE `catalog_product_super_attribute`
  ADD CONSTRAINT `FK_SUPER_PRODUCT_ATTRIBUTE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE;

--
-- Constraints for table `catalog_product_super_attribute_label`
--
ALTER TABLE `catalog_product_super_attribute_label`
  ADD CONSTRAINT `FK_CATALOG_PROD_SUPER_ATTR_LABEL_ATTR` FOREIGN KEY (`product_super_attribute_id`) REFERENCES `catalog_product_super_attribute` (`product_super_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PROD_SUPER_ATTR_LABEL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_super_attribute_pricing`
--
ALTER TABLE `catalog_product_super_attribute_pricing`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_SUPER_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SUPER_PRODUCT_ATTRIBUTE_PRICING` FOREIGN KEY (`product_super_attribute_id`) REFERENCES `catalog_product_super_attribute` (`product_super_attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_super_link`
--
ALTER TABLE `catalog_product_super_link`
  ADD CONSTRAINT `FK_SUPER_PRODUCT_LINK_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SUPER_PRODUCT_LINK_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `catalog_product_website`
--
ALTER TABLE `catalog_product_website`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_WEBSITE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_WEBSITE_PRODUCT_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `checkout_agreement_store`
--
ALTER TABLE `checkout_agreement_store`
  ADD CONSTRAINT `FK_CHECKOUT_AGREEMENT` FOREIGN KEY (`agreement_id`) REFERENCES `checkout_agreement` (`agreement_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CHECKOUT_AGREEMENT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cms_block_store`
--
ALTER TABLE `cms_block_store`
  ADD CONSTRAINT `FK_CMS_BLOCK_STORE_BLOCK` FOREIGN KEY (`block_id`) REFERENCES `cms_block` (`block_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CMS_BLOCK_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cms_page_store`
--
ALTER TABLE `cms_page_store`
  ADD CONSTRAINT `FK_CMS_PAGE_STORE_PAGE` FOREIGN KEY (`page_id`) REFERENCES `cms_page` (`page_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CMS_PAGE_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_layout_link`
--
ALTER TABLE `core_layout_link`
  ADD CONSTRAINT `FK_CORE_LAYOUT_LINK_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CORE_LAYOUT_LINK_UPDATE` FOREIGN KEY (`layout_update_id`) REFERENCES `core_layout_update` (`layout_update_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_session`
--
ALTER TABLE `core_session`
  ADD CONSTRAINT `FK_SESSION_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_store`
--
ALTER TABLE `core_store`
  ADD CONSTRAINT `FK_STORE_GROUP_STORE` FOREIGN KEY (`group_id`) REFERENCES `core_store_group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_STORE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_store_group`
--
ALTER TABLE `core_store_group`
  ADD CONSTRAINT `FK_STORE_GROUP_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_translate`
--
ALTER TABLE `core_translate`
  ADD CONSTRAINT `FK_CORE_TRANSLATE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_url_rewrite`
--
ALTER TABLE `core_url_rewrite`
  ADD CONSTRAINT `FK_CORE_URL_REWRITE_CATEGORY` FOREIGN KEY (`category_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CORE_URL_REWRITE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CORE_URL_REWRITE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `core_variable_value`
--
ALTER TABLE `core_variable_value`
  ADD CONSTRAINT `FK_CORE_VARIABLE_VALUE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CORE_VARIABLE_VALUE_VARIABLE_ID` FOREIGN KEY (`variable_id`) REFERENCES `core_variable` (`variable_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `coupon_aggregated`
--
ALTER TABLE `coupon_aggregated`
  ADD CONSTRAINT `FK_SALESTRULE_COUPON_AGGREGATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `coupon_aggregated_order`
--
ALTER TABLE `coupon_aggregated_order`
  ADD CONSTRAINT `FK_SALESTRULE_COUPON_AGGREGATED_ORDER_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_address_entity`
--
ALTER TABLE `customer_address_entity`
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_CUSTOMER_ID` FOREIGN KEY (`parent_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_address_entity_datetime`
--
ALTER TABLE `customer_address_entity_datetime`
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_address_entity_decimal`
--
ALTER TABLE `customer_address_entity_decimal`
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_address_entity_int`
--
ALTER TABLE `customer_address_entity_int`
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_address_entity_text`
--
ALTER TABLE `customer_address_entity_text`
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_address_entity_varchar`
--
ALTER TABLE `customer_address_entity_varchar`
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_address_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_ADDRESS_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_eav_attribute`
--
ALTER TABLE `customer_eav_attribute`
  ADD CONSTRAINT `FK_CUSTOMER_EAV_ATTRIBUTE_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_eav_attribute_website`
--
ALTER TABLE `customer_eav_attribute_website`
  ADD CONSTRAINT `FK_CUST_EAV_ATTR_WEBST_ATTR_EAV_ATTR` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUST_EAV_ATTR_WEBST_WEBST_CORE_WEBST` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_entity`
--
ALTER TABLE `customer_entity`
  ADD CONSTRAINT `FK_CUSTOMER_ENTITY_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `customer_entity_datetime`
--
ALTER TABLE `customer_entity_datetime`
  ADD CONSTRAINT `FK_CUSTOMER_DATETIME_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_entity_decimal`
--
ALTER TABLE `customer_entity_decimal`
  ADD CONSTRAINT `FK_CUSTOMER_DECIMAL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_entity_int`
--
ALTER TABLE `customer_entity_int`
  ADD CONSTRAINT `FK_CUSTOMER_INT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_entity_text`
--
ALTER TABLE `customer_entity_text`
  ADD CONSTRAINT `FK_CUSTOMER_TEXT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_entity_varchar`
--
ALTER TABLE `customer_entity_varchar`
  ADD CONSTRAINT `FK_CUSTOMER_VARCHAR_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CUSTOMER_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_form_attribute`
--
ALTER TABLE `customer_form_attribute`
  ADD CONSTRAINT `FK_CUSTOMER_FORM_ATTRIBUTE_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dataflow_batch`
--
ALTER TABLE `dataflow_batch`
  ADD CONSTRAINT `FK_DATAFLOW_BATCH_PROFILE` FOREIGN KEY (`profile_id`) REFERENCES `dataflow_profile` (`profile_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_DATAFLOW_BATCH_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE;

--
-- Constraints for table `dataflow_batch_export`
--
ALTER TABLE `dataflow_batch_export`
  ADD CONSTRAINT `FK_DATAFLOW_BATCH_EXPORT_BATCH` FOREIGN KEY (`batch_id`) REFERENCES `dataflow_batch` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `dataflow_batch_import`
--
ALTER TABLE `dataflow_batch_import`
  ADD CONSTRAINT `FK_DATAFLOW_BATCH_IMPORT_BATCH` FOREIGN KEY (`batch_id`) REFERENCES `dataflow_batch` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `dataflow_import_data`
--
ALTER TABLE `dataflow_import_data`
  ADD CONSTRAINT `FK_dataflow_import_data` FOREIGN KEY (`session_id`) REFERENCES `dataflow_session` (`session_id`);

--
-- Constraints for table `dataflow_profile_history`
--
ALTER TABLE `dataflow_profile_history`
  ADD CONSTRAINT `FK_dataflow_profile_history` FOREIGN KEY (`profile_id`) REFERENCES `dataflow_profile` (`profile_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `design_change`
--
ALTER TABLE `design_change`
  ADD CONSTRAINT `FK_DESIGN_CHANGE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `directory_country_region_name`
--
ALTER TABLE `directory_country_region_name`
  ADD CONSTRAINT `FK_DIRECTORY_REGION_NAME_REGION` FOREIGN KEY (`region_id`) REFERENCES `directory_country_region` (`region_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_link`
--
ALTER TABLE `downloadable_link`
  ADD CONSTRAINT `FK_DOWNLODABLE_LINK_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_link_price`
--
ALTER TABLE `downloadable_link_price`
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_PRICE_LINK` FOREIGN KEY (`link_id`) REFERENCES `downloadable_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_link_purchased`
--
ALTER TABLE `downloadable_link_purchased`
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_ORDER_ID` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_link_purchased_item`
--
ALTER TABLE `downloadable_link_purchased_item`
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_ORDER_ITEM_ID` FOREIGN KEY (`order_item_id`) REFERENCES `sales_flat_order_item` (`item_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_PURCHASED_ID` FOREIGN KEY (`purchased_id`) REFERENCES `downloadable_link_purchased` (`purchased_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_link_title`
--
ALTER TABLE `downloadable_link_title`
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_TITLE_LINK` FOREIGN KEY (`link_id`) REFERENCES `downloadable_link` (`link_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_DOWNLOADABLE_LINK_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_sample`
--
ALTER TABLE `downloadable_sample`
  ADD CONSTRAINT `FK_DOWNLODABLE_SAMPLE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `downloadable_sample_title`
--
ALTER TABLE `downloadable_sample_title`
  ADD CONSTRAINT `FK_DOWNLOADABLE_SAMPLE_TITLE_SAMPLE` FOREIGN KEY (`sample_id`) REFERENCES `downloadable_sample` (`sample_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_DOWNLOADABLE_SAMPLE_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_attribute`
--
ALTER TABLE `eav_attribute`
  ADD CONSTRAINT `FK_eav_attribute` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_attribute_group`
--
ALTER TABLE `eav_attribute_group`
  ADD CONSTRAINT `FK_eav_attribute_group` FOREIGN KEY (`attribute_set_id`) REFERENCES `eav_attribute_set` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_attribute_label`
--
ALTER TABLE `eav_attribute_label`
  ADD CONSTRAINT `FK_ATTRIBUTE_LABEL_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_ATTRIBUTE_LABEL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_attribute_option`
--
ALTER TABLE `eav_attribute_option`
  ADD CONSTRAINT `FK_ATTRIBUTE_OPTION_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_attribute_option_value`
--
ALTER TABLE `eav_attribute_option_value`
  ADD CONSTRAINT `FK_ATTRIBUTE_OPTION_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `eav_attribute_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_ATTRIBUTE_OPTION_VALUE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_attribute_set`
--
ALTER TABLE `eav_attribute_set`
  ADD CONSTRAINT `FK_eav_attribute_set` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity`
--
ALTER TABLE `eav_entity`
  ADD CONSTRAINT `FK_eav_entity` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_eav_entity_store` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_attribute`
--
ALTER TABLE `eav_entity_attribute`
  ADD CONSTRAINT `FK_EAV_ENTITY_ATTRIBUTE_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_ATTRIBUTE_GROUP` FOREIGN KEY (`attribute_group_id`) REFERENCES `eav_attribute_group` (`attribute_group_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_datetime`
--
ALTER TABLE `eav_entity_datetime`
  ADD CONSTRAINT `FK_EAV_ENTITY_DATETIME_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_DATETIME_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_DATETIME_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_decimal`
--
ALTER TABLE `eav_entity_decimal`
  ADD CONSTRAINT `FK_EAV_ENTITY_DECIMAL_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_DECIMAL_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_DECIMAL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_int`
--
ALTER TABLE `eav_entity_int`
  ADD CONSTRAINT `FK_EAV_ENTITY_INT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_INT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_INT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_store`
--
ALTER TABLE `eav_entity_store`
  ADD CONSTRAINT `FK_eav_entity_store_entity_type` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_eav_entity_store_store` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_text`
--
ALTER TABLE `eav_entity_text`
  ADD CONSTRAINT `FK_EAV_ENTITY_TEXT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_TEXT_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_TEXT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_entity_varchar`
--
ALTER TABLE `eav_entity_varchar`
  ADD CONSTRAINT `FK_EAV_ENTITY_VARCHAR_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `eav_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_VARCHAR_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_ENTITY_VARCHAR_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_form_element`
--
ALTER TABLE `eav_form_element`
  ADD CONSTRAINT `FK_EAV_FORM_ELEMENT_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_FORM_ELEMENT_FORM_FIELDSET` FOREIGN KEY (`fieldset_id`) REFERENCES `eav_form_fieldset` (`fieldset_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_FORM_ELEMENT_FORM_TYPE` FOREIGN KEY (`type_id`) REFERENCES `eav_form_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_form_fieldset`
--
ALTER TABLE `eav_form_fieldset`
  ADD CONSTRAINT `FK_EAV_FORM_FIELDSET_FORM_TYPE` FOREIGN KEY (`type_id`) REFERENCES `eav_form_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_form_fieldset_label`
--
ALTER TABLE `eav_form_fieldset_label`
  ADD CONSTRAINT `FK_EAV_FORM_FIELDSET_LABEL_FORM_FIELDSET` FOREIGN KEY (`fieldset_id`) REFERENCES `eav_form_fieldset` (`fieldset_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_FORM_FIELDSET_LABEL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_form_type`
--
ALTER TABLE `eav_form_type`
  ADD CONSTRAINT `FK_EAV_FORM_TYPE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eav_form_type_entity`
--
ALTER TABLE `eav_form_type_entity`
  ADD CONSTRAINT `FK_EAV_FORM_TYPE_ENTITY_ENTITY_TYPE` FOREIGN KEY (`entity_type_id`) REFERENCES `eav_entity_type` (`entity_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EAV_FORM_TYPE_ENTITY_FORM_TYPE` FOREIGN KEY (`type_id`) REFERENCES `eav_form_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `googlebase_attributes`
--
ALTER TABLE `googlebase_attributes`
  ADD CONSTRAINT `GOOGLEBASE_ATTRIBUTES_ATTRIBUTE_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `GOOGLEBASE_ATTRIBUTES_TYPE_ID` FOREIGN KEY (`type_id`) REFERENCES `googlebase_types` (`type_id`) ON DELETE CASCADE;

--
-- Constraints for table `googlebase_items`
--
ALTER TABLE `googlebase_items`
  ADD CONSTRAINT `GOOGLEBASE_ITEMS_PRODUCT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `GOOGLEBASE_ITEMS_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE;

--
-- Constraints for table `googlebase_types`
--
ALTER TABLE `googlebase_types`
  ADD CONSTRAINT `GOOGLEBASE_TYPES_ATTRIBUTE_SET_ID` FOREIGN KEY (`attribute_set_id`) REFERENCES `eav_attribute_set` (`attribute_set_id`) ON DELETE CASCADE;

--
-- Constraints for table `googleoptimizer_code`
--
ALTER TABLE `googleoptimizer_code`
  ADD CONSTRAINT `FK_GOOGLEOPTIMIZER_CODE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `index_process_event`
--
ALTER TABLE `index_process_event`
  ADD CONSTRAINT `FK_INDEX_EVNT_PROCESS` FOREIGN KEY (`event_id`) REFERENCES `index_event` (`event_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_INDEX_PROCESS_EVENT` FOREIGN KEY (`process_id`) REFERENCES `index_process` (`process_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `newsletter_problem`
--
ALTER TABLE `newsletter_problem`
  ADD CONSTRAINT `FK_PROBLEM_QUEUE` FOREIGN KEY (`queue_id`) REFERENCES `newsletter_queue` (`queue_id`),
  ADD CONSTRAINT `FK_PROBLEM_SUBSCRIBER` FOREIGN KEY (`subscriber_id`) REFERENCES `newsletter_subscriber` (`subscriber_id`);

--
-- Constraints for table `newsletter_queue`
--
ALTER TABLE `newsletter_queue`
  ADD CONSTRAINT `FK_QUEUE_TEMPLATE` FOREIGN KEY (`template_id`) REFERENCES `newsletter_template` (`template_id`) ON DELETE CASCADE;

--
-- Constraints for table `newsletter_queue_link`
--
ALTER TABLE `newsletter_queue_link`
  ADD CONSTRAINT `FK_QUEUE_LINK_QUEUE` FOREIGN KEY (`queue_id`) REFERENCES `newsletter_queue` (`queue_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_QUEUE_LINK_SUBSCRIBER` FOREIGN KEY (`subscriber_id`) REFERENCES `newsletter_subscriber` (`subscriber_id`) ON DELETE CASCADE;

--
-- Constraints for table `newsletter_queue_store_link`
--
ALTER TABLE `newsletter_queue_store_link`
  ADD CONSTRAINT `FK_LINK_QUEUE` FOREIGN KEY (`queue_id`) REFERENCES `newsletter_queue` (`queue_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_NEWSLETTER_QUEUE_STORE_LINK_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `newsletter_subscriber`
--
ALTER TABLE `newsletter_subscriber`
  ADD CONSTRAINT `FK_NEWSLETTER_SUBSCRIBER_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `paypal_cert`
--
ALTER TABLE `paypal_cert`
  ADD CONSTRAINT `FK_PAYPAL_CERT_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `paypal_settlement_report_row`
--
ALTER TABLE `paypal_settlement_report_row`
  ADD CONSTRAINT `FK_PAYPAL_SETTLEMENT_ROW_REPORT` FOREIGN KEY (`report_id`) REFERENCES `paypal_settlement_report` (`report_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `poll`
--
ALTER TABLE `poll`
  ADD CONSTRAINT `FK_POLL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `poll_answer`
--
ALTER TABLE `poll_answer`
  ADD CONSTRAINT `FK_POLL_PARENT` FOREIGN KEY (`poll_id`) REFERENCES `poll` (`poll_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `poll_store`
--
ALTER TABLE `poll_store`
  ADD CONSTRAINT `FK_POLL_STORE_POLL` FOREIGN KEY (`poll_id`) REFERENCES `poll` (`poll_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_POLL_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `poll_vote`
--
ALTER TABLE `poll_vote`
  ADD CONSTRAINT `FK_POLL_ANSWER` FOREIGN KEY (`poll_answer_id`) REFERENCES `poll_answer` (`answer_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_alert_price`
--
ALTER TABLE `product_alert_price`
  ADD CONSTRAINT `FK_PRODUCT_ALERT_PRICE_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ALERT_PRICE_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ALERT_PRICE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_alert_stock`
--
ALTER TABLE `product_alert_stock`
  ADD CONSTRAINT `FK_PRODUCT_ALERT_STOCK_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ALERT_STOCK_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ALERT_STOCK_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `FK_RATING_ENTITY_KEY` FOREIGN KEY (`entity_id`) REFERENCES `rating_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating_option`
--
ALTER TABLE `rating_option`
  ADD CONSTRAINT `FK_RATING_OPTION_RATING` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating_option_vote`
--
ALTER TABLE `rating_option_vote`
  ADD CONSTRAINT `FK_RATING_OPTION_REVIEW_ID` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_RATING_OPTION_VALUE_OPTION` FOREIGN KEY (`option_id`) REFERENCES `rating_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating_option_vote_aggregated`
--
ALTER TABLE `rating_option_vote_aggregated`
  ADD CONSTRAINT `FK_RATING_OPTION_VALUE_AGGREGATE` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_RATING_OPTION_VOTE_AGGREGATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating_store`
--
ALTER TABLE `rating_store`
  ADD CONSTRAINT `FK_RATING_STORE_RATING` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_RATING_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating_title`
--
ALTER TABLE `rating_title`
  ADD CONSTRAINT `FK_RATING_TITLE` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_RATING_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `report_compared_product_index`
--
ALTER TABLE `report_compared_product_index`
  ADD CONSTRAINT `FK_REPORT_COMPARED_PRODUCT_INDEX_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REPORT_COMPARED_PRODUCT_INDEX_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REPORT_COMPARED_PRODUCT_INDEX_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `report_event`
--
ALTER TABLE `report_event`
  ADD CONSTRAINT `FK_REPORT_EVENT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REPORT_EVENT_TYPE` FOREIGN KEY (`event_type_id`) REFERENCES `report_event_types` (`event_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `report_viewed_product_index`
--
ALTER TABLE `report_viewed_product_index`
  ADD CONSTRAINT `FK_REPORT_VIEWED_PRODUCT_INDEX_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REPORT_VIEWED_PRODUCT_INDEX_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REPORT_VIEWED_PRODUCT_INDEX_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `FK_REVIEW_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `review_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REVIEW_STATUS` FOREIGN KEY (`status_id`) REFERENCES `review_status` (`status_id`);

--
-- Constraints for table `review_detail`
--
ALTER TABLE `review_detail`
  ADD CONSTRAINT `FK_REVIEW_DETAIL_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REVIEW_DETAIL_REVIEW` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REVIEW_DETAIL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `review_entity_summary`
--
ALTER TABLE `review_entity_summary`
  ADD CONSTRAINT `FK_REVIEW_ENTITY_SUMMARY_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `review_store`
--
ALTER TABLE `review_store`
  ADD CONSTRAINT `FK_REVIEW_STORE_REVIEW` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_REVIEW_STORE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesrule_coupon`
--
ALTER TABLE `salesrule_coupon`
  ADD CONSTRAINT `FK_SALESRULE_COUPON_RULE_ID_SALESRULE` FOREIGN KEY (`rule_id`) REFERENCES `salesrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesrule_coupon_usage`
--
ALTER TABLE `salesrule_coupon_usage`
  ADD CONSTRAINT `FK_SALESRULE_CPN_CUST_CPN_ID_CUST_ENTITY` FOREIGN KEY (`coupon_id`) REFERENCES `salesrule_coupon` (`coupon_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALESRULE_CPN_CUST_CUST_ID_CUST_ENTITY` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesrule_customer`
--
ALTER TABLE `salesrule_customer`
  ADD CONSTRAINT `FK_salesrule_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_salesrule_customer_rule` FOREIGN KEY (`rule_id`) REFERENCES `salesrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesrule_label`
--
ALTER TABLE `salesrule_label`
  ADD CONSTRAINT `FK_SALESRULE_LABEL_RULE` FOREIGN KEY (`rule_id`) REFERENCES `salesrule` (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALESRULE_LABEL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesrule_product_attribute`
--
ALTER TABLE `salesrule_product_attribute`
  ADD CONSTRAINT `FK_SALESRULE_PRODUCT_ATTRIBUTE_ATTRIBUTE` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_SALESRULE_PRODUCT_ATTRIBUTE_CUSTOMER_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_SALESRULE_PRODUCT_ATTRIBUTE_RULE` FOREIGN KEY (`rule_id`) REFERENCES `salesrule` (`rule_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_SALESRULE_PRODUCT_ATTRIBUTE_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE;

--
-- Constraints for table `sales_bestsellers_aggregated_daily`
--
ALTER TABLE `sales_bestsellers_aggregated_daily`
  ADD CONSTRAINT `FK_PRODUCT_ORDERED_AGGREGATED_DAILY_PRODUCT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ORDERED_AGGREGATED_DAILY_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_bestsellers_aggregated_monthly`
--
ALTER TABLE `sales_bestsellers_aggregated_monthly`
  ADD CONSTRAINT `FK_PRODUCT_ORDERED_AGGREGATED_MONTHLY_PRODUCT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ORDERED_AGGREGATED_MONTHLY_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_bestsellers_aggregated_yearly`
--
ALTER TABLE `sales_bestsellers_aggregated_yearly`
  ADD CONSTRAINT `FK_PRODUCT_ORDERED_AGGREGATED_YEARLY_PRODUCT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_ORDERED_AGGREGATED_YEARLY_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_billing_agreement`
--
ALTER TABLE `sales_billing_agreement`
  ADD CONSTRAINT `FK_BILLING_AGREEMENT_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_BILLING_AGREEMENT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_billing_agreement_order`
--
ALTER TABLE `sales_billing_agreement_order`
  ADD CONSTRAINT `FK_BILLING_AGREEMENT_ORDER_AGREEMENT` FOREIGN KEY (`agreement_id`) REFERENCES `sales_billing_agreement` (`agreement_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_BILLING_AGREEMENT_ORDER_ORDER` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_creditmemo`
--
ALTER TABLE `sales_flat_creditmemo`
  ADD CONSTRAINT `FK_SALES_FLAT_CREDITMEMO_PARENT` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_CREDITMEMO_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_creditmemo_comment`
--
ALTER TABLE `sales_flat_creditmemo_comment`
  ADD CONSTRAINT `FK_SALES_FLAT_CREDITMEMO_COMMENT_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_creditmemo` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_creditmemo_grid`
--
ALTER TABLE `sales_flat_creditmemo_grid`
  ADD CONSTRAINT `FK_SALES_FLAT_CREDITMEMO_GRID_PARENT` FOREIGN KEY (`entity_id`) REFERENCES `sales_flat_creditmemo` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_CREDITMEMO_GRID_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_creditmemo_item`
--
ALTER TABLE `sales_flat_creditmemo_item`
  ADD CONSTRAINT `FK_SALES_FLAT_CREDITMEMO_ITEM_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_creditmemo` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_invoice`
--
ALTER TABLE `sales_flat_invoice`
  ADD CONSTRAINT `FK_SALES_FLAT_INVOICE_PARENT` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_INVOICE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_invoice_comment`
--
ALTER TABLE `sales_flat_invoice_comment`
  ADD CONSTRAINT `FK_SALES_FLAT_INVOICE_COMMENT_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_invoice` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_invoice_grid`
--
ALTER TABLE `sales_flat_invoice_grid`
  ADD CONSTRAINT `FK_SALES_FLAT_INVOICE_GRID_PARENT` FOREIGN KEY (`entity_id`) REFERENCES `sales_flat_invoice` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_INVOICE_GRID_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_invoice_item`
--
ALTER TABLE `sales_flat_invoice_item`
  ADD CONSTRAINT `FK_SALES_FLAT_INVOICE_ITEM_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_invoice` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_order`
--
ALTER TABLE `sales_flat_order`
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_order_address`
--
ALTER TABLE `sales_flat_order_address`
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_ADDRESS_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_order_grid`
--
ALTER TABLE `sales_flat_order_grid`
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_GRID_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_GRID_PARENT` FOREIGN KEY (`entity_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_GRID_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_order_item`
--
ALTER TABLE `sales_flat_order_item`
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_ITEM_PARENT` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_ITEM_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_order_payment`
--
ALTER TABLE `sales_flat_order_payment`
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_PAYMENT_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_order_status_history`
--
ALTER TABLE `sales_flat_order_status_history`
  ADD CONSTRAINT `FK_SALES_FLAT_ORDER_STATUS_HISTORY_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote`
--
ALTER TABLE `sales_flat_quote`
  ADD CONSTRAINT `FK_SALES_QUOTE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote_address`
--
ALTER TABLE `sales_flat_quote_address`
  ADD CONSTRAINT `FK_SALES_QUOTE_ADDRESS_SALES_QUOTE` FOREIGN KEY (`quote_id`) REFERENCES `sales_flat_quote` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote_address_item`
--
ALTER TABLE `sales_flat_quote_address_item`
  ADD CONSTRAINT `FK_QUOTE_ADDRESS_ITEM_QUOTE_ADDRESS` FOREIGN KEY (`quote_address_id`) REFERENCES `sales_flat_quote_address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_QUOTE_ADDRESS_ITEM_PARENT` FOREIGN KEY (`parent_item_id`) REFERENCES `sales_flat_quote_address_item` (`address_item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_QUOTE_ADDRESS_ITEM_QUOTE_ITEM` FOREIGN KEY (`quote_item_id`) REFERENCES `sales_flat_quote_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote_item`
--
ALTER TABLE `sales_flat_quote_item`
  ADD CONSTRAINT `FK_SALES_FLAT_QUOTE_ITEM_PARENT_ITEM` FOREIGN KEY (`parent_item_id`) REFERENCES `sales_flat_quote_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_QUOTE_ITEM_CATALOG_PRODUCT_ENTITY` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_QUOTE_ITEM_SALES_QUOTE` FOREIGN KEY (`quote_id`) REFERENCES `sales_flat_quote` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_QUOTE_ITEM_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote_item_option`
--
ALTER TABLE `sales_flat_quote_item_option`
  ADD CONSTRAINT `FK_SALES_QUOTE_ITEM_OPTION_ITEM_ID` FOREIGN KEY (`item_id`) REFERENCES `sales_flat_quote_item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote_payment`
--
ALTER TABLE `sales_flat_quote_payment`
  ADD CONSTRAINT `FK_SALES_QUOTE_PAYMENT_SALES_QUOTE` FOREIGN KEY (`quote_id`) REFERENCES `sales_flat_quote` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_quote_shipping_rate`
--
ALTER TABLE `sales_flat_quote_shipping_rate`
  ADD CONSTRAINT `FK_SALES_QUOTE_SHIPPING_RATE_ADDRESS` FOREIGN KEY (`address_id`) REFERENCES `sales_flat_quote_address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_shipment`
--
ALTER TABLE `sales_flat_shipment`
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_PARENT` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_shipment_comment`
--
ALTER TABLE `sales_flat_shipment_comment`
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_COMMENT_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_shipment` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_shipment_grid`
--
ALTER TABLE `sales_flat_shipment_grid`
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_GRID_PARENT` FOREIGN KEY (`entity_id`) REFERENCES `sales_flat_shipment` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_GRID_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_shipment_item`
--
ALTER TABLE `sales_flat_shipment_item`
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_ITEM_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_shipment` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_flat_shipment_track`
--
ALTER TABLE `sales_flat_shipment_track`
  ADD CONSTRAINT `FK_SALES_FLAT_SHIPMENT_TRACK_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_flat_shipment` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_invoiced_aggregated`
--
ALTER TABLE `sales_invoiced_aggregated`
  ADD CONSTRAINT `FK_SALES_INVOICED_AGGREGATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_invoiced_aggregated_order`
--
ALTER TABLE `sales_invoiced_aggregated_order`
  ADD CONSTRAINT `FK_SALES_INVOICED_AGGREGATED_ORDER_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_order_aggregated_created`
--
ALTER TABLE `sales_order_aggregated_created`
  ADD CONSTRAINT `FK_SALES_ORDER_AGGREGATED_CREATED` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_order_status_label`
--
ALTER TABLE `sales_order_status_label`
  ADD CONSTRAINT `FK_SALES_ORDER_STATUS_LABEL_STATUS` FOREIGN KEY (`status`) REFERENCES `sales_order_status` (`status`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_ORDER_STATUS_LABEL_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_order_status_state`
--
ALTER TABLE `sales_order_status_state`
  ADD CONSTRAINT `FK_SALES_ORDER_STATUS_STATE_STATUS` FOREIGN KEY (`status`) REFERENCES `sales_order_status` (`status`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_payment_transaction`
--
ALTER TABLE `sales_payment_transaction`
  ADD CONSTRAINT `FK_SALES_PAYMENT_TRANSACTION_ORDER` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_PAYMENT_TRANSACTION_PARENT` FOREIGN KEY (`parent_id`) REFERENCES `sales_payment_transaction` (`transaction_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SALES_PAYMENT_TRANSACTION_PAYMENT` FOREIGN KEY (`payment_id`) REFERENCES `sales_flat_order_payment` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_recurring_profile`
--
ALTER TABLE `sales_recurring_profile`
  ADD CONSTRAINT `FK_RECURRING_PROFILE_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_RECURRING_PROFILE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_recurring_profile_order`
--
ALTER TABLE `sales_recurring_profile_order`
  ADD CONSTRAINT `FK_RECURRING_PROFILE_ORDER_ORDER` FOREIGN KEY (`order_id`) REFERENCES `sales_flat_order` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_RECURRING_PROFILE_ORDER_PROFILE` FOREIGN KEY (`profile_id`) REFERENCES `sales_recurring_profile` (`profile_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_refunded_aggregated`
--
ALTER TABLE `sales_refunded_aggregated`
  ADD CONSTRAINT `FK_SALES_REFUNDED_AGGREGATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_refunded_aggregated_order`
--
ALTER TABLE `sales_refunded_aggregated_order`
  ADD CONSTRAINT `FK_SALES_REFUNDED_AGGREGATED_ORDER_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_shipping_aggregated`
--
ALTER TABLE `sales_shipping_aggregated`
  ADD CONSTRAINT `FK_SALES_SHIPPING_AGGREGATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sales_shipping_aggregated_order`
--
ALTER TABLE `sales_shipping_aggregated_order`
  ADD CONSTRAINT `FK_SALES_SHIPPING_AGGREGATED_ORDER_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `sitemap`
--
ALTER TABLE `sitemap`
  ADD CONSTRAINT `FK_SITEMAP_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tag_properties`
--
ALTER TABLE `tag_properties`
  ADD CONSTRAINT `FK_TAG_PROPERTIES_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAG_PROPERTIES_TAG` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tag_relation`
--
ALTER TABLE `tag_relation`
  ADD CONSTRAINT `FK_TAG_RELATION_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAG_RELATION_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAG_RELATION_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAG_RELATION_TAG` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tag_summary`
--
ALTER TABLE `tag_summary`
  ADD CONSTRAINT `FK_TAG_SUMMARY_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAG_SUMMARY_TAG` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tax_calculation`
--
ALTER TABLE `tax_calculation`
  ADD CONSTRAINT `FK_TAX_CALCULATION_CTC` FOREIGN KEY (`customer_tax_class_id`) REFERENCES `tax_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAX_CALCULATION_PTC` FOREIGN KEY (`product_tax_class_id`) REFERENCES `tax_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAX_CALCULATION_RATE` FOREIGN KEY (`tax_calculation_rate_id`) REFERENCES `tax_calculation_rate` (`tax_calculation_rate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAX_CALCULATION_RULE` FOREIGN KEY (`tax_calculation_rule_id`) REFERENCES `tax_calculation_rule` (`tax_calculation_rule_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tax_calculation_rate_title`
--
ALTER TABLE `tax_calculation_rate_title`
  ADD CONSTRAINT `FK_TAX_CALCULATION_RATE_TITLE_RATE` FOREIGN KEY (`tax_calculation_rate_id`) REFERENCES `tax_calculation_rate` (`tax_calculation_rate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TAX_CALCULATION_RATE_TITLE_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tax_order_aggregated_created`
--
ALTER TABLE `tax_order_aggregated_created`
  ADD CONSTRAINT `FK_TAX_ORDER_AGGREGATED_CREATED_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `weee_discount`
--
ALTER TABLE `weee_discount`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_GROUP` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_group` (`customer_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_DISCOUNT_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `weee_tax`
--
ALTER TABLE `weee_tax`
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_COUNTRY` FOREIGN KEY (`country`) REFERENCES `directory_country` (`country_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_PRODUCT_ENTITY` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CATALOG_PRODUCT_ENTITY_WEEE_TAX_WEBSITE` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_WEEE_TAX_ATTRIBUTE_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `widget_instance_page`
--
ALTER TABLE `widget_instance_page`
  ADD CONSTRAINT `FK_WIDGET_WIDGET_INSTANCE_ID` FOREIGN KEY (`instance_id`) REFERENCES `widget_instance` (`instance_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `widget_instance_page_layout`
--
ALTER TABLE `widget_instance_page_layout`
  ADD CONSTRAINT `FK_WIDGET_WIDGET_INSTANCE_LAYOUT_UPDATE_ID` FOREIGN KEY (`layout_update_id`) REFERENCES `core_layout_update` (`layout_update_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_WIDGET_WIDGET_INSTANCE_PAGE_ID` FOREIGN KEY (`page_id`) REFERENCES `widget_instance_page` (`page_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `FK_WISHLIST_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist_item`
--
ALTER TABLE `wishlist_item`
  ADD CONSTRAINT `FK_WISHLIST_ITEM_PRODUCT` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_WISHLIST_ITEM_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_WISHLIST_ITEM_WISHLIST` FOREIGN KEY (`wishlist_id`) REFERENCES `wishlist` (`wishlist_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist_item_option`
--
ALTER TABLE `wishlist_item_option`
  ADD CONSTRAINT `FK_WISHLIST_ITEM_OPTION_ITEM_ID` FOREIGN KEY (`wishlist_item_id`) REFERENCES `wishlist_item` (`wishlist_item_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `xmlconnect_application`
--
ALTER TABLE `xmlconnect_application`
  ADD CONSTRAINT `FK_XMLCONNECT_APPLICAION_STORE` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `xmlconnect_history`
--
ALTER TABLE `xmlconnect_history`
  ADD CONSTRAINT `FK_XMLCONNECT_HISTORY_APPLICATION` FOREIGN KEY (`application_id`) REFERENCES `xmlconnect_application` (`application_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `xmlconnect_notification_template`
--
ALTER TABLE `xmlconnect_notification_template`
  ADD CONSTRAINT `FK_APP_CODE` FOREIGN KEY (`app_code`) REFERENCES `xmlconnect_application` (`code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `xmlconnect_queue`
--
ALTER TABLE `xmlconnect_queue`
  ADD CONSTRAINT `FK_TEMPLATE_ID` FOREIGN KEY (`template_id`) REFERENCES `xmlconnect_notification_template` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
